// ============================================
// eBook Reader JavaScript
// ============================================

// State management
const ebookState = {
  currentPage: 1,
  totalPages: 10,
  viewMode: 'spread', // 'single' or 'spread' - start with spread view
  rotation: 0, // 0, 90, 180, 270
  pages: [],
  scale: 1,
  autoViewMode: false // Track if view mode is auto-managed
};

// Initialize the ebook reader
function initEbookReader() {
  // Check if pages exist in HTML, otherwise generate them
  const pageContainer = document.getElementById('pageContainer');
  const existingPages = pageContainer.querySelectorAll('.page');
  
  if (existingPages.length === 0) {
    // Generate sample pages only if none exist
    generatePages();
  } else {
    // Update totalPages based on existing pages
    ebookState.totalPages = existingPages.length;
  }
  
  // Setup event listeners
  setupEventListeners();
  
  // Check initial orientation and set view mode
  handleOrientationChange();
  
  // Set initial view mode UI
  updateViewModeUI();
  
  // Render initial view
  renderPages();
  
  // Update UI
  updatePageInput();
  
  // Calculate and apply initial scale
  calculateAndApplyScale();
}

// Update view mode UI
function updateViewModeUI() {
  if (ebookState.viewMode === 'spread') {
    document.getElementById('viewModeIcon').setAttribute('href', '#icon-spread');
    document.getElementById('viewModeText').textContent = 'Spread';
  } else {
    document.getElementById('viewModeIcon').setAttribute('href', '#icon-single-page');
    document.getElementById('viewModeText').textContent = 'Single';
  }
}

// Generate sample pages
function generatePages() {
  const pageContainer = document.getElementById('pageContainer');
  
  // Clear existing pages
  pageContainer.innerHTML = '';
  ebookState.pages = []; // Reset pages array
  
  // Generate 10 sample pages
  for (let i = 1; i <= ebookState.totalPages; i++) {
    const page = createPage(i);
    ebookState.pages.push(page);
    pageContainer.appendChild(page);
  }
}

// Create a page element
function createPage(pageNumber) {
  const page = document.createElement('div');
  page.className = 'page';
  page.dataset.page = pageNumber;
  
  const content = document.createElement('div');
  content.className = 'page-content';
  
  const title = document.createElement('h2');
  title.textContent = `Chapter ${pageNumber}`;
  
  const paragraph1 = document.createElement('p');
  paragraph1.textContent = `This is page ${pageNumber} of the eBook. You can navigate through the pages using the controls at the bottom.`;
  
  const paragraph2 = document.createElement('p');
  paragraph2.textContent = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris.';
  
  const paragraph3 = document.createElement('p');
  paragraph3.textContent = 'Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.';
  
  const pageNum = document.createElement('div');
  pageNum.className = 'page-number';
  pageNum.textContent = pageNumber;
  
  content.appendChild(title);
  content.appendChild(paragraph1);
  content.appendChild(paragraph2);
  content.appendChild(paragraph3);
  content.appendChild(pageNum);
  
  page.appendChild(content);
  
  return page;
}

// Setup event listeners
function setupEventListeners() {
  // Top bar buttons
  // Note: helpBtn listener is set up in DOMContentLoaded to call openHelpSupportModal()
  document.getElementById('closeBtn').addEventListener('click', handleClose);
  
  // Window resize and orientation change
  window.addEventListener('resize', handleResize);
  window.addEventListener('orientationchange', handleOrientationChange);
  
  // Bottom bar buttons
  document.getElementById('toggleViewBtn').addEventListener('click', toggleViewMode);
  document.getElementById('rotateBtn').addEventListener('click', rotateEbook);
  document.getElementById('prevPageBtn').addEventListener('click', previousPage);
  document.getElementById('nextPageBtn').addEventListener('click', nextPage);
  document.getElementById('annotationBtn').addEventListener('click', handleAnnotation);
  document.getElementById('resourcesBtn').addEventListener('click', handleResources);
  document.getElementById('tocBtn').addEventListener('click', handleTableOfContents);
  
  // Page input
  const pageInput = document.getElementById('pageInput');
  pageInput.addEventListener('change', handlePageInput);
  pageInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
      handlePageInput();
    }
  });
  
  // Keyboard navigation
  document.addEventListener('keydown', handleKeyboardNavigation);
}

// Handle help button
function handleHelp() {
  alert('eBook Reader Help:\n\n' +
    '• Use arrow buttons or arrow keys to navigate\n' +
    '• Toggle between single page and spread view\n' +
    '• Rotate the book for different orientations\n' +
    '• Add annotations to mark important sections\n' +
    '• Access resources and table of contents\n\n' +
    'For more support, visit the Help & Support page.');
}

// Handle close button
function handleClose() {
  window.close();
}

// Toggle view mode
function toggleViewMode() {
  // Disable auto view mode when user manually toggles
  ebookState.autoViewMode = false;
  
  if (ebookState.viewMode === 'single') {
    ebookState.viewMode = 'spread';
  } else {
    ebookState.viewMode = 'single';
  }
  
  updateViewModeUI();
  renderPages();
  calculateAndApplyScale();
}

// Rotate ebook
function rotateEbook() {
  ebookState.rotation = (ebookState.rotation + 90) % 360;
  const viewer = document.getElementById('ebookViewer');
  
  viewer.className = 'ebook-viewer';
  if (ebookState.rotation === 90) {
    viewer.classList.add('rotated-90');
  } else if (ebookState.rotation === 180) {
    viewer.classList.add('rotated-180');
  } else if (ebookState.rotation === 270) {
    viewer.classList.add('rotated-270');
  }
}

// Navigate to previous page
function previousPage() {
  const step = ebookState.viewMode === 'spread' ? 2 : 1;
  
  if (ebookState.currentPage > 1) {
    // Add flip animation
    animatePageFlip('prev');
    
    setTimeout(() => {
      ebookState.currentPage = Math.max(1, ebookState.currentPage - step);
      renderPages();
      updatePageInput();
    }, 250);
  }
}

// Navigate to next page
function nextPage() {
  const step = ebookState.viewMode === 'spread' ? 2 : 1;
  const maxPage = ebookState.totalPages;
  
  if (ebookState.currentPage < maxPage) {
    // Add flip animation
    animatePageFlip('next');
    
    setTimeout(() => {
      ebookState.currentPage = Math.min(maxPage, ebookState.currentPage + step);
      renderPages();
      updatePageInput();
    }, 250);
  }
}

// Animate page flip
function animatePageFlip(direction) {
  const pages = document.querySelectorAll('.page');
  pages.forEach(page => {
    if (direction === 'next') {
      page.classList.add('flipping-out');
    } else {
      page.classList.add('flipping-in');
    }
    
    setTimeout(() => {
      page.classList.remove('flipping-out', 'flipping-in');
    }, 500);
  });
}

// Handle page input
function handlePageInput() {
  const input = document.getElementById('pageInput');
  let pageNum = parseInt(input.value);
  
  if (isNaN(pageNum) || pageNum < 1) {
    pageNum = 1;
  } else if (pageNum > ebookState.totalPages) {
    pageNum = ebookState.totalPages;
  }
  
  ebookState.currentPage = pageNum;
  renderPages();
  updatePageInput();
}

// Update page input value
function updatePageInput() {
  document.getElementById('pageInput').value = ebookState.currentPage;
  document.getElementById('totalPages').textContent = ebookState.totalPages;
}

// Render pages based on current state
function renderPages() {
  const pageContainer = document.getElementById('pageContainer');
  const pages = pageContainer.querySelectorAll('.page');
  
  console.log('Rendering pages. Total:', pages.length, 'Current page:', ebookState.currentPage, 'View mode:', ebookState.viewMode);
  
  // Hide all pages first
  pages.forEach(page => {
    page.style.display = 'none';
  });
  
  if (ebookState.viewMode === 'single') {
    // Show only current page
    pageContainer.classList.add('single-view');
    const currentPage = pageContainer.querySelector(`[data-page="${ebookState.currentPage}"]`);
    if (currentPage) {
      currentPage.style.display = 'block';
      console.log('Showing page:', ebookState.currentPage);
    } else {
      console.error('Page not found:', ebookState.currentPage);
    }
  } else {
    // Show current page and next page (spread view)
    pageContainer.classList.remove('single-view');
    
    const currentPage = pageContainer.querySelector(`[data-page="${ebookState.currentPage}"]`);
    const nextPageNum = ebookState.currentPage + 1;
    const nextPage = pageContainer.querySelector(`[data-page="${nextPageNum}"]`);
    
    if (currentPage) {
      currentPage.style.display = 'block';
      console.log('Showing page:', ebookState.currentPage);
    } else {
      console.error('Page not found:', ebookState.currentPage);
    }
    
    if (nextPage && nextPageNum <= ebookState.totalPages) {
      nextPage.style.display = 'block';
      console.log('Showing page:', nextPageNum);
    }
  }
  
  // Recalculate scale after rendering
  setTimeout(() => {
    calculateAndApplyScale();
  }, 50);
}

// Handle keyboard navigation
function handleKeyboardNavigation(e) {
  switch(e.key) {
    case 'ArrowLeft':
      previousPage();
      break;
    case 'ArrowRight':
      nextPage();
      break;
    case 'Home':
      ebookState.currentPage = 1;
      renderPages();
      updatePageInput();
      break;
    case 'End':
      ebookState.currentPage = ebookState.totalPages;
      renderPages();
      updatePageInput();
      break;
  }
}

// Handle annotation button
function handleAnnotation() {
  alert('Annotation feature:\n\n' +
    'Click on any text in the book to add highlights and notes.\n' +
    'Your annotations will be saved and synced across devices.\n\n' +
    '(This is a demo - actual annotation functionality would be implemented here)');
}

// Handle resources button
function handleResources() {
  alert('Resources:\n\n' +
    '• Supplementary materials\n' +
    '• Practice exercises\n' +
    '• Video tutorials\n' +
    '• Downloadable content\n' +
    '• External links\n\n' +
    '(This is a demo - actual resources would be displayed here)');
}

// Handle table of contents button
function handleTableOfContents() {
  let tocContent = 'Table of Contents:\n\n';
  for (let i = 1; i <= ebookState.totalPages; i++) {
    tocContent += `Chapter ${i} ........................ Page ${i}\n`;
  }
  
  const selectedChapter = prompt(tocContent + '\nEnter chapter number to navigate:');
  
  if (selectedChapter) {
    const chapterNum = parseInt(selectedChapter);
    if (chapterNum >= 1 && chapterNum <= ebookState.totalPages) {
      ebookState.currentPage = chapterNum;
      renderPages();
      updatePageInput();
    }
  }
}

// Handle window resize
function handleResize() {
  calculateAndApplyScale();
}

// Handle orientation change
function handleOrientationChange() {
  // Check if we're on mobile
  const isMobile = window.innerWidth <= 768;
  
  if (isMobile) {
    ebookState.autoViewMode = true;
    const isPortrait = window.innerHeight > window.innerWidth;
    
    if (isPortrait) {
      ebookState.viewMode = 'single';
    } else {
      ebookState.viewMode = 'spread';
    }
    
    updateViewModeUI();
    renderPages();
  } else if (ebookState.autoViewMode) {
    // On desktop, if auto mode was active, set to spread
    ebookState.viewMode = 'spread';
    ebookState.autoViewMode = false;
    updateViewModeUI();
    renderPages();
  }
  
  // Recalculate scale after orientation change
  setTimeout(() => {
    calculateAndApplyScale();
  }, 100);
}

// Calculate and apply scale to fit viewport
function calculateAndApplyScale() {
  const pageContainer = document.getElementById('pageContainer');
  const pages = pageContainer.querySelectorAll('.page');
  
  if (pages.length === 0) return;
  
  // Get available space
  const topBarHeight = 60; // var(--header-height)
  const bottomBarHeight = 60; // var(--toolbar-height)
  const availableHeight = window.innerHeight - topBarHeight - bottomBarHeight - 40; // 40px padding
  const availableWidth = window.innerWidth - 40; // 40px padding
  
  // Base page dimensions
  const pageWidth = 650;
  const pageHeight = 900;
  
  // Calculate scale based on view mode
  let scaleX, scaleY, scale;
  
  if (ebookState.viewMode === 'single') {
    // Single page view
    scaleX = availableWidth / pageWidth;
    scaleY = availableHeight / pageHeight;
  } else {
    // Spread view (two pages side by side)
    scaleX = availableWidth / (pageWidth * 2);
    scaleY = availableHeight / pageHeight;
  }
  
  // Use the smaller scale to ensure both dimensions fit
  scale = Math.min(scaleX, scaleY, 1); // Don't scale up beyond 100%
  
  // Apply scale
  ebookState.scale = scale;
  pageContainer.style.transform = `scale(${scale})`;
  pageContainer.style.transformOrigin = 'center center';
  
  console.log('Scale applied:', scale, 'View mode:', ebookState.viewMode);
}

// ============================================
// eBook Features Slideshow Management
// ============================================
// SLIDE CONFIGURATION - Easy to edit!
// ============================================
const SLIDE_CONFIGURATIONS = {
  'teacher-ebook': [1, 2, 3, 4, 5, 10],
  'student-ebook': [1, 2, 3, 4, 5, 10],
  'teacher-ai': [1, 2, 3, 4, 5, 9, 10],
  'student-ai': [1, 2, 3, 4, 5, 11, 10],
  'teacher-digital-literacy': [1, 2, 3, 4, 5, 6, 7, 9, 10],
  'student-digital-literacy': [1, 2, 3, 4, 5, 6, 11, 10],
  'teacher-mpah-maths': [1, 2, 3, 4, 5, 6, 7, 9, 10],
  'student-mpah-maths': [1, 2, 3, 4, 5, 6, 11, 10]
};

// ============================================
// Configuration Modal
// ============================================
const configModal = document.getElementById('configModal');
const contentTypeSelection = document.getElementById('contentTypeSelection');
let selectedUserType = null;
let selectedContentType = null;
let activeSlides = [];

function showConfigModal() {
  if (configModal) {
    // Reset selections
    selectedUserType = null;
    selectedContentType = null;
    
    // Hide content type options
    if (contentTypeSelection) {
      contentTypeSelection.classList.add('hidden');
    }
    
    // Reset role button states
    const roleBtns = configModal.querySelectorAll('.role-btn');
    roleBtns.forEach(btn => btn.classList.remove('selected'));
    
    configModal.classList.remove('hidden');
    document.body.style.overflow = 'hidden';
  }
}

function hideConfigModal() {
  if (configModal) {
    configModal.classList.add('hidden');
    document.body.style.overflow = '';
  }
}

// Handle user type selection
function handleUserTypeSelection(userType) {
  selectedUserType = userType;
  
  // Update button states
  const roleBtns = configModal.querySelectorAll('.role-btn');
  roleBtns.forEach(btn => {
    if (btn.dataset.userType === userType) {
      btn.classList.add('selected');
    } else {
      btn.classList.remove('selected');
    }
  });
  
  // Show content type options
  if (contentTypeSelection) {
    contentTypeSelection.classList.remove('hidden');
  }
}

// Handle content type selection
function handleContentTypeSelection(contentType) {
  selectedContentType = contentType;
  const configKey = `${selectedUserType}-${contentType}`;
  activeSlides = SLIDE_CONFIGURATIONS[configKey] || [1, 2, 3, 4, 5, 10];
  hideConfigModal();
  updateProfileBadge();
  showEbookFeaturesModal(true);
}

// ============================================
// eBook Features Modal
// ============================================
const EBOOK_FEATURES_MODAL_KEY = 'ebookFeaturesModalShown';
const ebookFeaturesModal = document.getElementById('ebookFeaturesModal');
const ebookSlideshowBackBtn = document.getElementById('ebookSlideshowBackBtn');
const ebookSlideshowNextBtn = document.getElementById('ebookSlideshowNextBtn');
let ebookCurrentSlide = 0; // Index in activeSlides array
let ebookTotalSlides = 10;

// Update profile badge display
function updateProfileBadge() {
  const profileBadge = document.getElementById('profileBadge');
  if (!profileBadge || !selectedUserType || !selectedContentType) return;
  
  // Capitalize first letter
  const userTypeDisplay = selectedUserType.charAt(0).toUpperCase() + selectedUserType.slice(1);
  
  // Format content type
  let contentTypeDisplay = selectedContentType;
  if (contentTypeDisplay === 'ebook') {
    contentTypeDisplay = 'eBook';
  } else if (contentTypeDisplay === 'ai') {
    contentTypeDisplay = 'AI';
  } else if (contentTypeDisplay === 'digital-literacy') {
    contentTypeDisplay = 'Digital Literacy';
  } else if (contentTypeDisplay === 'mpah-maths') {
    contentTypeDisplay = 'MPAH Maths 4E';
  }
  
  // Get total slides count from activeSlides array
  const totalSlides = activeSlides.length > 0 ? activeSlides.length : 0;
  
  profileBadge.textContent = `${userTypeDisplay} > ${contentTypeDisplay} (Total Slides: ${totalSlides})`;
  profileBadge.style.display = 'block';
}

function showEbookFeaturesModal(forceShow = false) {
  const hasSeenModal = localStorage.getItem(EBOOK_FEATURES_MODAL_KEY) === 'true';
  
  // Show if forced or if user hasn't seen it before
  if (ebookFeaturesModal && (forceShow || !hasSeenModal)) {
    // Use default slides if no configuration selected
    if (activeSlides.length === 0) {
      activeSlides = [1, 2, 3, 4, 5, 10];
    }
    
    ebookCurrentSlide = 0; // Start at first slide in activeSlides
    ebookTotalSlides = activeSlides.length;
    updateEbookSlideDisplay();
    ebookFeaturesModal.classList.remove('hidden');
    document.body.style.overflow = 'hidden';
  }
}

function hideEbookFeaturesModal() {
  if (ebookFeaturesModal) {
    ebookFeaturesModal.classList.add('hidden');
    document.body.style.overflow = '';
    localStorage.setItem(EBOOK_FEATURES_MODAL_KEY, 'true');
    
    // Pause and reset video when closing modal
    const explicoVideo = document.getElementById('explicoVideo');
    if (explicoVideo) {
      explicoVideo.pause();
      explicoVideo.currentTime = 0; // Reset to beginning
    }
    
    ebookCurrentSlide = 0;
    updateEbookSlideDisplay();
  }
}

function updateEbookSlideDisplay() {
  if (activeSlides.length === 0) {
    activeSlides = [1, 2, 3, 4, 5, 10];
  }
  
  const currentSlideNumber = activeSlides[ebookCurrentSlide];
  
  // Update slides visibility - hide all first
  const slides = ebookFeaturesModal.querySelectorAll('.slideshow-slide');
  slides.forEach((slide) => {
    slide.classList.remove('active');
  });
  
  // Show only the current active slide
  const currentSlide = ebookFeaturesModal.querySelector(`[data-slide="${currentSlideNumber}"]`);
  if (currentSlide) {
    currentSlide.classList.add('active');
  }

  // Update progress dots - rebuild them based on active slides
  updateProgressDots();

  // Pause video when navigating away from slide 8 (Smart Features at Your Fingertips)
  const explicoVideo = document.getElementById('explicoVideo');
  if (explicoVideo && currentSlideNumber !== 8) {
    explicoVideo.pause();
  }

  // Update button states
  if (ebookSlideshowBackBtn) {
    if (ebookCurrentSlide === 0) {
      ebookSlideshowBackBtn.textContent = 'Close';
      ebookSlideshowBackBtn.disabled = false;
    } else {
      ebookSlideshowBackBtn.textContent = 'Back';
      ebookSlideshowBackBtn.disabled = false;
    }
  }

  if (ebookSlideshowNextBtn) {
    if (ebookCurrentSlide === ebookTotalSlides - 1) {
      ebookSlideshowNextBtn.textContent = "Let's Start";
    } else {
      ebookSlideshowNextBtn.textContent = 'Next';
    }
  }
}

function updateProgressDots() {
  const progressContainer = ebookFeaturesModal.querySelector('.slideshow-progress');
  if (!progressContainer) return;
  
  // Clear existing dots
  progressContainer.innerHTML = '';
  
  // Create dots based on active slides
  activeSlides.forEach((slideNum, index) => {
    const dot = document.createElement('span');
    dot.className = 'slideshow-dot';
    dot.dataset.slide = slideNum;
    if (index === ebookCurrentSlide) {
      dot.classList.add('active');
    }
    dot.addEventListener('click', () => {
      ebookCurrentSlide = index;
      updateEbookSlideDisplay();
    });
    progressContainer.appendChild(dot);
  });
}

function navigateEbookSlideshow(direction) {
  if (direction === 'next') {
    if (ebookCurrentSlide < ebookTotalSlides - 1) {
      ebookCurrentSlide++;
      updateEbookSlideDisplay();
    } else {
      // On last slide, close modal
      hideEbookFeaturesModal();
    }
  } else if (direction === 'back') {
    if (ebookCurrentSlide === 0) {
      // On first slide, close the modal
      hideEbookFeaturesModal();
    } else if (ebookCurrentSlide > 0) {
      ebookCurrentSlide--;
      updateEbookSlideDisplay();
    }
  }
}

// Handle slideshow navigation
if (ebookSlideshowBackBtn) {
  ebookSlideshowBackBtn.addEventListener('click', () => navigateEbookSlideshow('back'));
}

if (ebookSlideshowNextBtn) {
  ebookSlideshowNextBtn.addEventListener('click', () => navigateEbookSlideshow('next'));
}

// Handle clicking on progress dots - handled dynamically in updateProgressDots()

// Setup config modal event listeners
if (configModal) {
  // User type buttons
  const userTypeBtns = configModal.querySelectorAll('[data-user-type]');
  userTypeBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      handleUserTypeSelection(btn.dataset.userType);
    });
  });
  
  // Content type buttons
  const contentTypeBtns = configModal.querySelectorAll('[data-content-type]');
  contentTypeBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      handleContentTypeSelection(btn.dataset.contentType);
    });
  });
}

// Initialize on page load
document.addEventListener('DOMContentLoaded', () => {
  initEbookReader();
  
  // Video Player Controls for Explico video
  const explicoVideo = document.getElementById('explicoVideo');
  const playPauseBtn = document.getElementById('playPauseBtn');
  const seekBar = document.getElementById('seekBar');
  const seekBarProgress = document.getElementById('seekBarProgress');
  const currentTimeDisplay = document.getElementById('currentTime');
  const totalTimeDisplay = document.getElementById('totalTime');
  const fullscreenBtn = document.getElementById('fullscreenBtn');

  // Format time in MM:SS
  function formatTime(seconds) {
    if (isNaN(seconds)) return '0:00';
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  }

  // Play/Pause functionality
  if (playPauseBtn && explicoVideo) {
    playPauseBtn.addEventListener('click', () => {
      if (explicoVideo.paused) {
        explicoVideo.play();
        playPauseBtn.innerHTML = '<svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor"><path d="M6 4h4v16H6V4zm8 0h4v16h-4V4z"/></svg>';
        playPauseBtn.setAttribute('aria-label', 'Pause');
      } else {
        explicoVideo.pause();
        playPauseBtn.innerHTML = '<svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor"><path d="M8 5v14l11-7z"/></svg>';
        playPauseBtn.setAttribute('aria-label', 'Play');
      }
    });
  }

  // Update time display and seek bar
  if (explicoVideo) {
    explicoVideo.addEventListener('loadedmetadata', () => {
      totalTimeDisplay.textContent = formatTime(explicoVideo.duration);
      seekBar.max = explicoVideo.duration;
    });

    explicoVideo.addEventListener('timeupdate', () => {
      currentTimeDisplay.textContent = formatTime(explicoVideo.currentTime);
      seekBar.value = explicoVideo.currentTime;
      
      // Update progress bar
      const percentage = (explicoVideo.currentTime / explicoVideo.duration) * 100;
      seekBarProgress.style.width = `${percentage}%`;
    });

    // Seek functionality
    seekBar.addEventListener('input', () => {
      explicoVideo.currentTime = seekBar.value;
    });

    // Reset play button when video ends
    explicoVideo.addEventListener('ended', () => {
      playPauseBtn.innerHTML = '<svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor"><path d="M8 5v14l11-7z"/></svg>';
      playPauseBtn.setAttribute('aria-label', 'Play');
    });
  }

  // Fullscreen functionality
  if (fullscreenBtn && explicoVideo) {
    fullscreenBtn.addEventListener('click', () => {
      const videoContainer = explicoVideo.closest('.video-player-container');
      
      if (!document.fullscreenElement) {
        if (videoContainer.requestFullscreen) {
          videoContainer.requestFullscreen();
        } else if (videoContainer.webkitRequestFullscreen) {
          videoContainer.webkitRequestFullscreen();
        } else if (videoContainer.msRequestFullscreen) {
          videoContainer.msRequestFullscreen();
        }
      } else {
        if (document.exitFullscreen) {
          document.exitFullscreen();
        } else if (document.webkitExitFullscreen) {
          document.webkitExitFullscreen();
        } else if (document.msExitFullscreen) {
          document.msExitFullscreen();
        }
      }
    });
  }
  
  // ============================================
  // Slide 11: Join Class Code Input Functionality
  // ============================================
  const slide11 = document.querySelector('[data-slide="11"]');
  if (slide11) {
    const clearBtn = document.getElementById('clearClassCodeSlide');
    const submitBtn = document.getElementById('submitClassCodeSlide');
    const inputs = slide11.querySelectorAll('.class-code-input');
    
    // Clear button
    if (clearBtn) {
      clearBtn.addEventListener('click', () => {
        inputs.forEach(input => input.value = '');
        inputs[0].focus();
      });
    }
    
    // Submit button
    if (submitBtn) {
      submitBtn.addEventListener('click', () => {
        const code = Array.from(inputs).map(input => input.value).join('');
        
        if (code.length === 8) {
          alert(`Class code ${code} submitted! (This is a demo)`);
        } else {
          alert('Please enter all 8 characters of the class code.');
        }
      });
    }
    
    // Input handlers
    inputs.forEach((input, index) => {
      // Handle paste
      input.addEventListener('paste', (e) => {
        e.preventDefault();
        const pastedData = e.clipboardData.getData('text').trim().toUpperCase();
        
        // Fill inputs with pasted data
        for (let i = 0; i < Math.min(pastedData.length, 8); i++) {
          if (inputs[i]) {
            inputs[i].value = pastedData[i];
          }
        }
        
        // Focus on the next empty input or the last one
        const nextEmptyIndex = Array.from(inputs).findIndex(inp => !inp.value);
        if (nextEmptyIndex !== -1) {
          inputs[nextEmptyIndex].focus();
        } else {
          inputs[7].focus();
        }
      });
      
      // Handle input
      input.addEventListener('input', (e) => {
        const value = e.target.value.toUpperCase();
        
        if (value.length > 0) {
          e.target.value = value[value.length - 1]; // Keep only the last char
          
          // Move to next input
          if (index < inputs.length - 1) {
            inputs[index + 1].focus();
          }
        }
      });
      
      // Handle backspace
      input.addEventListener('keydown', (e) => {
        if (e.key === 'Backspace' && !e.target.value && index > 0) {
          inputs[index - 1].focus();
        }
      });
    });
  }
  
  // Show config modal on every page load
  setTimeout(() => {
    showConfigModal(); // Show configuration menu first
  }, 500);
  
  // Initialize Help Support Modal
  initHelpSupportModal();
  
  // Help button event listener
  const helpBtn = document.getElementById('helpBtn');
  if (helpBtn) {
    helpBtn.addEventListener('click', () => {
      openHelpSupportModal();
    });
  }
});

// ============================================
// HELP SUPPORT MODAL
// ============================================
function initHelpSupportModal() {
  const helpSupportModal = document.getElementById('helpSupportModal');
  const closeHelpSupportModal = document.getElementById('closeHelpSupportModal');
  const expandHelpModal = document.getElementById('expandHelpModal');
  const feedbackFormModal = document.getElementById('feedbackFormModal');
  const closeFeedbackModal = document.getElementById('closeFeedbackModal');
  const reportIssueBtn = document.getElementById('reportIssueBtn');
  const feedbackCancelBtn = document.getElementById('feedbackCancelBtn');
  const feedbackForm = document.getElementById('feedbackForm');
  const faqItems = document.querySelectorAll('.faq-item');
  
  if (!helpSupportModal) return;
  
  // Expand/Collapse functionality
  if (expandHelpModal) {
    expandHelpModal.addEventListener('click', () => {
      const modal = document.querySelector('.help-support-modal');
      const supportFrame = document.getElementById('supportPageFrame');
      const isExpanded = modal.classList.contains('expanded');
      
      if (isExpanded) {
        // Collapse to normal size
        modal.classList.remove('expanded');
        expandHelpModal.classList.remove('collapse-mode');
        expandHelpModal.setAttribute('title', 'Expand');
        expandHelpModal.innerHTML = `
          <svg viewBox="0 0 24 24" fill="none">
            <path d="M15 3h6v6M9 21H3v-6M21 3l-7 7M3 21l7-7" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
        `;
      } else {
        // Expand to 90% screen
        modal.classList.add('expanded');
        expandHelpModal.classList.add('collapse-mode');
        expandHelpModal.setAttribute('title', 'Collapse');
        expandHelpModal.innerHTML = `
          <svg viewBox="0 0 24 24" fill="none">
            <path d="M9 3H3v6M21 9V3h-6M9 21H3v-6M21 15v6h-6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
        `;
        
        // Load support page in iframe if not already loaded
        if (supportFrame && (!supportFrame.src || supportFrame.src === '' || supportFrame.src === window.location.href)) {
          supportFrame.src = 'support.html';
        }
      }
    });
  }
  
  // FAQ accordion functionality
  faqItems.forEach(item => {
    const question = item.querySelector('.faq-question');
    question.addEventListener('click', () => {
      const isActive = item.classList.contains('active');
      
      // Close all other FAQs
      faqItems.forEach(otherItem => {
        if (otherItem !== item) {
          otherItem.classList.remove('active');
        }
      });
      
      // Toggle current FAQ
      item.classList.toggle('active');
    });
  });
  
  // Search functionality (basic)
  const supportSearchInput = document.getElementById('supportSearchInput');
  const supportSearchBtn = document.querySelector('.support-search-btn');
  
  if (supportSearchBtn && supportSearchInput) {
    supportSearchBtn.addEventListener('click', () => {
      const searchTerm = supportSearchInput.value.trim();
      if (searchTerm) {
        alert(`Search functionality for "${searchTerm}" coming soon!`);
      }
    });
    
    supportSearchInput.addEventListener('keypress', (e) => {
      if (e.key === 'Enter') {
        const searchTerm = supportSearchInput.value.trim();
        if (searchTerm) {
          alert(`Search functionality for "${searchTerm}" coming soon!`);
        }
      }
    });
  }
  
  // Close help support modal
  if (closeHelpSupportModal) {
    closeHelpSupportModal.addEventListener('click', closeHelpSupportModalFunc);
  }
  
  // Close modal when clicking overlay
  helpSupportModal.addEventListener('click', (e) => {
    if (e.target.id === 'helpSupportModal') {
      closeHelpSupportModalFunc();
    }
  });
  
  // Report issue button
  if (reportIssueBtn) {
    reportIssueBtn.addEventListener('click', () => {
      openFeedbackFormModal();
    });
  }
  
  // Close feedback modal
  if (closeFeedbackModal) {
    closeFeedbackModal.addEventListener('click', closeFeedbackFormModalFunc);
  }
  
  if (feedbackCancelBtn) {
    feedbackCancelBtn.addEventListener('click', closeFeedbackFormModalFunc);
  }
  
  // Close feedback modal when clicking overlay
  if (feedbackFormModal) {
    feedbackFormModal.addEventListener('click', (e) => {
      if (e.target.id === 'feedbackFormModal') {
        closeFeedbackFormModalFunc();
      }
    });
  }
  
  // Handle feedback form submission
  if (feedbackForm) {
    feedbackForm.addEventListener('submit', (e) => {
      e.preventDefault();
      
      const subject = document.getElementById('feedbackSubject').value;
      const category = document.getElementById('feedbackCategory').value;
      const message = document.getElementById('feedbackMessage').value;
      
      // Show alert for demo purposes
      alert('Thank you for your feedback! We have received your issue report and will review it shortly.');
      
      // Reset form
      feedbackForm.reset();
      closeFeedbackFormModalFunc();
      
      console.log('Issue reported:', { subject, category, message });
    });
  }
}

function openHelpSupportModal() {
  closeAllEbookModals(['helpSupportModal']);
  
  const helpSupportModal = document.getElementById('helpSupportModal');
  if (helpSupportModal) {
    helpSupportModal.classList.add('active');
    
    // Close all open FAQs
    const faqItems = document.querySelectorAll('.faq-item');
    faqItems.forEach(item => item.classList.remove('active'));
    
    // Clear search input
    const supportSearchInput = document.getElementById('supportSearchInput');
    if (supportSearchInput) {
      supportSearchInput.value = '';
    }
  }
}

function closeHelpSupportModalFunc() {
  const helpSupportModal = document.getElementById('helpSupportModal');
  const modal = document.querySelector('.help-support-modal');
  const expandHelpModal = document.getElementById('expandHelpModal');
  
  if (helpSupportModal) {
    helpSupportModal.classList.remove('active');
  }
  
  // Reset to normal state
  if (modal) {
    modal.classList.remove('expanded');
  }
  
  if (expandHelpModal) {
    expandHelpModal.classList.remove('collapse-mode');
    expandHelpModal.setAttribute('title', 'Expand');
    expandHelpModal.innerHTML = `
      <svg viewBox="0 0 24 24" fill="none">
        <path d="M15 3h6v6M9 21H3v-6M21 3l-7 7M3 21l7-7" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
      </svg>
    `;
  }
}

function openFeedbackFormModal() {
  // Keep Help Support Modal open (parent-child relationship)
  closeAllEbookModals(['feedbackFormModal', 'helpSupportModal']);
  
  const feedbackFormModal = document.getElementById('feedbackFormModal');
  if (feedbackFormModal) {
    feedbackFormModal.classList.add('active');
  }
}

function closeFeedbackFormModalFunc() {
  const feedbackFormModal = document.getElementById('feedbackFormModal');
  if (feedbackFormModal) {
    feedbackFormModal.classList.remove('active');
  }
}

// Close all ebook modals helper function
function closeAllEbookModals(except = []) {
  const modals = [
    'helpSupportModal',
    'feedbackFormModal',
    'configModal',
    'welcomeModal'
  ];
  
  modals.forEach(modalId => {
    if (except.includes(modalId)) return;
    
    const modal = document.getElementById(modalId);
    if (modal) {
      modal.classList.remove('active');
    }
  });
}
