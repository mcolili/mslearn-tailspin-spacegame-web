// ============================================
// LOGIN PAGE FUNCTIONALITY
// ============================================

// State management
let validatedAccessCode = '';
let uploadedFile = null;
let currentSlide = 0;
let carouselInterval = null;

// ============================================
// DOM ELEMENTS
// ============================================

// Carousel Elements
const carouselSlides = document.querySelectorAll('.carousel-slide');
const carouselPrev = document.getElementById('carouselPrev');
const carouselNext = document.getElementById('carouselNext');
const carouselIndicators = document.querySelectorAll('.carousel-indicator');

// Buttons and Links
const loginForm = document.getElementById('loginForm');
const accessCodeBtn = document.getElementById('accessCodeBtn');
const contactSupportLink = document.getElementById('contactSupportLink');

// Login Form Elements
const userIdInput = document.getElementById('userId');
const schoolIdGroup = document.getElementById('schoolIdGroup');
const schoolIdInput = document.getElementById('schoolId');

// Modal Elements
const modalOverlay = document.getElementById('modalOverlay');
const accessCodeModal = document.getElementById('accessCodeModal');

// Modal Section Elements
const accessCodeSection = document.getElementById('accessCodeSection');
const registrationSection = document.getElementById('registrationSection');

// Access Code Elements
const closeAccessCodeModal = document.getElementById('closeAccessCodeModal');
const cancelAccessCode = document.getElementById('cancelAccessCode');
const accessCodeForm = document.getElementById('accessCodeForm');
const accessCodeInput = document.getElementById('accessCodeInput');
const accessCodeError = document.getElementById('accessCodeError');
const accessCodeSuccess = document.getElementById('accessCodeSuccess');

// Registration Form Elements
const cancelRegistration = document.getElementById('cancelRegistration');
const registrationForm = document.getElementById('registrationForm');
const displayAccessCode = document.getElementById('displayAccessCode');

// User Type Radio Buttons
const userTypeRadios = document.querySelectorAll('input[name="userType"]');
const newUserFields = document.getElementById('newUserFields');
const existingUserFields = document.getElementById('existingUserFields');

// Role Radio Buttons
const roleRadios = document.querySelectorAll('input[name="role"]');
const teacherIdUploadGroup = document.getElementById('teacherIdUploadGroup');
const teacherIdUpload = document.getElementById('teacherIdUpload');
const uploadFileName = document.getElementById('uploadFileName');
const uploadError = document.getElementById('uploadError');

// Form Inputs (New User)
const emailInput = document.getElementById('email');
const emailInfo = document.getElementById('emailInfo');
const countrySelect = document.getElementById('country');
const newPasswordInput = document.getElementById('newPassword');
const confirmPasswordInput = document.getElementById('confirmPassword');
const agreeTermsCheckbox = document.getElementById('agreeTerms');
const agreeMarketingCheckbox = document.getElementById('agreeMarketing');

// Form Inputs (Existing User)
const existingUserIdInput = document.getElementById('existingUserId');
const existingPasswordInput = document.getElementById('existingPassword');

// Error Elements
const emailError = document.getElementById('emailError');
const countryError = document.getElementById('countryError');
const passwordError = document.getElementById('passwordError');
const confirmPasswordError = document.getElementById('confirmPasswordError');
const existingUserIdError = document.getElementById('existingUserIdError');
const existingPasswordError = document.getElementById('existingPasswordError');

// Submit Button
const submitRegistration = document.getElementById('submitRegistration');

// Success Modal Elements
const successModal = document.getElementById('successModal');
const closeSuccessModal = document.getElementById('closeSuccessModal');
const successOkBtn = document.getElementById('successOkBtn');

// ============================================
// INITIALIZATION
// ============================================

document.addEventListener('DOMContentLoaded', () => {
  initializeEventListeners();
  initializeCarousel();
  initializeImageErrorHandlers();
});

// ============================================
// EVENT LISTENERS
// ============================================

function initializeEventListeners() {
  // Standard Login Form
  if (loginForm) loginForm.addEventListener('submit', handleLogin);
  
  // User ID input - toggle School ID field
  if (userIdInput) userIdInput.addEventListener('input', handleUserIdInput);

  // Access Code Button - Now handled in inline registration flow section
  // accessCodeBtn.addEventListener('click', openAccessCodeModal);

  // Access Code Modal
  if (closeAccessCodeModal) closeAccessCodeModal.addEventListener('click', closeModal);
  if (cancelAccessCode) cancelAccessCode.addEventListener('click', closeModal);
  if (accessCodeForm) accessCodeForm.addEventListener('submit', handleAccessCodeValidation);

  // Registration Form
  if (cancelRegistration) cancelRegistration.addEventListener('click', closeModal);
  if (registrationForm) registrationForm.addEventListener('submit', handleRegistrationSubmit);

  // User Type Toggle
  if (userTypeRadios && userTypeRadios.length > 0) {
    userTypeRadios.forEach(radio => {
      radio.addEventListener('change', handleUserTypeChange);
    });
  }

  // Role Toggle
  if (roleRadios && roleRadios.length > 0) {
    roleRadios.forEach(radio => {
      radio.addEventListener('change', handleRoleChange);
    });
  }

  // File Upload
  if (teacherIdUpload) teacherIdUpload.addEventListener('change', handleFileUpload);

  // Real-time Validation
  if (emailInput) emailInput.addEventListener('blur', validateEmail);
  if (emailInput) emailInput.addEventListener('input', handleEmailInput);
  if (newPasswordInput) newPasswordInput.addEventListener('input', validatePassword);
  if (confirmPasswordInput) confirmPasswordInput.addEventListener('input', validateConfirmPassword);

  // Close modal when clicking outside
  if (modalOverlay) {
    modalOverlay.addEventListener('click', (e) => {
      if (e.target === modalOverlay) {
        closeModal();
      }
    });
  }

  // Contact Support (placeholder)
  if (contactSupportLink) {
    contactSupportLink.addEventListener('click', (e) => {
      e.preventDefault();
      alert('Please contact support at support@mceducation.com or call +65 6213 9300');
    });
  }

  // Success Modal
  if (closeSuccessModal) {
    closeSuccessModal.addEventListener('click', closeSuccessModal_handler);
  }
  if (successOkBtn) {
    successOkBtn.addEventListener('click', closeSuccessModal_handler);
  }
}

// ============================================
// CAROUSEL FUNCTIONALITY
// ============================================

function initializeCarousel() {
  if (!carouselSlides || carouselSlides.length === 0) return;
  
  // Arrow buttons
  if (carouselPrev) {
    carouselPrev.addEventListener('click', () => {
      changeSlide(currentSlide - 1);
      resetCarouselTimer();
    });
  }
  
  if (carouselNext) {
    carouselNext.addEventListener('click', () => {
      changeSlide(currentSlide + 1);
      resetCarouselTimer();
    });
  }
  
  // Indicator buttons
  carouselIndicators.forEach((indicator, index) => {
    indicator.addEventListener('click', () => {
      changeSlide(index);
      resetCarouselTimer();
    });
  });
  
  // Auto-advance every 5 seconds
  startCarouselTimer();
}

function changeSlide(newIndex) {
  if (!carouselSlides || carouselSlides.length === 0) return;
  
  // Wrap around
  if (newIndex < 0) {
    newIndex = carouselSlides.length - 1;
  } else if (newIndex >= carouselSlides.length) {
    newIndex = 0;
  }
  
  // Remove active class from current slide and indicator
  carouselSlides[currentSlide].classList.remove('active');
  if (carouselIndicators[currentSlide]) {
    carouselIndicators[currentSlide].classList.remove('active');
  }
  
  // Add active class to new slide and indicator
  currentSlide = newIndex;
  carouselSlides[currentSlide].classList.add('active');
  if (carouselIndicators[currentSlide]) {
    carouselIndicators[currentSlide].classList.add('active');
  }
}

function startCarouselTimer() {
  carouselInterval = setInterval(() => {
    changeSlide(currentSlide + 1);
  }, 5000);
}

function resetCarouselTimer() {
  clearInterval(carouselInterval);
  startCarouselTimer();
}

// ============================================
// IMAGE ERROR HANDLERS (Security Fix)
// ============================================

function initializeImageErrorHandlers() {
  // Add error handlers to all carousel images with fallback sources
  document.querySelectorAll('.carousel-image').forEach(img => {
    img.addEventListener('error', function() {
      const fallbackSrc = this.getAttribute('data-fallback');
      if (fallbackSrc && this.src !== fallbackSrc) {
        this.src = fallbackSrc;
      }
    });
  });
}

// ============================================
// STANDARD LOGIN FUNCTIONALITY
// ============================================

function handleUserIdInput() {
  const userId = userIdInput.value.trim();
  
  // Check if the input looks like an email (contains @ and .)
  const isEmail = userId.includes('@') && userId.includes('.');
  
  // Hide School ID field if email is detected, show it otherwise
  if (isEmail) {
    // Add a class to smoothly hide the field
    schoolIdGroup.classList.add('hidden');
    setTimeout(() => {
      schoolIdGroup.style.display = 'none';
    }, 300); // Wait for transition
    schoolIdInput.removeAttribute('required');
    schoolIdInput.value = '';
  } else {
    schoolIdGroup.style.display = 'flex';
    // Remove hidden class after display is set
    setTimeout(() => {
      schoolIdGroup.classList.remove('hidden');
    }, 10);
  }
}

function handleLogin(e) {
  e.preventDefault();
  
  const userId = document.getElementById('userId').value;
  const password = document.getElementById('password').value;
  const rememberMe = document.getElementById('rememberMe').checked;

  // Simulate login validation
  if (!userId || !password) {
    showAlert('Please enter both User ID and Password', 'error');
    return;
  }

  // In a real application, this would make an API call
  console.log('Login attempt:', { userId, rememberMe });
  
  // Redirect to main page after short delay
  setTimeout(() => {
    window.location.href = 'index.html';
  }, 1500);
}

// ============================================
// MODAL MANAGEMENT
// ============================================

function openAccessCodeModal() {
  modalOverlay.classList.add('active');
  accessCodeModal.classList.add('active');
  accessCodeInput.value = '';
  
  // Show access code section, hide registration section
  accessCodeSection.style.display = 'block';
  registrationSection.style.display = 'none';
  
  // Reset access code form
  accessCodeInput.value = '';
  accessCodeError.textContent = '';
  accessCodeError.classList.remove('visible');
  accessCodeSuccess.textContent = '';
  accessCodeSuccess.classList.remove('visible');
  accessCodeInput.focus();
  
  // Reset the validate button
  const btn = accessCodeForm.querySelector('button[type="submit"]');
  btn.textContent = 'Validate';
  btn.onclick = null;
}

function showRegistrationForm() {
  // Hide access code section
  accessCodeSection.style.display = 'none';
  
  // Show registration section
  registrationSection.style.display = 'block';
  displayAccessCode.textContent = validatedAccessCode;
  
  // Reset form
  registrationForm.reset();
  clearAllErrors();
  
  // Set default state (New User, Student)
  document.querySelector('input[name="userType"][value="new"]').checked = true;
  document.querySelector('input[name="role"][value="student"]').checked = true;
  handleUserTypeChange();
  handleRoleChange();
}

function closeModal() {
  modalOverlay.classList.remove('active');
  accessCodeModal.classList.remove('active');
  
  // Reset section visibility
  accessCodeSection.style.display = 'block';
  registrationSection.style.display = 'none';
  
  // Reset states
  validatedAccessCode = '';
  uploadedFile = null;
  
  // Reset forms
  accessCodeForm.reset();
  registrationForm.reset();
  clearAllErrors();
  
  // Reset the validate button
  const btn = accessCodeForm.querySelector('button[type="submit"]');
  btn.textContent = 'Validate';
  btn.onclick = null;
}

// ============================================
// ACCESS CODE VALIDATION
// ============================================

function handleAccessCodeValidation(e) {
  e.preventDefault();
  
  const code = accessCodeInput.value.trim();
  
  // Hide previous messages
  accessCodeError.classList.remove('visible');
  accessCodeSuccess.classList.remove('visible');
  
  if (!code) {
    showAccessCodeError('Please enter an access code');
    return;
  }

  // Simulate API validation (in real app, this would be an API call)
  validateAccessCode(code);
}

function validateAccessCode(code) {
  // Simulate async validation
  const btn = accessCodeForm.querySelector('button[type="submit"]');
  btn.disabled = true;
  btn.textContent = 'Validating...';
  
  setTimeout(() => {
    // Simple validation logic (replace with real API call)
    // For demo purposes, accept codes that are 8+ characters alphanumeric
    const isValid = /^[A-Za-z0-9]{8,}$/.test(code);
    
    btn.disabled = false;
    btn.textContent = 'Validate';
    
    if (isValid) {
      validatedAccessCode = code.toUpperCase();
      showAccessCodeSuccess('Access code is valid!');
      
      // Automatically show registration form after brief delay
      setTimeout(() => {
        showRegistrationForm();
      }, 800);
    } else {
      showAccessCodeError('Invalid access code. Please check and try again.');
      validatedAccessCode = '';
    }
  }, 1000);
}

function showAccessCodeError(message) {
  accessCodeError.textContent = message;
  accessCodeError.classList.add('visible');
  accessCodeInput.focus();
}

function showAccessCodeSuccess(message) {
  accessCodeSuccess.textContent = message;
  accessCodeSuccess.classList.add('visible');
}

// ============================================
// USER TYPE AND ROLE MANAGEMENT
// ============================================

function handleUserTypeChange() {
  const selectedType = document.querySelector('input[name="userType"]:checked').value;
  
  if (selectedType === 'new') {
    newUserFields.style.display = 'flex';
    existingUserFields.style.display = 'none';
    
    // Clear existing user fields
    existingUserIdInput.value = '';
    existingPasswordInput.value = '';
    clearError(existingUserIdError);
    clearError(existingPasswordError);
  } else {
    newUserFields.style.display = 'none';
    existingUserFields.style.display = 'flex';
    
    // Clear new user fields
    emailInput.value = '';
    countrySelect.value = '';
    newPasswordInput.value = '';
    confirmPasswordInput.value = '';
    teacherIdUpload.value = '';
    uploadFileName.textContent = 'Choose file or drag here';
    uploadedFile = null;
    clearAllNewUserErrors();
  }
}

function handleRoleChange() {
  const selectedRole = document.querySelector('input[name="role"]:checked').value;
  
  if (selectedRole === 'teacher') {
    teacherIdUploadGroup.style.display = 'block';
    // Make upload required for teachers
    teacherIdUpload.setAttribute('required', 'required');
  } else {
    teacherIdUploadGroup.style.display = 'none';
    teacherIdUpload.removeAttribute('required');
    teacherIdUpload.value = '';
    uploadFileName.textContent = 'Choose file or drag here';
    uploadedFile = null;
    clearError(uploadError);
  }
}

// ============================================
// FILE UPLOAD HANDLING
// ============================================

function handleFileUpload(e) {
  const file = e.target.files[0];
  clearError(uploadError);
  
  if (!file) {
    uploadFileName.textContent = 'Choose file or drag here';
    uploadedFile = null;
    return;
  }
  
  // Validate file type
  const allowedTypes = ['image/jpeg', 'image/jpg', 'image/png', 'application/pdf'];
  if (!allowedTypes.includes(file.type)) {
    showError(uploadError, 'Invalid file type. Please upload JPG, PNG, or PDF.');
    uploadFileName.textContent = 'Choose file or drag here';
    uploadedFile = null;
    e.target.value = '';
    return;
  }
  
  // Validate file size (1 MB = 1048576 bytes)
  const maxSize = 1048576;
  if (file.size > maxSize) {
    showError(uploadError, 'File size exceeds 1 MB. Please choose a smaller file.');
    uploadFileName.textContent = 'Choose file or drag here';
    uploadedFile = null;
    e.target.value = '';
    return;
  }
  
  // File is valid
  uploadedFile = file;
  uploadFileName.textContent = file.name;
  console.log('File uploaded:', file.name, 'Size:', (file.size / 1024).toFixed(2), 'KB');
}

// ============================================
// FORM VALIDATION
// ============================================

function validateEmail() {
  const email = emailInput.value.trim();
  clearError(emailError);
  
  if (!email) {
    showError(emailError, 'Email address is required');
    return false;
  }
  
  // Basic email validation
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email)) {
    showError(emailError, 'Please enter a valid email address');
    return false;
  }
  
  return true;
}

function handleEmailInput() {
  const email = emailInput.value.trim();
  
  // Show info message if there's a valid-looking email
  if (email && email.includes('@') && email.includes('.')) {
    emailInfo.classList.add('visible');
  } else {
    emailInfo.classList.remove('visible');
  }
}

function validatePassword() {
  const password = newPasswordInput.value;
  clearError(passwordError);
  
  if (!password) {
    return false;
  }
  
  // Minimum 8 characters
  if (password.length < 8) {
    showError(passwordError, 'Password must be at least 8 characters');
    return false;
  }
  
  // At least 1 letter
  if (!/[a-zA-Z]/.test(password)) {
    showError(passwordError, 'Password must contain at least 1 letter');
    return false;
  }
  
  // At least 1 number
  if (!/[0-9]/.test(password)) {
    showError(passwordError, 'Password must contain at least 1 number');
    return false;
  }
  
  // Only allowed characters
  if (!/^[a-zA-Z0-9_\-\.@]+$/.test(password)) {
    showError(passwordError, 'Password can only contain a-z, 0-9 and symbols _ - . @');
    return false;
  }
  
  // Check against User ID (if in existing user mode with access code)
  const userId = existingUserIdInput.value.trim();
  if (userId && password === userId) {
    showError(passwordError, 'Password must be different from User ID');
    return false;
  }
  
  // Validate confirm password if it has a value
  if (confirmPasswordInput.value) {
    validateConfirmPassword();
  }
  
  return true;
}

function validateConfirmPassword() {
  const password = newPasswordInput.value;
  const confirmPassword = confirmPasswordInput.value;
  clearError(confirmPasswordError);
  
  if (!confirmPassword) {
    return false;
  }
  
  if (password !== confirmPassword) {
    showError(confirmPasswordError, 'Passwords do not match');
    return false;
  }
  
  return true;
}

// ============================================
// REGISTRATION FORM SUBMISSION
// ============================================

function handleRegistrationSubmit(e) {
  e.preventDefault();
  
  const userType = document.querySelector('input[name="userType"]:checked').value;
  
  if (userType === 'existing') {
    submitExistingUserLogin();
  } else {
    submitNewUserRegistration();
  }
}

function submitExistingUserLogin() {
  clearError(existingUserIdError);
  clearError(existingPasswordError);
  
  const userId = existingUserIdInput.value.trim();
  const password = existingPasswordInput.value;
  
  let isValid = true;
  
  if (!userId) {
    showError(existingUserIdError, 'User ID is required');
    isValid = false;
  }
  
  if (!password) {
    showError(existingPasswordError, 'Password is required');
    isValid = false;
  }
  
  if (!isValid) {
    return;
  }
  
  // Disable submit button
  submitRegistration.disabled = true;
  submitRegistration.textContent = 'Logging in...';
  
  // Simulate API call
  setTimeout(() => {
    console.log('Existing user login with access code:', {
      userId,
      accessCode: validatedAccessCode
    });
    
    showAlert('Login successful! Access code linked to your account.', 'success');
    
    // Redirect to main page
    setTimeout(() => {
      window.location.href = 'index.html';
    }, 1500);
  }, 1000);
}

function submitNewUserRegistration() {
  clearAllNewUserErrors();
  
  const role = document.querySelector('input[name="role"]:checked').value;
  const email = emailInput.value.trim();
  const country = countrySelect.value;
  const password = newPasswordInput.value;
  const confirmPassword = confirmPasswordInput.value;
  const agreeTerms = agreeTermsCheckbox.checked;
  const agreeMarketing = agreeMarketingCheckbox.checked;
  
  let isValid = true;
  
  // Validate email
  if (!validateEmail()) {
    isValid = false;
  }
  
  // Validate country
  if (!country) {
    showError(countryError, 'Please select your country');
    isValid = false;
  }
  
  // Validate password
  if (!validatePassword()) {
    isValid = false;
  }
  
  // Validate confirm password
  if (!validateConfirmPassword()) {
    isValid = false;
  }
  
  // Validate teacher ID upload
  if (role === 'teacher' && !uploadedFile) {
    showError(uploadError, 'Please upload your school ID');
    isValid = false;
  }
  
  // Validate terms agreement
  if (!agreeTerms) {
    showAlert('Please agree to the Terms & Conditions to continue', 'error');
    isValid = false;
  }
  
  if (!isValid) {
    return;
  }
  
  // Disable submit button
  submitRegistration.disabled = true;
  submitRegistration.textContent = 'Creating account...';
  
  // Simulate API call
  setTimeout(() => {
    const registrationData = {
      accessCode: validatedAccessCode,
      role,
      email,
      country,
      password,
      agreeMarketing,
      teacherId: uploadedFile ? uploadedFile.name : null
    };
    
    console.log('New user registration:', registrationData);
    
    // Show success modal (it will hide the registration form)
    openSuccessModal();
    
    // Re-enable submit button for next use
    submitRegistration.disabled = false;
    submitRegistration.textContent = 'Submit';
  }, 1500);
}

// ============================================
// SUCCESS MODAL
// ============================================

function openSuccessModal() {
  // Hide access code modal
  accessCodeModal.classList.remove('active');
  
  // Show success modal (overlay is already active)
  modalOverlay.classList.add('active');
  successModal.classList.add('active');
}

function closeSuccessModal_handler() {
  // Redirect to index.html after successful registration
  console.log('closeSuccessModal_handler called');
  window.location.href = 'index.html';
}

// ============================================
// UTILITY FUNCTIONS
// ============================================

function showError(element, message) {
  element.textContent = message;
  element.classList.add('visible');
}

function clearError(element) {
  element.textContent = '';
  element.classList.remove('visible');
}

function clearAllErrors() {
  clearError(accessCodeError);
  clearError(accessCodeSuccess);
  clearAllNewUserErrors();
  clearError(existingUserIdError);
  clearError(existingPasswordError);
}

function clearAllNewUserErrors() {
  clearError(emailError);
  clearError(countryError);
  clearError(passwordError);
  clearError(confirmPasswordError);
  clearError(uploadError);
}

function showAlert(message, type = 'info') {
  // Simple alert for now - in production, this would be a custom toast notification
  alert(message);
}

// ============================================
// KEYBOARD SHORTCUTS
// ============================================

document.addEventListener('keydown', (e) => {
  // Close modal on Escape key
  if (e.key === 'Escape' && modalOverlay.classList.contains('active')) {
    closeModal();
  }
});

// ============================================
// DRAG AND DROP FOR FILE UPLOAD
// ============================================

if (teacherIdUploadGroup) {
  const fileUploadLabel = teacherIdUploadGroup.querySelector('.file-upload-label');
  
  ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
    fileUploadLabel.addEventListener(eventName, preventDefaults, false);
  });
  
  function preventDefaults(e) {
    e.preventDefault();
    e.stopPropagation();
  }
  
  ['dragenter', 'dragover'].forEach(eventName => {
    fileUploadLabel.addEventListener(eventName, () => {
      fileUploadLabel.style.borderColor = 'var(--primary)';
      fileUploadLabel.style.backgroundColor = 'rgba(47, 126, 216, 0.1)';
    }, false);
  });
  
  ['dragleave', 'drop'].forEach(eventName => {
    fileUploadLabel.addEventListener(eventName, () => {
      fileUploadLabel.style.borderColor = '';
      fileUploadLabel.style.backgroundColor = '';
    }, false);
  });
  
  fileUploadLabel.addEventListener('drop', (e) => {
    const dt = e.dataTransfer;
    const files = dt.files;
    
    if (files.length > 0) {
      teacherIdUpload.files = files;
      handleFileUpload({ target: teacherIdUpload });
    }
  }, false);
}

// Drag and drop for inline teacher upload
const inlineTeacherIdUploadGroup = document.getElementById('inlineTeacherIdUploadGroup');
if (inlineTeacherIdUploadGroup) {
  const inlineFileUploadLabel = inlineTeacherIdUploadGroup.querySelector('.file-upload-label');
  
  if (inlineFileUploadLabel) {
    ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
      inlineFileUploadLabel.addEventListener(eventName, preventDefaults, false);
    });
    
    function preventDefaults(e) {
      e.preventDefault();
      e.stopPropagation();
    }
    
    ['dragenter', 'dragover'].forEach(eventName => {
      inlineFileUploadLabel.addEventListener(eventName, () => {
        inlineFileUploadLabel.style.borderColor = 'var(--primary)';
        inlineFileUploadLabel.style.backgroundColor = 'rgba(47, 126, 216, 0.1)';
      }, false);
    });
    
    ['dragleave', 'drop'].forEach(eventName => {
      inlineFileUploadLabel.addEventListener(eventName, () => {
        inlineFileUploadLabel.style.borderColor = '';
        inlineFileUploadLabel.style.backgroundColor = '';
      }, false);
    });
    
    inlineFileUploadLabel.addEventListener('drop', (e) => {
      const dt = e.dataTransfer;
      const files = dt.files;
      const inlineUpload = document.getElementById('inlineTeacherIdUpload');
      
      if (files.length > 0 && inlineUpload) {
        inlineUpload.files = files;
        handleInlineFileUpload({ target: inlineUpload });
      }
    }, false);
  }
}

// ============================================
// INLINE REGISTRATION FLOW (V2 SPECIFIC)
// ============================================

let currentRole = '';
let inlineUploadedFile = null;
let resendTimer = null;
let resendCountdown = 0;

// State management for views
function showView(viewName) {
  const loginView = document.getElementById('loginView');
  const accessCodeView = document.getElementById('accessCodeView');
  const roleSelectionView = document.getElementById('roleSelectionView');
  const registrationView = document.getElementById('registrationView');
  const otpVerificationView = document.getElementById('otpVerificationView');
  const panelTitle = document.getElementById('panelTitle');
  const panelSubtitle = document.getElementById('panelSubtitle');
  const stepperContainer = document.getElementById('stepperContainer');
  
  // Hide all views
  if (loginView) loginView.style.display = 'none';
  if (accessCodeView) accessCodeView.style.display = 'none';
  if (roleSelectionView) roleSelectionView.style.display = 'none';
  if (registrationView) registrationView.style.display = 'none';
  if (otpVerificationView) otpVerificationView.style.display = 'none';
  
  // Show requested view and update title
  switch(viewName) {
    case 'login':
      if (loginView) loginView.style.display = 'block';
      panelTitle.textContent = 'Welcome to MCEduHub';
      panelSubtitle.textContent = 'Sign in to discover the joy of learning';
      if (stepperContainer) stepperContainer.style.display = 'none';
      updateStepper(0);
      break;
    case 'accessCode':
      if (accessCodeView) accessCodeView.style.display = 'block';
      panelTitle.textContent = 'Activate Access Code';
      panelSubtitle.textContent = 'Enter your code to get started';
      if (stepperContainer) stepperContainer.style.display = 'block';
      updateStepper(1);
      break;
    case 'roleSelection':
      if (roleSelectionView) roleSelectionView.style.display = 'block';
      panelTitle.textContent = 'Choose Your Role';
      panelSubtitle.textContent = 'Select your role to get started';
      if (stepperContainer) stepperContainer.style.display = 'block';
      updateStepper(2);
      break;
    case 'registration':
      if (registrationView) registrationView.style.display = 'block';
      panelTitle.textContent = currentRole === 'teacher' ? 'Teacher Registration' : 'Student Registration';
      panelSubtitle.textContent = 'Complete your registration information';
      if (stepperContainer) stepperContainer.style.display = 'block';
      updateStepper(3);
      break;
    case 'otpVerification':
      if (otpVerificationView) otpVerificationView.style.display = 'block';
      panelTitle.textContent = 'Verify Your Account';
      panelSubtitle.textContent = 'Enter the verification code sent to your email';
      if (stepperContainer) stepperContainer.style.display = 'block';
      updateStepper(4);
      // Start the resend OTP countdown timer
      startResendTimer();
      break;
  }
  
  // Scroll the active form container to top
  const activeContainer = document.querySelector('.login-form-container[style*="display: block"], .login-form-container:not([style*="display: none"])');
  if (activeContainer) {
    activeContainer.scrollTop = 0;
  }
}

// Update stepper state
function updateStepper(currentStep) {
  const steps = ['step1', 'step2', 'step3', 'step4'];
  
  steps.forEach((stepId, index) => {
    const stepElement = document.getElementById(stepId);
    if (stepElement) {
      stepElement.classList.remove('active', 'completed');
      
      if (index + 1 < currentStep) {
        stepElement.classList.add('completed');
      } else if (index + 1 === currentStep) {
        stepElement.classList.add('active');
      }
    }
  });
}

// Back to login view
function backToLogin() {
  // Clear the resend timer
  if (resendTimer) {
    clearInterval(resendTimer);
    resendTimer = null;
  }
  
  showView('login');
  currentRole = '';
  inlineUploadedFile = null;
  
  // Reset all forms
  const accessCodeForm = document.getElementById('accessCodeEntryForm');
  if (accessCodeForm) {
    accessCodeForm.reset();
    const errorElement = document.getElementById('accessCodeEntryError');
    if (errorElement) errorElement.textContent = '';
    
    // Clear all OTP inputs
    for (let i = 1; i <= 8; i++) {
      const input = document.getElementById('accessCode' + i);
      if (input) input.value = '';
    }
  }
  
  const registrationForm = document.getElementById('inlineRegistrationForm');
  if (registrationForm) {
    registrationForm.reset();
    clearInlineErrors();
    
    // Hide school fields
    const schoolDropdownGroup = document.getElementById('inlineSchoolDropdownGroup');
    const schoolNameGroup = document.getElementById('inlineSchoolNameGroup');
    const schoolAddressGroup = document.getElementById('inlineSchoolAddressGroup');
    if (schoolDropdownGroup) schoolDropdownGroup.style.display = 'none';
    if (schoolNameGroup) schoolNameGroup.style.display = 'none';
    if (schoolAddressGroup) schoolAddressGroup.style.display = 'none';
  }
  
  const otpForm = document.getElementById('otpVerificationForm');
  if (otpForm) {
    otpForm.reset();
    clearOTPError();
  }
}

// Back to role selection from registration form
function backToRoleSelection() {
  showView('roleSelection');
  
  // Clear registration form but keep currentRole
  const registrationForm = document.getElementById('inlineRegistrationForm');
  if (registrationForm) {
    registrationForm.reset();
    clearInlineErrors();
  }
  inlineUploadedFile = null;
}

// Back to access code from role selection
function backToAccessCode() {
  showView('accessCode');
  currentRole = '';
}

// Back to registration form from OTP verification
function backToRegistrationForm() {
  // Clear the resend timer
  if (resendTimer) {
    clearInterval(resendTimer);
    resendTimer = null;
  }
  
  showView('registration');
  
  // Clear OTP form
  const otpForm = document.getElementById('otpVerificationForm');
  if (otpForm) {
    otpForm.reset();
    clearOTPError();
  }
}

// Select role and move to registration
function selectRole(role) {
  currentRole = role;
  
  // Update radio selection
  const radios = document.querySelectorAll('input[name="roleSelection"]');
  radios.forEach(radio => {
    radio.checked = (radio.value === role);
  });
  
  // Show registration form
  setTimeout(() => {
    showRegistrationForm();
  }, 300);
}

function showRegistrationForm() {
  showView('registration');
  
  // Show/hide teacher upload field
  const teacherUploadGroup = document.getElementById('inlineTeacherIdUploadGroup');
  const teacherUpload = document.getElementById('inlineTeacherIdUpload');
  const schoolDropdownGroup = document.getElementById('inlineSchoolDropdownGroup');
  const schoolNameGroup = document.getElementById('inlineSchoolNameGroup');
  const schoolAddressGroup = document.getElementById('inlineSchoolAddressGroup');
  
  if (currentRole === 'teacher') {
    teacherUploadGroup.style.display = 'block';
    teacherUpload.setAttribute('required', 'required');
    
    // Trigger country change event if country is already selected
    const inlineCountry = document.getElementById('inlineCountry');
    if (inlineCountry && inlineCountry.value) {
      inlineCountry.dispatchEvent(new Event('change'));
    }
  } else {
    teacherUploadGroup.style.display = 'none';
    teacherUpload.removeAttribute('required');
    teacherUpload.value = '';
    inlineUploadedFile = null;
    
    // Hide school fields for students and remove required attributes
    const schoolDropdown = document.getElementById('inlineSchoolDropdown');
    const schoolName = document.getElementById('inlineSchoolName');
    const schoolAddress = document.getElementById('inlineSchoolAddress');
    
    if (schoolDropdownGroup) schoolDropdownGroup.style.display = 'none';
    if (schoolNameGroup) schoolNameGroup.style.display = 'none';
    if (schoolAddressGroup) schoolAddressGroup.style.display = 'none';
    
    // Remove required attributes so form can submit for students
    if (schoolDropdown) schoolDropdown.removeAttribute('required');
    if (schoolName) schoolName.removeAttribute('required');
    if (schoolAddress) schoolAddress.removeAttribute('required');
  }
}

// Update accessCodeBtn to redirect to register.html full page
const accessCodeBtnElement = document.getElementById('accessCodeBtn');
if (accessCodeBtnElement) {
  accessCodeBtnElement.addEventListener('click', (e) => {
    e.preventDefault();
    // Redirect to full page registration
    window.location.href = 'register.html';
  });
}

// Access Code Entry Form Handler with OTP-style inputs
const accessCodeEntryForm = document.getElementById('accessCodeEntryForm');
if (accessCodeEntryForm) {
  // Setup OTP input handling for access code
  const accessCodeInputs = [
    document.getElementById('accessCode1'),
    document.getElementById('accessCode2'),
    document.getElementById('accessCode3'),
    document.getElementById('accessCode4'),
    document.getElementById('accessCode5'),
    document.getElementById('accessCode6'),
    document.getElementById('accessCode7'),
    document.getElementById('accessCode8')
  ];
  
  accessCodeInputs.forEach((input, index) => {
    if (!input) return;
    
    input.addEventListener('input', (e) => {
      const value = e.target.value.toUpperCase();
      e.target.value = value;
      
      // Clear error on input
      const errorElement = document.getElementById('accessCodeEntryError');
      if (errorElement) errorElement.textContent = '';
      
      // Auto-focus next input if character entered
      if (value && index < accessCodeInputs.length - 1) {
        accessCodeInputs[index + 1].focus();
      }
    });
    
    input.addEventListener('keydown', (e) => {
      // Move to previous input on backspace if empty
      if (e.key === 'Backspace' && !e.target.value && index > 0) {
        accessCodeInputs[index - 1].focus();
      }
    });
    
    input.addEventListener('paste', (e) => {
      e.preventDefault();
      const pastedData = e.clipboardData.getData('text').toUpperCase().slice(0, 8);
      
      pastedData.split('').forEach((char, i) => {
        if (accessCodeInputs[i]) {
          accessCodeInputs[i].value = char;
        }
      });
      
      // Focus last filled input or last input
      const lastIndex = Math.min(pastedData.length, accessCodeInputs.length - 1);
      accessCodeInputs[lastIndex].focus();
    });
  });
  
  accessCodeEntryForm.addEventListener('submit', (e) => {
    e.preventDefault();
    
    const errorElement = document.getElementById('accessCodeEntryError');
    
    // Collect all values
    const code = accessCodeInputs.map(input => input.value).join('').toUpperCase();
    
    // Validate format: 8 alphanumeric characters
    const alphanumericPattern = /^[A-Z0-9]{8}$/;
    
    if (code.length !== 8) {
      errorElement.textContent = 'Please enter all 8 characters of your access code.';
      return;
    }
    
    if (!alphanumericPattern.test(code)) {
      errorElement.textContent = 'Access code must contain only letters and numbers.';
      return;
    }
    
    // Clear error
    errorElement.textContent = '';
    
    // For demo purposes, accept any valid format
    // In production, you would validate against server
    console.log('Access code validated:', code);
    
    // Move to role selection
    setTimeout(() => {
      showView('roleSelection');
    }, 300);
  });
}

// Inline Registration Form Handlers - Initialize on load
const inlineRegistrationForm = document.getElementById('inlineRegistrationForm');
const inlineTeacherIdUpload = document.getElementById('inlineTeacherIdUpload');
const inlineEmail = document.getElementById('inlineEmail');
const inlineNewPassword = document.getElementById('inlineNewPassword');
const inlineConfirmPassword = document.getElementById('inlineConfirmPassword');
const inlineCountry = document.getElementById('inlineCountry');
const inlineSchoolDropdown = document.getElementById('inlineSchoolDropdown');
const inlineSchoolName = document.getElementById('inlineSchoolName');
const inlineSchoolAddress = document.getElementById('inlineSchoolAddress');

// School data with addresses
const schoolData = {
  'Indo-ABC': 'Indo-ABC International School, Jl. Sudirman No. 123, Jakarta Selatan, DKI Jakarta 12190',
  'Indo-DEF': 'Indo-DEF Academy, Jl. Gatot Subroto No. 456, Bandung, Jawa Barat 40262',
  'Indo-GHI': 'Indo-GHI Education Center, Jl. Ahmad Yani No. 789, Surabaya, Jawa Timur 60234',
  'Indo-JKL': 'Indo-JKL Learning Institute, Jl. Diponegoro No. 321, Yogyakarta, DIY 55221'
};

if (inlineRegistrationForm) {
  inlineRegistrationForm.addEventListener('submit', handleInlineRegistrationSubmit);
}

if (inlineTeacherIdUpload) {
  inlineTeacherIdUpload.addEventListener('change', handleInlineFileUpload);
}

if (inlineEmail) {
  inlineEmail.addEventListener('blur', validateInlineEmail);
  inlineEmail.addEventListener('input', handleInlineEmailInput);
}

if (inlineNewPassword) {
  inlineNewPassword.addEventListener('input', validateInlinePassword);
}

if (inlineConfirmPassword) {
  inlineConfirmPassword.addEventListener('input', validateInlineConfirmPassword);
}

// Handle country selection for teachers (show school dropdown)
if (inlineCountry) {
  inlineCountry.addEventListener('change', (e) => {
    const selectedCountry = e.target.value;
    const schoolDropdownGroup = document.getElementById('inlineSchoolDropdownGroup');
    const schoolNameGroup = document.getElementById('inlineSchoolNameGroup');
    const schoolAddressGroup = document.getElementById('inlineSchoolAddressGroup');
    const noSchoolsMessage = document.getElementById('inlineNoSchoolsMessage');
    
    // Only show school fields for teachers
    if (currentRole !== 'teacher') {
      return;
    }
    
    if (selectedCountry && selectedCountry === 'ID') {
      // Show school dropdown for Indonesia
      schoolDropdownGroup.style.display = 'flex';
      
      // Update dropdown options (no Create New School option)
      inlineSchoolDropdown.innerHTML = `
        <option value="">Choose a School</option>
        <option value="Indo-ABC">Indo-ABC</option>
        <option value="Indo-DEF">Indo-DEF</option>
        <option value="Indo-GHI">Indo-GHI</option>
        <option value="Indo-JKL">Indo-JKL</option>
      `;
      
      // Show dropdown, hide message
      inlineSchoolDropdown.style.display = 'block';
      if (noSchoolsMessage) noSchoolsMessage.style.display = 'none';
      
      // Clear selections
      inlineSchoolDropdown.value = '';
      inlineSchoolName.value = '';
      inlineSchoolAddress.value = '';
      schoolNameGroup.style.display = 'none';
      schoolAddressGroup.style.display = 'none';
    } else if (selectedCountry) {
      // For other countries, show "No schools found" message
      schoolDropdownGroup.style.display = 'flex';
      
      // Hide dropdown, show message
      inlineSchoolDropdown.style.display = 'none';
      if (noSchoolsMessage) noSchoolsMessage.style.display = 'block';
      
      // Hide name and address fields
      schoolNameGroup.style.display = 'none';
      schoolAddressGroup.style.display = 'none';
      inlineSchoolName.value = '';
      inlineSchoolAddress.value = '';
    } else {
      // Hide all school fields if no country selected
      schoolDropdownGroup.style.display = 'none';
      schoolNameGroup.style.display = 'none';
      schoolAddressGroup.style.display = 'none';
      if (noSchoolsMessage) noSchoolsMessage.style.display = 'none';
    }
  });
}

// Handle school dropdown selection
if (inlineSchoolDropdown) {
  inlineSchoolDropdown.addEventListener('change', (e) => {
    const selectedSchool = e.target.value;
    const schoolNameGroup = document.getElementById('inlineSchoolNameGroup');
    const schoolAddressGroup = document.getElementById('inlineSchoolAddressGroup');
    
    if (selectedSchool && selectedSchool !== '') {
      // Auto-fill school name and address
      inlineSchoolName.value = selectedSchool;
      if (schoolData[selectedSchool]) {
        inlineSchoolAddress.value = schoolData[selectedSchool];
      }
      
      // Show fields but disable them
      schoolNameGroup.style.display = 'flex';
      schoolAddressGroup.style.display = 'flex';
      inlineSchoolName.disabled = true;
      inlineSchoolAddress.disabled = true;
    } else {
      // Hide fields if nothing selected
      schoolNameGroup.style.display = 'none';
      schoolAddressGroup.style.display = 'none';
      inlineSchoolName.value = '';
      inlineSchoolAddress.value = '';
    }
  });
}

// File upload for inline form
function handleInlineFileUpload(e) {
  const file = e.target.files[0];
  const uploadError = document.getElementById('inlineUploadError');
  const uploadFileName = document.getElementById('inlineUploadFileName');
  
  clearError(uploadError);
  
  if (!file) {
    uploadFileName.textContent = 'Choose file or drag here';
    inlineUploadedFile = null;
    return;
  }
  
  // Validate file type
  const allowedTypes = ['image/jpeg', 'image/jpg', 'image/png', 'application/pdf'];
  if (!allowedTypes.includes(file.type)) {
    showError(uploadError, 'Invalid file type. Please upload JPG, PNG, or PDF.');
    uploadFileName.textContent = 'Choose file or drag here';
    inlineUploadedFile = null;
    e.target.value = '';
    return;
  }
  
  // Validate file size (1 MB = 1048576 bytes)
  const maxSize = 1048576;
  if (file.size > maxSize) {
    showError(uploadError, 'File size exceeds 1 MB. Please choose a smaller file.');
    uploadFileName.textContent = 'Choose file or drag here';
    inlineUploadedFile = null;
    e.target.value = '';
    return;
  }
  
  // File is valid
  inlineUploadedFile = file;
  uploadFileName.textContent = file.name;
  console.log('File uploaded:', file.name, 'Size:', (file.size / 1024).toFixed(2), 'KB');
}

// Email validation for inline form
function validateInlineEmail() {
  const email = document.getElementById('inlineEmail').value.trim();
  const emailError = document.getElementById('inlineEmailError');
  clearError(emailError);
  
  if (!email) {
    showError(emailError, 'Email address is required');
    return false;
  }
  
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email)) {
    showError(emailError, 'Please enter a valid email address');
    return false;
  }
  
  return true;
}

function handleInlineEmailInput() {
  const email = document.getElementById('inlineEmail').value.trim();
  const emailInfo = document.getElementById('inlineEmailInfo');
  
  if (email && email.includes('@') && email.includes('.')) {
    emailInfo.classList.add('visible');
  } else {
    emailInfo.classList.remove('visible');
  }
}

// Password validation for inline form
function validateInlinePassword() {
  const password = document.getElementById('inlineNewPassword').value;
  const passwordError = document.getElementById('inlinePasswordError');
  clearError(passwordError);
  
  if (!password) {
    return false;
  }
  
  if (password.length < 8) {
    showError(passwordError, 'Password must be at least 8 characters');
    return false;
  }
  
  if (!/[a-zA-Z]/.test(password)) {
    showError(passwordError, 'Password must contain at least 1 letter');
    return false;
  }
  
  if (!/[0-9]/.test(password)) {
    showError(passwordError, 'Password must contain at least 1 number');
    return false;
  }
  
  if (!/^[a-zA-Z0-9_\-\.@]+$/.test(password)) {
    showError(passwordError, 'Password can only contain a-z, 0-9 and symbols _ - . @');
    return false;
  }
  
  const confirmPassword = document.getElementById('inlineConfirmPassword').value;
  if (confirmPassword) {
    validateInlineConfirmPassword();
  }
  
  return true;
}

function validateInlineConfirmPassword() {
  const password = document.getElementById('inlineNewPassword').value;
  const confirmPassword = document.getElementById('inlineConfirmPassword').value;
  const confirmPasswordError = document.getElementById('inlineConfirmPasswordError');
  clearError(confirmPasswordError);
  
  if (!confirmPassword) {
    return false;
  }
  
  if (password !== confirmPassword) {
    showError(confirmPasswordError, 'Passwords do not match');
    return false;
  }
  
  return true;
}

function clearInlineErrors() {
  const errorIds = [
    'inlineUploadError',
    'inlineEmailError',
    'inlineCountryError',
    'inlineSchoolError',
    'inlineSchoolNameError',
    'inlineSchoolAddressError',
    'inlinePasswordError',
    'inlineConfirmPasswordError'
  ];
  
  errorIds.forEach(id => {
    const element = document.getElementById(id);
    if (element) clearError(element);
  });
}

// Handle inline registration submission
function handleInlineRegistrationSubmit(e) {
  e.preventDefault();
  
  clearInlineErrors();
  
  const email = document.getElementById('inlineEmail').value.trim();
  const country = document.getElementById('inlineCountry').value;
  const password = document.getElementById('inlineNewPassword').value;
  const confirmPassword = document.getElementById('inlineConfirmPassword').value;
  const agreeTerms = document.getElementById('inlineAgreeTerms').checked;
  const agreeMarketing = document.getElementById('inlineAgreeMarketing').checked;
  
  let isValid = true;
  let firstErrorElement = null;
  
  // Validate teacher ID upload (only if visible and required)
  const teacherUploadInput = document.getElementById('inlineTeacherIdUpload');
  const teacherUploadGroup = document.getElementById('inlineTeacherIdUploadGroup');
  const isUploadRequired = teacherUploadInput && teacherUploadInput.hasAttribute('required');
  const isUploadVisible = teacherUploadGroup && teacherUploadGroup.style.display !== 'none';
  
  if (currentRole === 'teacher' && isUploadRequired && isUploadVisible && !inlineUploadedFile) {
    const uploadError = document.getElementById('inlineUploadError');
    showError(uploadError, 'Please upload your school ID');
    if (!firstErrorElement) firstErrorElement = document.getElementById('inlineTeacherIdUpload');
    isValid = false;
  }
  
  // Validate email
  if (!validateInlineEmail()) {
    if (!firstErrorElement) firstErrorElement = document.getElementById('inlineEmail');
    isValid = false;
  }
  
  // Validate country
  if (!country) {
    const countryError = document.getElementById('inlineCountryError');
    showError(countryError, 'Please select your country');
    if (!firstErrorElement) firstErrorElement = document.getElementById('inlineCountry');
    isValid = false;
  }
  
  // Validate school selection for teachers
  if (currentRole === 'teacher') {
    const noSchoolsMessage = document.getElementById('inlineNoSchoolsMessage');
    const schoolDropdown = document.getElementById('inlineSchoolDropdown');
    
    // Check if "no schools" message is visible (country has no schools)
    if (noSchoolsMessage && noSchoolsMessage.style.display !== 'none') {
      const schoolError = document.getElementById('inlineSchoolError');
      showError(schoolError, 'Cannot proceed - no schools available in this country');
      if (!firstErrorElement) firstErrorElement = noSchoolsMessage;
      isValid = false;
    } 
    // Check if dropdown is visible but no school selected
    else if (schoolDropdown && schoolDropdown.style.display !== 'none' && !schoolDropdown.value) {
      const schoolError = document.getElementById('inlineSchoolError');
      showError(schoolError, 'Please select a school');
      if (!firstErrorElement) firstErrorElement = schoolDropdown;
      isValid = false;
    }
  }
  
  // Validate password
  if (!validateInlinePassword()) {
    if (!firstErrorElement) firstErrorElement = document.getElementById('inlineNewPassword');
    isValid = false;
  }
  
  // Validate confirm password
  if (!validateInlineConfirmPassword()) {
    if (!firstErrorElement) firstErrorElement = document.getElementById('inlineConfirmPassword');
    isValid = false;
  }
  
  // Validate terms agreement
  if (!agreeTerms) {
    showAlert('Please agree to the Terms & Conditions to continue', 'error');
    isValid = false;
  }
  
  if (!isValid) {
    // Scroll to first error field
    if (firstErrorElement) {
      firstErrorElement.scrollIntoView({ behavior: 'smooth', block: 'center' });
      setTimeout(() => {
        firstErrorElement.focus();
      }, 500);
    }
    return;
  }
  
  // Disable submit button
  const submitBtn = document.getElementById('inlineSubmitRegistration');
  submitBtn.disabled = true;
  submitBtn.textContent = 'Sending...';
  
  // Simulate API call to send OTP
  setTimeout(() => {
    const registrationData = {
      role: currentRole,
      email,
      country,
      password,
      agreeMarketing,
      teacherId: inlineUploadedFile ? inlineUploadedFile.name : null
    };
    
    console.log('Registration data submitted:', registrationData);
    console.log('OTP sent to:', email);
    
    // Re-enable submit button
    submitBtn.disabled = false;
    submitBtn.textContent = 'Submit';
    
    // Update all displayEmail elements with the user's email
    const displayEmailElements = document.querySelectorAll('#displayEmail');
    displayEmailElements.forEach(el => {
      el.textContent = email;
    });
    
    // Move to OTP verification view
    showView('otpVerification');
    
    // Focus first OTP input
    const firstOtpInput = document.getElementById('otp1');
    if (firstOtpInput) {
      setTimeout(() => firstOtpInput.focus(), 100);
    }
  }, 1500);
}

// ============================================
// OTP VERIFICATION HANDLING
// ============================================

// Initialize OTP inputs
function initializeOTPInputs() {
  const otpInputs = document.querySelectorAll('.otp-input');
  
  otpInputs.forEach((input, index) => {
    // Auto-focus next input on entry
    input.addEventListener('input', (e) => {
      const value = e.target.value;
      
      if (value.length === 1 && index < otpInputs.length - 1) {
        otpInputs[index + 1].focus();
      }
      
      // Remove error state
      input.classList.remove('error');
      clearOTPError();
    });
    
    // Handle backspace
    input.addEventListener('keydown', (e) => {
      if (e.key === 'Backspace' && !e.target.value && index > 0) {
        otpInputs[index - 1].focus();
      }
    });
    
    // Handle paste
    input.addEventListener('paste', (e) => {
      e.preventDefault();
      const pastedData = e.clipboardData.getData('text').trim().toUpperCase();
      
      if (/^[0-9]{4}$/.test(pastedData)) {
        pastedData.split('').forEach((char, i) => {
          if (otpInputs[i]) {
            otpInputs[i].value = char;
          }
        });
        otpInputs[3].focus();
      }
    });
    
    // Force uppercase
    input.addEventListener('input', (e) => {
      e.target.value = e.target.value.toUpperCase();
    });
  });
}

// Verify OTP form submission
const otpVerificationForm = document.getElementById('otpVerificationForm');
if (otpVerificationForm) {
  otpVerificationForm.addEventListener('submit', handleOTPVerification);
}

function handleOTPVerification(e) {
  e.preventDefault();
  
  // Only get OTP verification inputs (id starts with 'otp')
  const otpInputs = [
    document.getElementById('otp1'),
    document.getElementById('otp2'),
    document.getElementById('otp3'),
    document.getElementById('otp4')
  ];
  
  let otpCode = '';
  
  otpInputs.forEach(input => {
    if (input) otpCode += input.value;
  });
  
  if (otpCode.length !== 4) {
    showOTPError('Please enter all 4 digits');
    otpInputs.forEach(input => {
      if (input) input.classList.add('error');
    });
    return;
  }
  
  // Disable verify button
  const verifyBtn = document.getElementById('verifyOtpBtn');
  verifyBtn.disabled = true;
  verifyBtn.textContent = 'Verifying...';
  
  // Simulate API verification
  setTimeout(() => {
    // For demo, accept any 4-digit numeric code
    const isValid = /^[0-9]{4}$/.test(otpCode);
    
    verifyBtn.disabled = false;
    verifyBtn.textContent = 'Verify';
    
    if (isValid) {
      console.log('OTP verified:', otpCode);
      
      // Show success modal
      openSuccessModal();
    } else {
      showOTPError('Invalid verification code. Please try again.');
      // Clear all OTP inputs on error
      const otpInputsError = [
        document.getElementById('otp1'),
        document.getElementById('otp2'),
        document.getElementById('otp3'),
        document.getElementById('otp4')
      ];
      otpInputsError.forEach(input => {
        if (input) {
          input.classList.add('error');
          input.value = '';
        }
      });
      if (otpInputsError[0]) otpInputsError[0].focus();
    }
  }, 1000);
}

function showOTPError(message) {
  const otpError = document.getElementById('otpError');
  if (otpError) {
    otpError.textContent = message;
    otpError.classList.add('visible');
  }
}

function clearOTPError() {
  const otpError = document.getElementById('otpError');
  if (otpError) {
    otpError.textContent = '';
    otpError.classList.remove('visible');
  }
}

// Start the 5-minute countdown timer for resend OTP
function startResendTimer() {
  // Clear any existing timer
  if (resendTimer) {
    clearInterval(resendTimer);
  }
  
  // Set countdown to 5 minutes (300 seconds)
  resendCountdown = 300;
  
  const resendLink = document.getElementById('resendOtpLink');
  if (!resendLink) return;
  
  // Disable the link initially
  resendLink.style.pointerEvents = 'none';
  resendLink.style.opacity = '0.5';
  
  // Update timer display
  function updateTimerDisplay() {
    const minutes = Math.floor(resendCountdown / 60);
    const seconds = resendCountdown % 60;
    const timeString = `${minutes}:${seconds.toString().padStart(2, '0')}`;
    resendLink.textContent = `Resend Code (${timeString})`;
  }
  
  updateTimerDisplay();
  
  // Start countdown
  resendTimer = setInterval(() => {
    resendCountdown--;
    
    if (resendCountdown > 0) {
      updateTimerDisplay();
    } else {
      // Timer finished - enable the link
      clearInterval(resendTimer);
      resendTimer = null;
      resendLink.style.pointerEvents = 'auto';
      resendLink.style.opacity = '1';
      resendLink.textContent = 'Resend Code';
    }
  }, 1000);
}

function resendOTP() {
  const resendLink = document.getElementById('resendOtpLink');
  if (resendLink) {
    resendLink.style.pointerEvents = 'none';
    resendLink.style.opacity = '0.5';
    resendLink.textContent = 'Sending...';
    
    setTimeout(() => {
      console.log('OTP resent');
      alert('Verification code has been resent to your email.');
      
      // Clear OTP inputs
      const otpInputs = document.querySelectorAll('.otp-input');
      otpInputs.forEach(input => {
        input.value = '';
        input.classList.remove('error');
      });
      clearOTPError();
      
      // Focus first input
      const firstInput = document.getElementById('otp1');
      if (firstInput) firstInput.focus();
      
      // Restart the 5-minute timer
      startResendTimer();
    }, 1500);
  }
}

// Initialize OTP inputs on load
initializeOTPInputs();

console.log('Login page initialized successfully');