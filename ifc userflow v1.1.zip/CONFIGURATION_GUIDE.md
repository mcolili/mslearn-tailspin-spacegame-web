# eBook Features Configuration Guide

## Overview
The configuration menu allows users to select their role (Teacher/Student) and content type, which determines which slides are shown in the eBook features modal.

## How It Works

### User Flow
1. **Configuration Menu** appears first with two options:
   - Teacher
   - Student

2. After selecting user type, **four content type options** appear:
   - eBook
   - AI
   - Digital Literacy
   - MPAH Maths 4E

3. Once both selections are made, the **eBook Features Modal** opens showing only the configured slides

## Slide Configurations

### Current Setup
Located in `ebook-scripts.js` at the top (lines 1-14):

```javascript
const SLIDE_CONFIGURATIONS = {
  'teacher-ebook': [1, 2, 3, 4, 5, 10],
  'student-ebook': [1, 2, 3, 4, 5, 10],
  'teacher-ai': [1, 2, 3, 4, 5, 9, 8, 10],
  'student-ai': [1, 2, 3, 4, 5, 9, 8, 10],
  'teacher-digital-literacy': [1, 2, 3, 4, 5, 6, 7, 9, 10],
  'student-digital-literacy': [1, 2, 3, 4, 5, 6, 9, 10],
  'teacher-mpah-maths': [1, 2, 3, 4, 5, 6, 7, 9, 10],
  'student-mpah-maths': [1, 2, 3, 4, 5, 6, 9, 10]
};
```

### Slide Reference
1. Navigate with Ease
2. Annotate Your Content
3. Resource Library
4. eBook Tagged Resources
5. Interactive Whiteboard
6. Auto-marking
7. Portfolio & Pupil's Performance
8. Smart Features at Your Fingertips (Video)
9. Setup Class
10. Help Centre

## How to Edit Slide Sequences

### Easy Method
Simply edit the arrays in the `SLIDE_CONFIGURATIONS` object:

**Example 1:** Add slide 7 to Student eBook
```javascript
'student-ebook': [1, 2, 3, 4, 5, 7, 10],  // Added 7
```

**Example 2:** Change the order for Teacher AI
```javascript
'teacher-ai': [1, 2, 3, 5, 4, 8, 9, 10],  // Swapped 4 and 5, changed order of 8 and 9
```

**Example 3:** Create a minimal experience
```javascript
'student-ebook': [1, 5, 10],  // Just show navigation, whiteboard, and help
```

### Rules
- Use slide numbers from 1-10 (matching the data-slide attribute in HTML)
- Numbers can be in any order (they'll display in the order you specify)
- No duplicate numbers
- At least one slide should be included

## Adding New Content Types

To add a new content type:

1. **Add configuration in JavaScript:**
```javascript
const SLIDE_CONFIGURATIONS = {
  // ... existing configs ...
  'teacher-new-type': [1, 2, 3, 10],
  'student-new-type': [1, 2, 10]
};
```

2. **Add button in HTML** (`ebook.html` around line 269):
```html
<button class="config-btn" data-content-type="new-type">
  <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
    <!-- Your icon SVG path here -->
  </svg>
  <span>New Type Name</span>
</button>
```

## Testing

To test different configurations:
1. Refresh the page
2. Select a user type
3. Select a content type
4. Verify the correct slides appear in the correct order
5. Check that progress dots match the number of slides
6. Test navigation (Next/Back buttons and dots)

## Customization

### Styling
Configuration menu styles are in `ebook-styles.css` starting at line 419:
- `.config-menu-modal` - Modal container
- `.config-btn` - Selection buttons
- `.config-description` - Help text

### Behavior
- Configuration modal appears 500ms after page load
- Modal shows on every page load (can be changed in `ebook-scripts.js` line 703)
- Back button in content selection returns to user type selection
- Close/Back on first slide closes the modal

## Files Modified
1. `ebook.html` - Added configuration menu HTML
2. `ebook-scripts.js` - Added configuration logic and slide management
3. `ebook-styles.css` - Added configuration menu styles
