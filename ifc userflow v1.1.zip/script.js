﻿// ============================================
// CONFIGURATION
// ============================================
const ONBOARD_STORAGE_KEY = 'libraryOnboardingChecklist';
const EMAIL_COOLDOWN_HOURS = 1;

// Track email send timestamps for each class (classCode -> timestamp)
const emailSendTimestamps = {};

// Get tasks from config.js
const defaultTasksConfig = (typeof CONFIG !== 'undefined' && CONFIG.checklistTasks) 
  ? CONFIG.checklistTasks 
  : [];

// ============================================
// STATE MANAGEMENT
// ============================================
function loadState() {
  try {
    const stored = localStorage.getItem(ONBOARD_STORAGE_KEY);
    return stored ? JSON.parse(stored) : null;
  } catch (err) {
    console.error('Failed to load state:', err);
    return null;
  }
}

function saveState(state) {
  try {
    localStorage.setItem(ONBOARD_STORAGE_KEY, JSON.stringify(state));
  } catch (err) {
    console.error('Failed to save state:', err);
  }
}

function initializeState() {
  const stored = loadState();
  if (stored) {
    // If tasks were added/removed in config, sync with stored state
    const storedTaskIds = stored.tasks.map(t => t.id);
    const configTaskIds = defaultTasksConfig.map(t => t.id);
    
    // Add new tasks from config
    const newTasks = defaultTasksConfig.filter(t => !storedTaskIds.includes(t.id));
    const updatedTasks = [
      ...stored.tasks.filter(t => configTaskIds.includes(t.id)), // Keep existing tasks still in config
      ...newTasks.map(t => ({ ...t, completed: false })) // Add new tasks
    ];
    
    return { ...stored, tasks: updatedTasks };
  }

  const freshState = {
    tasks: defaultTasksConfig.map(t => ({ ...t, completed: false })),
    panelOpen: false
  };
  saveState(freshState);
  return freshState;
}

let state = initializeState();

// ============================================
// NAVIGATION
// ============================================
function initNavigation() {
  const navLinks = document.querySelectorAll('.nav-link, .help-icon-btn');
  const contentPages = document.querySelectorAll('.content-page');
  const hamburgerBtn = document.getElementById('hamburgerBtn');
  const navMenu = document.getElementById('navMenu');

  // Hamburger menu toggle
  if (hamburgerBtn && navMenu) {
    hamburgerBtn.addEventListener('click', () => {
      const isActive = navMenu.classList.toggle('active');
      hamburgerBtn.setAttribute('aria-expanded', isActive);
    });

    // Close menu when clicking outside
    document.addEventListener('click', (e) => {
      if (!navMenu.contains(e.target) && !hamburgerBtn.contains(e.target)) {
        navMenu.classList.remove('active');
        hamburgerBtn.setAttribute('aria-expanded', 'false');
      }
    });
  }

  navLinks.forEach(link => {
    link.addEventListener('click', (e) => {
      e.preventDefault();
      
      // Close mobile menu
      if (navMenu) {
        navMenu.classList.remove('active');
        if (hamburgerBtn) hamburgerBtn.setAttribute('aria-expanded', 'false');
      }
      
      // Check if this is an action link (like Class)
      const action = link.getAttribute('data-action');
      if (action === 'manage-class') {
        // Check current view mode to determine which page to show
        const userInfo = document.getElementById('userInfo');
        const viewMode = userInfo ? userInfo.getAttribute('data-view-mode') : 'teacher';
        
        // Use setTimeout to match the TG modal navigation pattern (ensures proper initialization)
        setTimeout(() => {
          // Update active nav link first
          navLinks.forEach(l => l.classList.remove('active'));
          link.classList.add('active');
          
          // Hide all content pages
          contentPages.forEach(page => page.classList.remove('active'));
          
          if (viewMode === 'student') {
            // Student view - show Join School/Class full page
            const joinClassPage = document.getElementById('join-class');
            if (joinClassPage) {
              joinClassPage.classList.add('active');
              initializeJoinClassPage();
            }
          } else {
            // Teacher view - show Class management page
            const manageClassPage = document.getElementById('manage-class');
            if (manageClassPage) {
              manageClassPage.classList.add('active');
              initializeManageClassPage();
            }
          }
        }, 300);
        return;
      }
      
      const targetPage = link.getAttribute('data-page');

      // Update active nav link (only for .nav-link elements, not help-icon-btn)
      if (link.classList.contains('nav-link')) {
        navLinks.forEach(l => l.classList.remove('active'));
        link.classList.add('active');
      }

      // Update active content page
      contentPages.forEach(page => page.classList.remove('active'));
      const targetElement = document.getElementById(targetPage);
      if (targetElement) {
        targetElement.classList.add('active');
      }
    });
  });

  // Footer links navigation
  const footerLinks = document.querySelectorAll('.footer-link');
  footerLinks.forEach(link => {
    link.addEventListener('click', (e) => {
      e.preventDefault();
      const href = link.getAttribute('href');
      
      // Check if it's a page link (starts with #)
      if (href && href.startsWith('#')) {
        const targetPage = href.substring(1); // Remove the # symbol
        
        // Find and click the nav link for this page, or directly show the page
        const navLink = document.querySelector(`.nav-link[data-page="${targetPage}"]`);
        if (navLink) {
          navLink.click();
        } else {
          // If no nav link exists, directly show the page
          contentPages.forEach(page => page.classList.remove('active'));
          const targetElement = document.getElementById(targetPage);
          if (targetElement) {
            targetElement.classList.add('active');
          }
        }
      } else {
        // For other links, navigate to My Library
        const myLibraryLink = document.querySelector('.nav-link[data-page="my-library"]');
        if (myLibraryLink) {
          myLibraryLink.click();
        }
      }
    });
  });
}

// ============================================
// GETTING STARTED WIDGET
// ============================================
function renderTasks() {
  const taskList = document.getElementById('taskList');
  if (!taskList) return;

  taskList.innerHTML = '';

  state.tasks.forEach((task, index) => {
    const taskItem = document.createElement('div');
    taskItem.className = `task-item ${task.completed ? 'completed' : ''}`;
    taskItem.dataset.taskId = task.id;

    const checkbox = document.createElement('div');
    checkbox.className = `task-checkbox ${task.completed ? 'checked' : ''}`;
    checkbox.addEventListener('click', () => toggleTask(task.id));

    const content = document.createElement('div');
    content.className = 'task-content';

    const label = document.createElement('div');
    label.className = 'task-label';
    label.textContent = task.label;

    const hint = document.createElement('div');
    hint.className = 'task-hint';
    hint.textContent = task.hint;

    content.appendChild(label);
    content.appendChild(hint);

    if (task.link) {
      const link = document.createElement('a');
      link.href = task.link;
      link.className = 'task-link';
      link.textContent = 'Learn more â†’';
      link.target = '_blank';
      content.appendChild(link);
    }

    // Actions container
    const actions = document.createElement('div');
    actions.className = 'task-actions';

    // Action button (if defined)
    if (task.action && task.action.label && task.action.url) {
      const actionBtn = document.createElement('button');
      actionBtn.className = 'action-btn';
      actionBtn.setAttribute('aria-label', task.action.label);
      actionBtn.setAttribute('title', task.action.label);
      actionBtn.innerHTML = `<svg viewBox="0 0 24 24" fill="none"><path d="M9 5l7 7-7 7" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg><span>${task.action.label}</span>`;
      actionBtn.addEventListener('click', () => {
        if (task.action.type === 'link') {
          window.open(task.action.url, '_blank', 'noopener,noreferrer');
        }
      });
      actions.appendChild(actionBtn);
    }

    // Form button
    const formBtn = document.createElement('button');
    formBtn.className = 'form-btn';
    formBtn.setAttribute('aria-label', `Open form for ${task.label}`);
    formBtn.setAttribute('title', 'Open Form');
    formBtn.innerHTML = '<svg viewBox="0 0 24 24" fill="none"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" fill="none"/><polyline points="14 2 14 8 20 8" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" fill="none"/><line x1="9" y1="13" x2="15" y2="13" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><line x1="9" y1="17" x2="15" y2="17" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>';
    formBtn.addEventListener('click', () => openTaskForm(task));
    actions.appendChild(formBtn);

    // Video button
    const videoBtn = document.createElement('button');
    videoBtn.className = 'video-btn';
    videoBtn.setAttribute('aria-label', `Watch tutorial for ${task.label}`);
    videoBtn.setAttribute('title', 'Watch Video Tutorial');
    videoBtn.innerHTML = '<svg viewBox="0 0 24 24" fill="none"><path d="M23 7l-7 5 7 5V7z" fill="currentColor"/><rect x="1" y="5" width="15" height="14" rx="2" fill="currentColor"/></svg>';
    videoBtn.addEventListener('click', () => openTutorial(task));
    actions.appendChild(videoBtn);

    taskItem.appendChild(checkbox);
    taskItem.appendChild(content);
    taskItem.appendChild(actions);
    taskList.appendChild(taskItem);
  });

  updateProgress();
}

function toggleTask(taskId) {
  const task = state.tasks.find(t => t.id === taskId);
  if (task) {
    task.completed = !task.completed;
    saveState(state);
    renderTasks();
  }
}

function updateProgress() {
  const completed = state.tasks.filter(t => t.completed).length;
  const total = state.tasks.length;
  const percentage = total > 0 ? (completed / total) * 100 : 0;

  const progressFill = document.getElementById('progressFill');
  const progressText = document.getElementById('progressText');

  if (progressFill) progressFill.style.width = `${percentage}%`;
  if (progressText) progressText.textContent = `${completed}/${total}`;
}

function initOnboardWidget() {
  const toggleBtn = document.getElementById('onboardToggle');
  const panel = document.getElementById('onboardPanel');
  const closeBtn = document.getElementById('onboardClose');

  if (!toggleBtn || !panel || !closeBtn) return;

  // Toggle panel
  toggleBtn.addEventListener('click', () => {
    const isOpen = panel.classList.contains('open');
    if (isOpen) {
      panel.classList.remove('open');
      toggleBtn.setAttribute('aria-expanded', 'false');
      state.panelOpen = false;
    } else {
      panel.classList.add('open');
      toggleBtn.setAttribute('aria-expanded', 'true');
      state.panelOpen = true;
    }
    saveState(state);
  });

  // Close panel
  closeBtn.addEventListener('click', () => {
    panel.classList.remove('open');
    toggleBtn.setAttribute('aria-expanded', 'false');
    state.panelOpen = false;
    saveState(state);
  });

  // Restore panel state
  if (state.panelOpen) {
    panel.classList.add('open');
    toggleBtn.setAttribute('aria-expanded', 'true');
  }

  // Render initial tasks
  renderTasks();
}

// ============================================
// MODAL - FORMS AND VIDEOS
// ============================================
function openTaskForm(task) {
  closeAllModals(['modalBackdrop']);
  
  const modalBackdrop = document.getElementById('modalBackdrop');
  const modalTitle = document.getElementById('modalTitle');
  const modalBody = document.getElementById('modalBody');

  if (!modalBackdrop || !modalTitle || !modalBody) return;

  modalTitle.textContent = task.label;
  modalBody.innerHTML = '';
  document.body.style.overflow = 'hidden';

  if (task.id === 'are-you-teacher') {
    // Teacher role application form
    modalBody.innerHTML = `
      <div class="task-form-container">
        <p class="task-form-description">Select or create your school and verify your teacher account by submitting your school ID. Once approved, you'll gain access to all teacher resources.</p>
        <form class="task-form" id="taskForm-${task.id}">
          <div class="form-group">
            <label for="form-country-${task.id}">Country:</label>
            <select id="form-country-${task.id}" name="country" required>
              <option value="">Select a country</option>
              <option value="Afghanistan">Afghanistan</option>
              <option value="Albania">Albania</option>
              <option value="Algeria">Algeria</option>
              <option value="Argentina">Argentina</option>
              <option value="Australia">Australia</option>
              <option value="Austria">Austria</option>
              <option value="Bangladesh">Bangladesh</option>
              <option value="Belgium">Belgium</option>
              <option value="Brazil">Brazil</option>
              <option value="Brunei">Brunei</option>
              <option value="Bulgaria">Bulgaria</option>
              <option value="Cambodia">Cambodia</option>
              <option value="Canada">Canada</option>
              <option value="Chile">Chile</option>
              <option value="China">China</option>
              <option value="Colombia">Colombia</option>
              <option value="Croatia">Croatia</option>
              <option value="Czech Republic">Czech Republic</option>
              <option value="Denmark">Denmark</option>
              <option value="Egypt">Egypt</option>
              <option value="Estonia">Estonia</option>
              <option value="Finland">Finland</option>
              <option value="France">France</option>
              <option value="Germany">Germany</option>
              <option value="Greece">Greece</option>
              <option value="Hong Kong">Hong Kong</option>
              <option value="Hungary">Hungary</option>
              <option value="Iceland">Iceland</option>
              <option value="India">India</option>
              <option value="Indonesia">Indonesia</option>
              <option value="Iran">Iran</option>
              <option value="Iraq">Iraq</option>
              <option value="Ireland">Ireland</option>
              <option value="Israel">Israel</option>
              <option value="Italy">Italy</option>
              <option value="Japan">Japan</option>
              <option value="Jordan">Jordan</option>
              <option value="Kazakhstan">Kazakhstan</option>
              <option value="Kenya">Kenya</option>
              <option value="Kuwait">Kuwait</option>
              <option value="Laos">Laos</option>
              <option value="Latvia">Latvia</option>
              <option value="Lebanon">Lebanon</option>
              <option value="Lithuania">Lithuania</option>
              <option value="Malaysia">Malaysia</option>
              <option value="Mexico">Mexico</option>
              <option value="Morocco">Morocco</option>
              <option value="Myanmar">Myanmar</option>
              <option value="Nepal">Nepal</option>
              <option value="Netherlands">Netherlands</option>
              <option value="New Zealand">New Zealand</option>
              <option value="Nigeria">Nigeria</option>
              <option value="Norway">Norway</option>
              <option value="Oman">Oman</option>
              <option value="Pakistan">Pakistan</option>
              <option value="Palestine">Palestine</option>
              <option value="Peru">Peru</option>
              <option value="Philippines">Philippines</option>
              <option value="Poland">Poland</option>
              <option value="Portugal">Portugal</option>
              <option value="Qatar">Qatar</option>
              <option value="Romania">Romania</option>
              <option value="Russia">Russia</option>
              <option value="Saudi Arabia">Saudi Arabia</option>
              <option value="Singapore">Singapore</option>
              <option value="Slovakia">Slovakia</option>
              <option value="Slovenia">Slovenia</option>
              <option value="South Africa">South Africa</option>
              <option value="South Korea">South Korea</option>
              <option value="Spain">Spain</option>
              <option value="Sri Lanka">Sri Lanka</option>
              <option value="Sweden">Sweden</option>
              <option value="Switzerland">Switzerland</option>
              <option value="Syria">Syria</option>
              <option value="Taiwan">Taiwan</option>
              <option value="Thailand">Thailand</option>
              <option value="Turkey">Turkey</option>
              <option value="Ukraine">Ukraine</option>
              <option value="United Arab Emirates">United Arab Emirates</option>
              <option value="United Kingdom">United Kingdom</option>
              <option value="United States">United States</option>
              <option value="Vietnam">Vietnam</option>
              <option value="Yemen">Yemen</option>
            </select>
            <div class="form-error" id="country-error-${task.id}" style="display: none;">Please select a country</div>
          </div>
          
          <div class="form-group" id="school-dropdown-group-${task.id}" style="display: none;">
            <label for="form-school-dropdown-${task.id}">School:</label>
            <select id="form-school-dropdown-${task.id}" name="schoolDropdown">
              <option value="">Choose a School or Create New School</option>
              <option value="create-new">Create New School</option>
            </select>
            <div class="form-error" id="school-error-${task.id}" style="display: none;">Please select a school</div>
          </div>
          
          <div class="form-group" id="school-name-group-${task.id}" style="display: none;">
            <label for="form-school-name-${task.id}">School Name:</label>
            <input type="text" id="form-school-name-${task.id}" name="schoolName" required placeholder="Enter school name">
            <div class="form-error" id="school-name-error-${task.id}" style="display: none;">Please enter school name</div>
          </div>
          
          <div class="form-group" id="school-address-group-${task.id}" style="display: none;">
            <label for="form-school-address-${task.id}">School Address:</label>
            <input type="text" id="form-school-address-${task.id}" name="schoolAddress" required placeholder="Enter school address">
            <div class="form-error" id="school-address-error-${task.id}" style="display: none;">Please enter school address</div>
          </div>
          
          <div class="form-group" id="school-id-group-${task.id}" style="display: none;">
            <label for="form-school-id-${task.id}">Upload School ID:</label>
            <input type="file" id="form-school-id-${task.id}" name="schoolId" accept=".jpg,.jpeg,.png,.pdf" style="display: none;">
            <div class="upload-row">
              <button type="button" class="file-upload-btn" id="upload-btn-${task.id}">
                <svg viewBox="0 0 24 24" fill="none" style="width: 18px; height: 18px;">
                  <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                  <polyline points="17 8 12 3 7 8" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                  <line x1="12" y1="3" x2="12" y2="15" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                </svg>
                <span>Upload</span>
              </button>
              <div class="file-info">File type: JPG, PNG and PDF. Maximum file size: 1 MB.</div>
            </div>
            <div class="file-name" id="file-name-${task.id}" style="margin-top: 8px; font-size: 13px; color: #059669;"></div>
            <div class="form-error" id="upload-error-${task.id}" style="display: none;">Please upload a School ID document</div>
          </div>
          
          <div class="admin-notice" id="admin-notice-${task.id}" style="display: none;">
            <strong>No School Admin Found!</strong><br>
            If no administrator has been assigned to this school, you will be automatically promoted to school admin to assist with onboarding fellow teachers. Administrative privileges can be reassigned at a later time.
          </div>
          
          <div class="form-actions">
            <button type="button" class="form-cancel-btn">Cancel</button>
            <button type="submit" class="form-submit-btn">Submit</button>
          </div>
        </form>
      </div>
    `;
    
    modalBackdrop.classList.add('show');
    modalBackdrop.setAttribute('aria-hidden', 'false');
    
    setupTeacherForm(task);
  } else if (task.id === 'create-choose-school') {
    // Create or Choose School form (from AI modal)
    modalBody.innerHTML = `
      <div class="task-form-container">
        <p class="task-form-description">You are about to Create or Choose your school. Please ensure that you have provided the correct information of your school.</p>
        <form class="task-form" id="taskForm-${task.id}">
          <div class="form-group">
            <label for="form-country-${task.id}">Country:</label>
            <select id="form-country-${task.id}" name="country" required>
              <option value="">Select a country</option>
              <option value="Afghanistan">Afghanistan</option>
              <option value="Albania">Albania</option>
              <option value="Algeria">Algeria</option>
              <option value="Argentina">Argentina</option>
              <option value="Australia">Australia</option>
              <option value="Austria">Austria</option>
              <option value="Bangladesh">Bangladesh</option>
              <option value="Belgium">Belgium</option>
              <option value="Brazil">Brazil</option>
              <option value="Brunei">Brunei</option>
              <option value="Bulgaria">Bulgaria</option>
              <option value="Cambodia">Cambodia</option>
              <option value="Canada">Canada</option>
              <option value="Chile">Chile</option>
              <option value="China">China</option>
              <option value="Colombia">Colombia</option>
              <option value="Croatia">Croatia</option>
              <option value="Czech Republic">Czech Republic</option>
              <option value="Denmark">Denmark</option>
              <option value="Egypt">Egypt</option>
              <option value="Estonia">Estonia</option>
              <option value="Finland">Finland</option>
              <option value="France">France</option>
              <option value="Germany">Germany</option>
              <option value="Greece">Greece</option>
              <option value="Hong Kong">Hong Kong</option>
              <option value="Hungary">Hungary</option>
              <option value="Iceland">Iceland</option>
              <option value="India">India</option>
              <option value="Indonesia">Indonesia</option>
              <option value="Iran">Iran</option>
              <option value="Iraq">Iraq</option>
              <option value="Ireland">Ireland</option>
              <option value="Israel">Israel</option>
              <option value="Italy">Italy</option>
              <option value="Japan">Japan</option>
              <option value="Jordan">Jordan</option>
              <option value="Kazakhstan">Kazakhstan</option>
              <option value="Kenya">Kenya</option>
              <option value="Kuwait">Kuwait</option>
              <option value="Laos">Laos</option>
              <option value="Latvia">Latvia</option>
              <option value="Lebanon">Lebanon</option>
              <option value="Lithuania">Lithuania</option>
              <option value="Malaysia">Malaysia</option>
              <option value="Mexico">Mexico</option>
              <option value="Morocco">Morocco</option>
              <option value="Myanmar">Myanmar</option>
              <option value="Nepal">Nepal</option>
              <option value="Netherlands">Netherlands</option>
              <option value="New Zealand">New Zealand</option>
              <option value="Nigeria">Nigeria</option>
              <option value="Norway">Norway</option>
              <option value="Oman">Oman</option>
              <option value="Pakistan">Pakistan</option>
              <option value="Palestine">Palestine</option>
              <option value="Peru">Peru</option>
              <option value="Philippines">Philippines</option>
              <option value="Poland">Poland</option>
              <option value="Portugal">Portugal</option>
              <option value="Qatar">Qatar</option>
              <option value="Romania">Romania</option>
              <option value="Russia">Russia</option>
              <option value="Saudi Arabia">Saudi Arabia</option>
              <option value="Singapore">Singapore</option>
              <option value="Slovakia">Slovakia</option>
              <option value="Slovenia">Slovenia</option>
              <option value="South Africa">South Africa</option>
              <option value="South Korea">South Korea</option>
              <option value="Spain">Spain</option>
              <option value="Sri Lanka">Sri Lanka</option>
              <option value="Sweden">Sweden</option>
              <option value="Switzerland">Switzerland</option>
              <option value="Syria">Syria</option>
              <option value="Taiwan">Taiwan</option>
              <option value="Thailand">Thailand</option>
              <option value="Turkey">Turkey</option>
              <option value="Ukraine">Ukraine</option>
              <option value="United Arab Emirates">United Arab Emirates</option>
              <option value="United Kingdom">United Kingdom</option>
              <option value="United States">United States</option>
              <option value="Vietnam">Vietnam</option>
              <option value="Yemen">Yemen</option>
            </select>
            <div class="form-error" id="country-error-${task.id}" style="display: none;">Please select a country</div>
          </div>
          
          <div class="form-group" id="school-dropdown-group-${task.id}" style="display: none;">
            <label for="form-school-dropdown-${task.id}">School:</label>
            <select id="form-school-dropdown-${task.id}" name="schoolDropdown">
              <option value="">Choose a School or Create New School</option>
              <option value="create-new">Create New School</option>
            </select>
            <div class="form-error" id="school-error-${task.id}" style="display: none;">Please select a school</div>
          </div>
          
          <div class="form-group" id="school-name-group-${task.id}" style="display: none;">
            <label for="form-school-name-${task.id}">School Name:</label>
            <input type="text" id="form-school-name-${task.id}" name="schoolName" required placeholder="Enter school name">
            <div class="form-error" id="school-name-error-${task.id}" style="display: none;">Please enter school name</div>
          </div>
          
          <div class="form-group" id="school-address-group-${task.id}" style="display: none;">
            <label for="form-school-address-${task.id}">School Address:</label>
            <input type="text" id="form-school-address-${task.id}" name="schoolAddress" required placeholder="Enter school address">
            <div class="form-error" id="school-address-error-${task.id}" style="display: none;">Please enter school address</div>
          </div>
          
          <div class="form-actions">
            <button type="button" class="form-cancel-btn">Cancel</button>
            <button type="submit" class="form-submit-btn">Submit</button>
          </div>
        </form>
      </div>
    `;
    
    modalBackdrop.classList.add('show');
    modalBackdrop.setAttribute('aria-hidden', 'false');
    
    setupTeacherForm(task, 'create-choose-school');
  } else if (task.id === 'create-class') {
    setupCreateClassForm(task);
  } else {
    // Default form
    modalBody.innerHTML = `
      <div class="task-form-container">
        <p class="task-form-description">${task.hint}</p>
        <form class="task-form" id="taskForm-${task.id}">
          <div class="form-group">
            <label for="form-name-${task.id}">Name</label>
            <input type="text" id="form-name-${task.id}" name="name" required placeholder="Enter your name">
          </div>
          <div class="form-group">
            <label for="form-email-${task.id}">Email</label>
            <input type="email" id="form-email-${task.id}" name="email" required placeholder="Enter your email">
          </div>
          <div class="form-group">
            <label for="form-message-${task.id}">Message</label>
            <textarea id="form-message-${task.id}" name="message" rows="4" placeholder="Enter your message"></textarea>
          </div>
          <div class="form-actions">
            <button type="button" class="form-cancel-btn">Cancel</button>
            <button type="submit" class="form-submit-btn">Submit</button>
          </div>
        </form>
      </div>
    `;
    
    modalBackdrop.classList.add('show');
    modalBackdrop.setAttribute('aria-hidden', 'false');
    
    const form = document.getElementById(`taskForm-${task.id}`);
    form.addEventListener('submit', (e) => {
      e.preventDefault();
      showFormSuccess(task.label);
    });
    
    const cancelBtn = modalBody.querySelector('.form-cancel-btn');
    cancelBtn.addEventListener('click', closeModal);
  }
}

function openTutorial(task) {
  closeAllModals(['modalBackdrop']);
  
  const modalBackdrop = document.getElementById('modalBackdrop');
  const modalTitle = document.getElementById('modalTitle');
  const modalBody = document.getElementById('modalBody');

  if (!modalBackdrop || !modalTitle || !modalBody) return;

  modalTitle.textContent = task.label;
  modalBody.innerHTML = '';

  if (task.video && task.video.type === 'youtube') {
    const iframe = document.createElement('iframe');
    iframe.src = task.video.src + '?rel=0&enablejsapi=1';
    iframe.allow = 'accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture';
    iframe.allowFullscreen = true;
    iframe.title = `Tutorial: ${task.label}`;
    iframe.style.width = '100%';
    iframe.style.height = '450px';
    iframe.style.border = 'none';
    iframe.style.borderRadius = 'var(--radius)';
    modalBody.appendChild(iframe);
  } else if (task.video && task.video.type === 'mp4') {
    setupMP4Player(task, modalBody);
  } else {
    modalBody.innerHTML = '<p>No video available for this task.</p>';
  }

  modalBackdrop.classList.add('show');
  modalBackdrop.setAttribute('aria-hidden', 'false');
}

function closeModal() {
  const backdrop = document.getElementById('modalBackdrop');
  const modalBody = document.getElementById('modalBody');

  if (!backdrop || !modalBody) return;

  const video = modalBody.querySelector('video');
  if (video) {
    video.pause();
    video.currentTime = 0;
  }

  const iframe = modalBody.querySelector('iframe');
  if (iframe) {
    iframe.src = '';
  }

  backdrop.classList.remove('show');
  backdrop.setAttribute('aria-hidden', 'true');
  modalBody.innerHTML = '';
  document.body.style.overflow = '';
}

function initModal() {
  const closeBtn = document.getElementById('modalClose');
  const backdrop = document.getElementById('modalBackdrop');

  if (closeBtn) {
    closeBtn.addEventListener('click', closeModal);
  }

  if (backdrop) {
    backdrop.addEventListener('click', (e) => {
      if (e.target === backdrop) {
        closeModal();
      }
    });
  }

  // Close modal on Escape key
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      closeModal();
    }
  });
}



// ============================================
// THUMBNAIL INTERACTIONS
// ============================================
function initThumbnails() {
  // Use event delegation on parent containers for better performance
  const contentSections = document.querySelectorAll('.content-section');
  
  contentSections.forEach(section => {
    section.addEventListener('click', (e) => {
      const card = e.target.closest('.thumbnail-card');
      if (!card) return;
      
      // Check if click is on or within a tag button (handles SVG clicks)
      const tagButton = e.target.closest('.tag-btn');
      
      if (tagButton) {
        e.stopPropagation();
        
        if (tagButton.classList.contains('offline-available-tag')) {
          openDownloadAppModal();
          return;
        }
        
        if (tagButton.classList.contains('enhanced-tag')) {
          openEnhancedEbookModal();
          return;
        }
        
        if (tagButton.classList.contains('auto-marking-tag')) {
          openAutoMarkingModal();
          return;
        }
        
        if (tagButton.classList.contains('ai-tag')) {
          // Call the globally exposed function
          if (window.showUseAiModal) {
            window.showUseAiModal(true);
          }
          return;
        }
        
        if (tagButton.classList.contains('teacher-resources-tag')) {
          const version = card.getAttribute('data-teacher-resources') || '3a';
          openTeacherResourcesModal(version);
          return;
        }
      }
      
      // Check if click is on offline badge (grid or list mode)
      const offlineBadge = e.target.closest('.offline-badge, .list-mode-offline-badge');
      if (offlineBadge) {
        e.stopPropagation();
        openDownloadAppModal();
        return;
      }
      
      // Check if the card has teacher resources attribute
      if (card.hasAttribute('data-teacher-resources')) {
        const version = card.getAttribute('data-teacher-resources');
        openTeacherResourcesModal(version);
        return;
      }
      
      // Check if this is a student card (has student badge) but NOT a sample or content-package
      const studentBadge = card.querySelector('.student-badge');
      const sampleBadge = card.querySelector('.sample-badge');
      const cardType = card.getAttribute('data-type');
      const title = card.querySelector('h3')?.textContent || 'Content';
      
      // Open ebook.html for student content (except content-package like "English with Coco")
      if (studentBadge && !sampleBadge && cardType !== 'content-package') {
        // Open ebook.html in a new tab
        window.open('ebook.html', '_blank');
        return;
      }
      
      // For content-package or teacher view, show default message
      alert(`Opening: ${title}\n\nThis would navigate to the content package or eBook in a real implementation.`);
      // In a real implementation, this would navigate to the content detail page
    });
  });
}

// ============================================
// DOWNLOAD APP MODAL
// ============================================
function initDownloadAppModal() {
  const closeBtn = document.getElementById('closeDownloadModal');
  const modal = document.getElementById('downloadAppModal');
  const downloadUserGuideBtn = document.getElementById('downloadUserGuide');
  const platformBtns = document.querySelectorAll('.platform-download-btn');
  
  if (closeBtn) {
    closeBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      closeDownloadAppModal();
    });
  }
  
  if (modal) {
    modal.addEventListener('click', (e) => {
      if (e.target === modal) {
        closeDownloadAppModal();
      }
    });
  }
  
  if (downloadUserGuideBtn) {
    downloadUserGuideBtn.addEventListener('click', () => {
      // In real implementation, this would download the actual user guide PDF
      alert('Downloading MCEduHub User Guide...\n\nThis would download the user guide PDF file in a real implementation.');
    });
  }
  
  platformBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      const platform = btn.dataset.platform;
      alert(`Downloading MCEduHub for ${platform === 'windows' ? 'Windows' : 'Mac OS'}...\n\nThis would download the installer in a real implementation.`);
    });
  });
  
  // Close modal on Escape key
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      const modal = document.getElementById('downloadAppModal');
      if (modal && modal.classList.contains('active')) {
        closeDownloadAppModal();
      }
    }
  });
}

function openDownloadAppModal() {
  closeAllModals(['downloadAppModal']);
  
  const modal = document.getElementById('downloadAppModal');
  if (modal) {
    modal.classList.add('active');
    document.body.style.overflow = 'hidden';
  }
}

function closeDownloadAppModal() {
  const modal = document.getElementById('downloadAppModal');
  if (modal) {
    modal.classList.remove('active');
    document.body.style.overflow = '';
  }
}

// ============================================
// FEATURE INFO MODALS (Enhanced e-Book, Auto Marking)
// ============================================
function initFeatureModals() {
  // Enhanced e-Book Modal
  const enhancedModal = document.getElementById('enhancedEbookModal');
  const closeEnhancedBtn = document.getElementById('closeEnhancedModal');
  
  if (closeEnhancedBtn) {
    closeEnhancedBtn.addEventListener('click', closeEnhancedEbookModal);
  }
  
  if (enhancedModal) {
    enhancedModal.addEventListener('click', (e) => {
      if (e.target === enhancedModal) {
        closeEnhancedEbookModal();
      }
    });
  }
  
  // Auto Marking Modal
  const autoMarkingModal = document.getElementById('autoMarkingModal');
  const closeAutoMarkingBtn = document.getElementById('closeAutoMarkingModal');
  
  if (closeAutoMarkingBtn) {
    closeAutoMarkingBtn.addEventListener('click', closeAutoMarkingModal);
  }
  
  if (autoMarkingModal) {
    autoMarkingModal.addEventListener('click', (e) => {
      if (e.target === autoMarkingModal) {
        closeAutoMarkingModal();
      }
    });
  }
  
  // Teacher Resources Modal 3A
  const teacherResourcesModal3A = document.getElementById('teacherResourcesModal3A');
  const closeTeacherResourcesBtn3A = document.getElementById('closeTeacherResourcesModal3A');
  
  if (closeTeacherResourcesBtn3A) {
    closeTeacherResourcesBtn3A.addEventListener('click', () => closeTeacherResourcesModal('3a'));
  }
  
  if (teacherResourcesModal3A) {
    teacherResourcesModal3A.addEventListener('click', (e) => {
      if (e.target === teacherResourcesModal3A) {
        closeTeacherResourcesModal('3a');
      }
    });
  }
  
  // Teacher Resources Modal 3B
  const teacherResourcesModal3B = document.getElementById('teacherResourcesModal3B');
  const closeTeacherResourcesBtn3B = document.getElementById('closeTeacherResourcesModal3B');
  
  if (closeTeacherResourcesBtn3B) {
    closeTeacherResourcesBtn3B.addEventListener('click', () => closeTeacherResourcesModal('3b'));
  }
  
  if (teacherResourcesModal3B) {
    teacherResourcesModal3B.addEventListener('click', (e) => {
      if (e.target === teacherResourcesModal3B) {
        closeTeacherResourcesModal('3b');
      }
    });
  }
}

// Resource Category Collapse/Expand Functionality
function initializeResourceCategoryToggles() {
  const categoryHeaders = document.querySelectorAll('.resource-category-header');
  
  categoryHeaders.forEach(header => {
    // Check if collapse button already exists
    if (!header.querySelector('.category-collapse-btn')) {
      // Create collapse button
      const collapseBtn = document.createElement('button');
      collapseBtn.className = 'category-collapse-btn';
      collapseBtn.setAttribute('aria-label', 'Toggle section');
      
      // Create SVG
      const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
      svg.setAttribute('viewBox', '0 0 24 24');
      svg.setAttribute('fill', 'none');
      
      const path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
      path.setAttribute('d', 'M6 9l6 6 6-6');
      path.setAttribute('stroke', 'currentColor');
      path.setAttribute('stroke-width', '2');
      path.setAttribute('stroke-linecap', 'round');
      path.setAttribute('stroke-linejoin', 'round');
      
      svg.appendChild(path);
      collapseBtn.appendChild(svg);
      
      // Insert button before the h3
      const h3 = header.querySelector('h3');
      if (h3) {
        header.insertBefore(collapseBtn, h3);
      }
    }
    
    // Add event listener
    const collapseBtn = header.querySelector('.category-collapse-btn');
    if (collapseBtn && !collapseBtn.hasAttribute('data-initialized')) {
      collapseBtn.setAttribute('data-initialized', 'true');
      collapseBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        header.classList.toggle('collapsed');
        
        // Update aria-label
        const isCollapsed = header.classList.contains('collapsed');
        collapseBtn.setAttribute('aria-label', isCollapsed ? 'Expand section' : 'Collapse section');
      });
    }
  });
}

// Initialize when modals become active
const observer = new MutationObserver((mutations) => {
  mutations.forEach((mutation) => {
    if (mutation.type === 'attributes' && mutation.attributeName === 'class') {
      const target = mutation.target;
      if (target.classList.contains('active') && 
          (target.id === 'teacherResourcesModal3A' || target.id === 'teacherResourcesModal3B')) {
        initializeResourceCategoryToggles();
      }
    }
  });
});

// Observe both modals
const modal3A = document.getElementById('teacherResourcesModal3A');
const modal3B = document.getElementById('teacherResourcesModal3B');
if (modal3A) observer.observe(modal3A, { attributes: true });
if (modal3B) observer.observe(modal3B, { attributes: true });

// Also initialize on page load for any  sections already in the DOM
document.addEventListener('DOMContentLoaded', () => {
  initializeResourceCategoryToggles();
});

function openEnhancedEbookModal() {
  closeAllModals(['enhancedEbookModal']);
  
  const modal = document.getElementById('enhancedEbookModal');
  if (modal) {
    modal.classList.add('active');
    document.body.style.overflow = 'hidden';
  }
}

function closeEnhancedEbookModal() {
  const modal = document.getElementById('enhancedEbookModal');
  if (modal) {
    modal.classList.remove('active');
    document.body.style.overflow = '';
  }
}

function openAutoMarkingModal() {
  closeAllModals(['autoMarkingModal']);
  
  const modal = document.getElementById('autoMarkingModal');
  if (modal) {
    modal.classList.add('active');
    document.body.style.overflow = 'hidden';
  }
}

function closeAutoMarkingModal() {
  const modal = document.getElementById('autoMarkingModal');
  if (modal) {
    modal.classList.remove('active');
    document.body.style.overflow = '';
  }
}

function openTeacherResourcesModal(version = '3a') {
  const modalId = version === '3b' ? 'teacherResourcesModal3B' : 'teacherResourcesModal3A';
  closeAllModals([modalId]);
  
  const modal = document.getElementById(modalId);
  if (modal) {
    modal.classList.add('active');
    document.body.style.overflow = 'hidden';
  }
}

function closeTeacherResourcesModal(version = '3a') {
  const modalId = version === '3b' ? 'teacherResourcesModal3B' : 'teacherResourcesModal3A';
  const modal = document.getElementById(modalId);
  if (modal) {
    modal.classList.remove('active');
    document.body.style.overflow = '';
  }
}

function closeAllTeacherResourcesModals() {
  closeTeacherResourcesModal('3a');
  closeTeacherResourcesModal('3b');
}

// ============================================
// FORM HELPERS
// ============================================
function setupTeacherForm(task, formType = 'are-you-teacher') {
  const countrySelect = document.getElementById(`form-country-${task.id}`);
  const schoolDropdownGroup = document.getElementById(`school-dropdown-group-${task.id}`);
  const schoolDropdown = document.getElementById(`form-school-dropdown-${task.id}`);
  const schoolNameGroup = document.getElementById(`school-name-group-${task.id}`);
  const schoolAddressGroup = document.getElementById(`school-address-group-${task.id}`);
  const schoolIdGroup = document.getElementById(`school-id-group-${task.id}`);
  const schoolNameInput = document.getElementById(`form-school-name-${task.id}`);
  const schoolAddressInput = document.getElementById(`form-school-address-${task.id}`);
  const adminNotice = document.getElementById(`admin-notice-${task.id}`);
  
  // Check if this is the AI modal form
  const isAiModalForm = formType === 'create-choose-school';
  
  // School data with addresses
  const schoolData = {
    'Indo-ABC': 'Indo-ABC International School, Jl. Sudirman No. 123, Jakarta Selatan, DKI Jakarta 12190',
    'Indo-DEF': 'Indo-DEF Academy, Jl. Gatot Subroto No. 456, Bandung, Jawa Barat 40262',
    'Indo-GHI': 'Indo-GHI Education Center, Jl. Ahmad Yani No. 789, Surabaya, Jawa Timur 60234',
    'Indo-JKL': 'Indo-JKL Learning Institute, Jl. Diponegoro No. 321, Yogyakarta, DIY 55221',
    'Austria-ABC': 'Austria-ABC International School, Stephansplatz 12, 1010 Wien, Austria'
  };
  
  // Schools with existing admin
  // For are-you-teacher form: Indo-ABC and Indo-DEF have admin
  // For create-choose-school form: All Indo schools have admin setup already
  const schoolsWithAdmin = isAiModalForm 
    ? ['Indo-ABC', 'Indo-DEF', 'Indo-GHI', 'Indo-JKL']
    : ['Indo-ABC', 'Indo-DEF'];
  
  // School admin names
  const schoolAdmins = {
    'Indo-ABC': 'Indo-ABC-Admin',
    'Indo-DEF': 'Indo-DEF-Admin'
  };
  
  // Handle country selection change
  countrySelect.addEventListener('change', (e) => {
    const selectedCountry = e.target.value;
    
    // Clear country error when user makes a selection
    document.getElementById(`country-error-${task.id}`).style.display = 'none';
    
    if (selectedCountry) {
      // Show school dropdown and name/address fields
      schoolDropdownGroup.style.display = 'block';
      schoolNameGroup.style.display = 'block';
      schoolAddressGroup.style.display = 'block';
      if (schoolIdGroup) schoolIdGroup.style.display = 'block';
      
      // Clear previous selections
      schoolDropdown.value = '';
      schoolNameInput.value = '';
      schoolAddressInput.value = '';
      
      // Update school dropdown options based on country
      if (selectedCountry === 'Indonesia') {
        schoolDropdown.innerHTML = `
          <option value="">Choose a School or Create New School</option>
          <option value="create-new">Create New School</option>
          <option value="Indo-ABC">Indo-ABC</option>
          <option value="Indo-DEF">Indo-DEF</option>
          <option value="Indo-GHI">Indo-GHI</option>
          <option value="Indo-JKL">Indo-JKL</option>
        `;
      } else if (selectedCountry === 'Austria') {
        schoolDropdown.innerHTML = `
          <option value="">Choose a School or Create New School</option>
          <option value="create-new">Create New School</option>
          <option value="Austria-ABC">Austria-ABC</option>
        `;
      } else {
        schoolDropdown.innerHTML = `
          <option value="create-new">Create New School</option>
        `;
        // Auto-select "Create New School" for countries without schools
        schoolDropdown.value = 'create-new';
        // Clear fields and make them editable
        schoolNameInput.value = '';
        schoolAddressInput.value = '';
        schoolNameInput.readOnly = false;
        schoolAddressInput.readOnly = false;
        // Show admin notice for new school (only for are-you-teacher form)
        if (adminNotice) adminNotice.style.display = 'block';
      }
    } else {
      // Hide all fields if no country selected
      schoolDropdownGroup.style.display = 'none';
      schoolNameGroup.style.display = 'none';
      schoolAddressGroup.style.display = 'none';
      if (schoolIdGroup) schoolIdGroup.style.display = 'none';
      schoolDropdown.value = '';
      schoolNameInput.value = '';
      schoolAddressInput.value = '';
    }
  });
  
  // Handle school dropdown selection change
  schoolDropdown.addEventListener('change', (e) => {
    const selectedSchool = e.target.value;
    
    // Clear school error when user makes a selection
    document.getElementById(`school-error-${task.id}`).style.display = 'none';
    
    if (selectedSchool && selectedSchool !== '' && selectedSchool !== 'create-new') {
      // Auto-fill school name
      schoolNameInput.value = selectedSchool;
      
      // Auto-fill school address
      if (schoolData[selectedSchool]) {
        schoolAddressInput.value = schoolData[selectedSchool];
      } else {
        schoolAddressInput.value = '';
      }
      
      // Disable fields when a school is selected
      schoolNameInput.disabled = true;
      schoolAddressInput.disabled = true;
      
      // Show/hide admin notice based on whether school has admin (only for are-you-teacher form)
      if (adminNotice) {
        if (schoolsWithAdmin.includes(selectedSchool)) {
          adminNotice.style.display = 'none';
        } else {
          adminNotice.style.display = 'block';
        }
      }
    } else if (selectedSchool === 'create-new') {
      // Clear fields and enable them for new school
      schoolNameInput.value = '';
      schoolAddressInput.value = '';
      schoolNameInput.disabled = false;
      schoolAddressInput.disabled = false;
      
      // Show admin notice for new school (only for are-you-teacher form)
      if (adminNotice) adminNotice.style.display = 'block';
      schoolNameInput.focus();
    } else {
      // Clear fields when no selection (placeholder selected)
      schoolNameInput.value = '';
      schoolAddressInput.value = '';
      schoolNameInput.disabled = false;
      schoolAddressInput.disabled = false;
      // Hide admin notice when no selection (only for are-you-teacher form)
      if (adminNotice) adminNotice.style.display = 'none';
    }
  });
  
  // Clear school name error on input
  schoolNameInput.addEventListener('input', () => {
    if (schoolNameInput.value.trim()) {
      document.getElementById(`school-name-error-${task.id}`).style.display = 'none';
    }
  });
  
  // Clear school address error on input
  schoolAddressInput.addEventListener('input', () => {
    if (schoolAddressInput.value.trim()) {
      document.getElementById(`school-address-error-${task.id}`).style.display = 'none';
    }
  });
  
  // Handle file upload button click (only for are-you-teacher form)
  if (!isAiModalForm) {
    const uploadBtn = document.getElementById(`upload-btn-${task.id}`);
    const fileInput = document.getElementById(`form-school-id-${task.id}`);
    const fileNameDisplay = document.getElementById(`file-name-${task.id}`);
    const uploadError = document.getElementById(`upload-error-${task.id}`);
    
    uploadBtn.addEventListener('click', () => {
      // Clear error when user clicks upload button
      uploadError.style.display = 'none';
      fileInput.click();
    });
    
    fileInput.addEventListener('change', (e) => {
      const file = e.target.files[0];
      if (file) {
        // Clear any previous error
        uploadError.style.display = 'none';
        
        // Validate file size (1 MB = 1048576 bytes)
        if (file.size > 1048576) {
            uploadError.style.display = 'block';
          fileInput.value = '';
          fileNameDisplay.textContent = '';
          return;
        }
        
        // Validate file type
        const validTypes = ['image/jpeg', 'image/jpg', 'image/png', 'application/pdf'];
        if (!validTypes.includes(file.type)) {
          uploadError.textContent = 'Invalid file type. Please upload a JPG, PNG, or PDF file.';
          uploadError.style.display = 'block';
          fileInput.value = '';
          fileNameDisplay.textContent = '';
          return;
        }
        
        fileNameDisplay.textContent = `Selected: ${file.name}`;
      } else {
        fileNameDisplay.textContent = '';
      }
    });
  }
  
  // Handle form submission
  const form = document.getElementById(`taskForm-${task.id}`);
  form.addEventListener('submit', (e) => {
    e.preventDefault();
    
    // Clear all previous errors
    const errorElements = [
      document.getElementById(`country-error-${task.id}`),
      document.getElementById(`school-error-${task.id}`),
      document.getElementById(`school-name-error-${task.id}`),
      document.getElementById(`school-address-error-${task.id}`)
    ];
    if (!isAiModalForm) {
      errorElements.push(document.getElementById(`upload-error-${task.id}`));
    }
    errorElements.forEach(el => el && (el.style.display = 'none'));
    
    let hasError = false;
    
    // Validate country
    if (!countrySelect.value) {
      document.getElementById(`country-error-${task.id}`).style.display = 'block';
      hasError = true;
    }
    
    // Validate school (only if dropdown is visible)
    if (schoolDropdownGroup.style.display !== 'none' && !schoolDropdown.value) {
      document.getElementById(`school-error-${task.id}`).style.display = 'block';
      hasError = true;
    }
    
    // Validate school name (only if field is visible and not readonly)
    if (schoolNameGroup.style.display !== 'none' && !schoolNameInput.value.trim()) {
      document.getElementById(`school-name-error-${task.id}`).style.display = 'block';
      hasError = true;
    }
    
    // Validate school address (only if field is visible and not readonly)
    if (schoolAddressGroup.style.display !== 'none' && !schoolAddressInput.value.trim()) {
      document.getElementById(`school-address-error-${task.id}`).style.display = 'block';
      hasError = true;
    }
    
    // Validate file upload (only for are-you-teacher form)
    let file = null;
    if (!isAiModalForm) {
      const fileInput = document.getElementById(`form-school-id-${task.id}`);
      file = fileInput.files[0];
      if (!file) {
        document.getElementById(`upload-error-${task.id}`).style.display = 'block';
        hasError = true;
      }
    }
    
    // If there are errors, stop submission
    if (hasError) {
      return;
    }
    
    const formData = new FormData(form);
    const data = Object.fromEntries(formData.entries());
    
    // Get selected school from dropdown
    const selectedSchool = schoolDropdown.value;
    
    // Dispatch custom event with form data
    window.dispatchEvent(new CustomEvent('onboarding:formSubmitted', {
      detail: { taskId: task.id, taskLabel: task.label, formData: data, fileName: file ? file.name : null, ts: Date.now() }
    }));
    
    const modalBody = document.getElementById('modalBody');
    
    // Check if school has admin and show appropriate message
    let successMessage = '';
    
    if (selectedSchool === 'Austria-ABC') {
      // Special modal for Austria-ABC
      successMessage = `
        <div class="form-success">
          <svg viewBox="0 0 24 24" fill="none" class="success-icon">
            <circle cx="12" cy="12" r="10" stroke="#16a34a" stroke-width="2" fill="none"/>
            <path d="M9 12l2 2 4-4" stroke="#16a34a" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <h3>Successfully Joined School!</h3>
          <p>You have successfully joined <strong>Austria-ABC</strong>. You can now start creating classes and managing your students.</p>
          <div class="form-actions" style="justify-content: center; margin-top: 20px;">
            <button class="form-cancel-btn" id="later-btn-${task.id}">Later</button>
            <button class="form-submit-btn" id="create-class-btn-${task.id}">Create Class</button>
          </div>
        </div>
      `;
    } else if (isAiModalForm) {
      // Custom message for create-choose-school form
      successMessage = `
        <div class="form-success">
          <svg viewBox="0 0 24 24" fill="none" class="success-icon">
            <circle cx="12" cy="12" r="10" stroke="#16a34a" stroke-width="2" fill="none"/>
            <path d="M9 12l2 2 4-4" stroke="#16a34a" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <h3>Application Submitted Successfully!</h3>
          <p>Thank you for your application! We will review your request within 1-3 business days and send you an email confirmation once your school setup is complete.</p>
          <button class="form-cancel-btn">Close</button>
        </div>
      `;
    } else if (selectedSchool && selectedSchool !== 'create-new' && schoolAdmins[selectedSchool]) {
      // School has admin - show pending approval message
      successMessage = `
        <div class="form-success">
          <svg viewBox="0 0 24 24" fill="none" class="success-icon">
            <circle cx="12" cy="12" r="10" stroke="#2563eb" stroke-width="2" fill="none"/>
            <path d="M12 8v4M12 16h.01" stroke="#2563eb" stroke-width="2" stroke-linecap="round"/>
          </svg>
          <h3>Application Submitted</h3>
          <p>Your application for teacher role has been submitted and pending <strong>${schoolAdmins[selectedSchool]}</strong> for approval.</p>
          <button class="form-cancel-btn">Close</button>
        </div>
      `;
    } else {
      // New school or school without admin - show success message
      successMessage = `
        <div class="form-success">
          <svg viewBox="0 0 24 24" fill="none" class="success-icon">
            <circle cx="12" cy="12" r="10" stroke="#16a34a" stroke-width="2" fill="none"/>
            <path d="M9 12l2 2 4-4" stroke="#16a34a" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <h3>Application Submitted Successfully!</h3>
          <p>Thank you for submitting the teacher role application. We will review and approve the request in 1-3 working days. The application result will be sent to your email upon approval.</p>
          <button class="form-cancel-btn">Close</button>
        </div>
      `;
    }
    
    // Show success message
    modalBody.innerHTML = successMessage;
    
    // Handle Austria-ABC buttons
    const laterBtn = document.getElementById(`later-btn-${task.id}`);
    const createClassBtn = document.getElementById(`create-class-btn-${task.id}`);
    
    if (laterBtn) {
      laterBtn.addEventListener('click', () => {
        closeModal();
      });
    }
    
    if (createClassBtn) {
      createClassBtn.addEventListener('click', () => {
        // Update modal title
        const modalTitle = document.getElementById('modalTitle');
        if (modalTitle) {
          modalTitle.textContent = 'Class';
        }
        setupCreateClassFormFromAustria(task);
      });
    }
    
    // Handle close button
    const closeBtn = modalBody.querySelector('.form-cancel-btn');
    if (closeBtn) {
      closeBtn.addEventListener('click', () => {
        closeModal();
      });
    }
  });
  
  // Handle cancel button
  const modalBody = document.getElementById('modalBody');
  const cancelBtn = modalBody.querySelector('.form-cancel-btn');
  if (cancelBtn) {
    cancelBtn.addEventListener('click', closeModal);
  }
}

function setupCreateClassForm(task) {
  const modalBody = document.getElementById('modalBody');
  const modalBackdrop = document.getElementById('modalBackdrop');
  
  // Sample class data - students distributed uniquely across classes
  const classData = [
    { name: '1', users: 0, grade: 1, teacher: 'Teacher-Class 1', assistant: '', classCode: 'A1B2C3D4', students: [] },
    { name: '2', users: 0, grade: 2, teacher: 'Teacher-Class 2', assistant: '', classCode: 'E5F6G7H8', students: [] },
    { name: '3', users: 0, grade: 3, teacher: 'Teacher-Class 3', assistant: '', classCode: 'I9J0K1L2', students: [] },
    { name: '4', users: 0, grade: 4, teacher: 'Teacher-Class 4', assistant: '', classCode: 'M3N4O5P6', students: [] },
    { name: '5', users: 0, grade: 5, teacher: 'Teacher-Class 5', assistant: '', classCode: 'Q7R8S9T0', students: [] },
    { name: '6', users: 10, grade: 1, teacher: 'Teacher-Class 1', assistant: 'Teacher-Class 2', classCode: 'U1V2W3X4', students: ['Student01', 'Student02', 'Student03', 'Student04', 'Student05', 'Student06', 'Student07', 'Student08', 'Student09', 'Student10'] }
  ];
  
  let filteredData = [...classData];
  let lastCheckedRadio = null;
  
  // Load user's joined class from sessionStorage
  let currentUserClass = null;
  const savedClass = sessionStorage.getItem('userJoinedClass');
  if (savedClass) {
    try {
      const parsedClass = JSON.parse(savedClass);
      // Find the class in classData to ensure it still exists
      currentUserClass = classData.find(c => c.name === parsedClass.name && c.grade === parsedClass.grade);
    } catch (e) {
      console.error('Error loading joined class:', e);
    }
  }
  
  // Show class list view
  function showClassListView() {
    // Determine current user's class
    const userClassName = currentUserClass ? currentUserClass.name : 'Not Joined';
    
    modalBody.innerHTML = `
      <div class="task-form-container">
        <div style="padding: 12px 16px; background: #f3f4f6; border-radius: 8px; margin-bottom: 16px;">
          <span style="font-weight: 600; color: #374151;">My Class:</span> 
          <span id="user-class-display-${task.id}" style="color: #1f2937; font-weight: 500;">${userClassName}</span>
        </div>
        
        <p class="task-form-description">Join and manage your existing classes. Give the 8-character Class code to your students to join the school and class directly.</p>
        
        <div class="class-toolbar" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px;">
          <div style="display: flex; align-items: center; gap: 12px;">
            <label for="grade-filter-toolbar-${task.id}" style="font-size: 14px; color: #374151; font-weight: 500;">Filter by:</label>
            <select id="grade-filter-toolbar-${task.id}" style="padding: 6px 12px; border: 1px solid #d1d5db; border-radius: 6px; font-size: 14px; color: #374151;">
              <option value="all">All Grades</option>
              <option value="1">Grade 1</option>
              <option value="2">Grade 2</option>
              <option value="3">Grade 3</option>
              <option value="4">Grade 4</option>
              <option value="5">Grade 5</option>
              <option value="6">Grade 6</option>
            </select>
          </div>
          <div class="class-action-buttons" id="class-action-buttons-${task.id}" style="display: none;">
            <button type="button" class="join-class-btn" id="join-class-btn-${task.id}" style="background: #10b981; color: white; padding: 8px 16px; border: none; border-radius: 6px; cursor: pointer; font-size: 14px; font-weight: 500; margin-right: 8px;">Join</button>
            <button type="button" class="manage-class-btn" id="manage-class-btn-${task.id}" style="background: #3b82f6; color: white; padding: 8px 16px; border: none; border-radius: 6px; cursor: pointer; font-size: 14px; font-weight: 500;">Edit</button>
          </div>
        </div>
        
        <div class="class-list-container"></div>
        
        <div class="form-actions">
          <button type="button" class="form-submit-btn" id="close-btn-${task.id}">Close</button>
        </div>
      </div>
    `;
    
    const classActionButtons = document.getElementById(`class-action-buttons-${task.id}`);
    const joinClassBtn = document.getElementById(`join-class-btn-${task.id}`);
    const manageClassBtn = document.getElementById(`manage-class-btn-${task.id}`);
    const closeBtnMain = document.getElementById(`close-btn-${task.id}`);
    const gradeFilterToolbar = document.getElementById(`grade-filter-toolbar-${task.id}`);
    const userClassDisplay = document.getElementById(`user-class-display-${task.id}`);
    
    // Function to update user class display
    function updateUserClassDisplay() {
      const userClassName = currentUserClass ? currentUserClass.name : 'Not Joined';
      userClassDisplay.textContent = userClassName;
    }
    
    // Render class table
    function renderClassTable() {
      const tableContainer = document.querySelector('.class-list-container');
      
      // If no classes found, show message and hide table
      if (filteredData.length === 0) {
        tableContainer.innerHTML = '<div style="text-align: center; padding: 40px; color: #6b7280; font-size: 14px;">No classes found.</div>';
        return;
      }
      
      // Create or restore table if it doesn't exist
      if (!tableContainer.querySelector('table')) {
        tableContainer.innerHTML = `
          <table class="class-table">
            <thead>
              <tr>
                <th class="radio-column"></th>
                <th>Grade</th>
                <th>Class Name</th>
                <th>No. of Students</th>
                <th>Class Code</th>
              </tr>
            </thead>
            <tbody id="class-table-body-${task.id}"></tbody>
          </table>
        `;
      }
      
      // Now get the table body and clear it
      const tableBody = document.getElementById(`class-table-body-${task.id}`);
      tableBody.innerHTML = '';
      
      filteredData.forEach((classItem, index) => {
        const row = document.createElement('tr');
        const isChecked = lastCheckedRadio === classItem.name ? 'checked' : '';
        const classCode = classItem.classCode || 'N/A';
        row.innerHTML = `
          <td class="radio-column">
            <input type="radio" name="class-selection-${task.id}" class="class-row-radio" data-index="${index}" value="${classItem.name}" ${isChecked}>
          </td>
          <td>${classItem.grade}</td>
          <td>${classItem.name}</td>
          <td>${classItem.users}</td>
          <td>
            <div style="display: flex; align-items: center; gap: 8px; position: relative; justify-content: flex-end;">
              <span style="font-weight: bold;">${classCode}</span>
              ${classCode !== 'N/A' ? `<button class="copy-code-btn" data-code="${classCode}" title="Copy code" style="padding: 6px 8px; background: #3b82f6; color: white; border: none; border-radius: 4px; cursor: pointer; display: flex; align-items: center; justify-content: center;"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path></svg></button>` : ''}
            </div>
          </td>
        `;
        tableBody.appendChild(row);
      });
      
      // Add copy button listeners
      const copyButtons = tableBody.querySelectorAll('.copy-code-btn');
      copyButtons.forEach(btn => {
        btn.addEventListener('click', (e) => {
          e.stopPropagation();
          const code = btn.getAttribute('data-code');
          navigator.clipboard.writeText(code).then(() => {
            // Create tooltip
            const tooltip = document.createElement('div');
            tooltip.textContent = 'Copied!';
            tooltip.style.cssText = 'position: absolute; top: -35px; left: 50%; transform: translateX(-50%); background: #16a34a; color: white; padding: 6px 12px; border-radius: 6px; font-size: 12px; white-space: nowrap; opacity: 0; transition: opacity 0.3s ease-in-out; pointer-events: none; z-index: 1000;';

            const container = btn.parentElement;
            container.appendChild(tooltip);

            // Trigger fade-in
            setTimeout(() => {
              tooltip.style.opacity = '1';
            }, 10);

            // Fade out and remove
            setTimeout(() => {
              tooltip.style.opacity = '0';
              setTimeout(() => {
                if (tooltip.parentElement) {
                  tooltip.parentElement.removeChild(tooltip);
                }
              }, 300);
            }, 2000);
          }).catch(err => {
            console.error('Failed to copy:', err);
            alert('Failed to copy code');
          });
        });
      });
      
      // Add email button listeners
      const emailButtons = tableBody.querySelectorAll('.email-code-btn');
      emailButtons.forEach(btn => {
        btn.addEventListener('click', (e) => {
          e.stopPropagation();
          const code = btn.getAttribute('data-code');
          const users = btn.getAttribute('data-users');
          const className = btn.getAttribute('data-classname');
          
          if (users > 0) {
            // Check if email was recently sent for this class
            const cooldownInfo = checkEmailCooldown(code);
            if (cooldownInfo.canSend) {
              showEmailConfirmationModal(code, users, className, showClassListView);
            } else {
              showEmailRestrictionModal(code, className, cooldownInfo.nextSendTime, showClassListView);
            }
          }
        });
      });
      
      setupRadioListeners();
    }
    
    function setupRadioListeners() {
      const radioButtons = document.querySelectorAll(`input[name="class-selection-${task.id}"]`);
      
      radioButtons.forEach(radio => {
        if (radio.checked) {
          lastCheckedRadio = radio.value;
          if (classActionButtons) classActionButtons.style.display = 'flex';
        }
      });
      
      radioButtons.forEach(radio => {
        radio.addEventListener('click', (e) => {
          if (lastCheckedRadio === radio.value && radio.checked) {
            radio.checked = false;
            lastCheckedRadio = null;
            if (classActionButtons) classActionButtons.style.display = 'none';
          } else {
            lastCheckedRadio = radio.value;
            if (classActionButtons) classActionButtons.style.display = 'flex';
          }
        });
      });
    }
    
    // Handle grade filter
    function applyGradeFilter() {
      const selectedGrade = gradeFilterToolbar.value;
      
      if (selectedGrade === 'all') {
        filteredData = [...classData];
      } else {
        filteredData = classData.filter(classItem => 
          classItem.grade.toString() === selectedGrade
        );
      }
      
      // Hide action buttons when filter changes
      if (classActionButtons) classActionButtons.style.display = 'none';
      lastCheckedRadio = null;
      
      renderClassTable();
    }
    
    gradeFilterToolbar.addEventListener('change', applyGradeFilter);
    
    // Render class table on load
    renderClassTable();
    
    joinClassBtn.addEventListener('click', () => {
      const selectedRadio = document.querySelector(`input[name="class-selection-${task.id}"]:checked`);
      if (selectedRadio) {
        const selectedIndex = parseInt(selectedRadio.getAttribute('data-index'));
        const selectedClass = filteredData[selectedIndex];
        
        // Set current user's class
        currentUserClass = selectedClass;
        
        // Save to sessionStorage
        sessionStorage.setItem('userJoinedClass', JSON.stringify({
          name: selectedClass.name,
          grade: selectedClass.grade,
          teacher: selectedClass.teacher,
          classCode: selectedClass.classCode
        }));
        
        // Update display
        updateUserClassDisplay();
        
        // Show success message
        const successMsg = document.createElement('div');
        successMsg.style.cssText = 'position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%); background: #10b981; color: white; padding: 20px 40px; border-radius: 8px; font-size: 16px; font-weight: 500; z-index: 10001; box-shadow: 0 4px 6px rgba(0,0,0,0.2);';
        successMsg.textContent = `Successfully joined Class ${selectedClass.name}!`;
        document.body.appendChild(successMsg);
        
        setTimeout(() => {
          successMsg.style.opacity = '0';
          successMsg.style.transition = 'opacity 0.3s';
          setTimeout(() => document.body.removeChild(successMsg), 300);
        }, 2000);
      }
    });
    
    manageClassBtn.addEventListener('click', () => {
      const selectedRadio = document.querySelector(`input[name="class-selection-${task.id}"]:checked`);
      if (selectedRadio) {
        const selectedIndex = parseInt(selectedRadio.getAttribute('data-index'));
        showCreateForm(filteredData[selectedIndex]);
      }
    });
    
    closeBtnMain.addEventListener('click', closeModal);
  }
  
  // Show delete confirmation
  function showDeleteConfirmation(classToDelete) {
    const confirmationHtml = `
      <div class="task-form-container">
        <div class="delete-confirmation">
          <div class="warning-icon">!</div>
          <h3>Delete Class?</h3>
          <p>Are you sure you want to delete <strong>${classToDelete.name}</strong>? This action cannot be undone.</p>
          <div class="confirmation-actions">
            <button class="confirmation-cancel-btn">Cancel</button>
            <button class="confirmation-delete-btn">Delete</button>
          </div>
        </div>
      </div>
    `;
    
    modalBody.innerHTML = confirmationHtml;
    
    // Handle Cancel button
    const cancelBtn = modalBody.querySelector('.confirmation-cancel-btn');
    cancelBtn.addEventListener('click', showClassListView);
    
    // Handle Delete button
    const deleteBtn = modalBody.querySelector('.confirmation-delete-btn');
    deleteBtn.addEventListener('click', () => {
      // Find and remove the class from classData
      const classIndex = classData.findIndex(c => 
        c.name === classToDelete.name && 
        c.grade === classToDelete.grade && 
        c.teacher === classToDelete.teacher
      );
      
      if (classIndex !== -1) {
        classData.splice(classIndex, 1);
      }
      
      // Reset lastCheckedRadio since we deleted the selected item
      lastCheckedRadio = null;
      
      // Restore list view with updated data
      filteredData = [...classData];
      showClassListView();
    });
  }
  
  // Step 2b: Show create/edit form (New Class path)
  function showCreateForm(existingClass = null) {
    const isEditMode = existingClass !== null;
    const formTitle = isEditMode ? 'Edit Class' : 'Create New Class';
    
    // Get unique teachers from existing classes, or use default list if no classes exist
    let teachers = [...new Set(classData.map(c => c.teacher).filter(t => t && t.trim() !== ''))];
    if (teachers.length === 0) {
      // Default teacher list when no classes exist
      teachers = ['Teacher A', 'Teacher B', 'Teacher C', 'Teacher D', 'Teacher E'];
    }
    const teacherOptions = teachers.map(t => `<option value="${t}">${t}</option>`).join('');
    
    // Get all students already assigned to other classes with class name mapping
    const studentToClassMap = new Map();
    classData.forEach(c => {
      if (c.name !== (existingClass?.name)) {
        c.students?.forEach(s => studentToClassMap.set(s, c.name));
      }
    });
    
    // Generate student table rows with disabled state for assigned students
    const studentRows = Array.from({length: 10}, (_, i) => {
      const studentName = `Student${String(i + 1).padStart(2, '0')}`;
      const assignedClassName = studentToClassMap.get(studentName);
      const isAssigned = assignedClassName !== undefined;
      const isSelected = existingClass?.students?.includes(studentName) || false;
      const disabledAttr = isAssigned ? 'disabled' : '';
      const checkedAttr = isSelected ? 'checked' : '';
      const rowClass = isAssigned ? 'style="opacity: 0.5;"' : '';
      return `
        <tr ${rowClass}>
          <td class="checkbox-column">
            <input type="checkbox" id="student-${i}-${task.id}" class="student-checkbox" value="${studentName}" ${checkedAttr} ${disabledAttr}>
          </td>
          <td>${studentName}${isAssigned ? ` (Assigned to Class ${assignedClassName})` : ''}</td>
        </tr>
      `;
    }).join('');
    
    modalBody.innerHTML = `
      <div class="task-form-container">
        <p class="task-form-description">You can change the class name and add or remove students for this class.</p>
        
        <div class="form-group">
          <label for="new-class-name-${task.id}">Class Name:</label>
          <input type="text" id="new-class-name-${task.id}" placeholder="Enter class name" value="${existingClass ? existingClass.name : ''}">
          <div class="form-error" id="class-name-error-${task.id}" style="display: none;">Please enter a Class Name</div>
        </div>
        
        <div class="form-group">
          <label>No. of Students Selected <strong id="student-count-${task.id}">0</strong>:</label>
          <div class="student-table-container">
            <table class="student-table">
              <thead>
                <tr>
                  <th class="checkbox-column">
                    <input type="checkbox" id="select-all-students-${task.id}" class="select-all-checkbox">
                  </th>
                  <th>Student Name</th>
                </tr>
              </thead>
              <tbody id="student-table-body-${task.id}">
                ${studentRows}
              </tbody>
            </table>
          </div>
        </div>
        
        <div class="form-actions" style="display: flex; gap: 12px;">
          <button type="button" class="form-cancel-btn" id="back-create-${task.id}" style="flex: 1;">Back</button>
          <button type="button" class="form-submit-btn" id="save-create-${task.id}" style="flex: 1;">Save</button>
        </div>
      </div>
    `;
    
    // Set values if editing
    if (existingClass) {
      if (existingClass.users > 0) {
        const allCheckboxes = Array.from(document.querySelectorAll('.student-checkbox'));
        const shuffled = allCheckboxes.sort(() => 0.5 - Math.random());
        const selected = shuffled.slice(0, existingClass.users);
        selected.forEach(cb => cb.checked = true);
      }
    }
    
    const backCreateBtn = document.getElementById(`back-create-${task.id}`);
    // Go back to class list view
    backCreateBtn.addEventListener('click', () => {
      showClassListView();
    });
    
    const selectAllCheckbox = document.getElementById(`select-all-students-${task.id}`);
    const studentCheckboxes = document.querySelectorAll('.student-checkbox');
    const studentCountDisplay = document.getElementById(`student-count-${task.id}`);
    
    function updateStudentCount() {
      const checkedCount = Array.from(studentCheckboxes).filter(cb => cb.checked).length;
      studentCountDisplay.textContent = checkedCount;
    }
    
    updateStudentCount();
    
    selectAllCheckbox.addEventListener('change', (e) => {
      studentCheckboxes.forEach(checkbox => checkbox.checked = e.target.checked);
      updateStudentCount();
    });
    
    studentCheckboxes.forEach(checkbox => {
      checkbox.addEventListener('change', () => {
        const allChecked = Array.from(studentCheckboxes).every(cb => cb.checked);
        const someChecked = Array.from(studentCheckboxes).some(cb => cb.checked);
        selectAllCheckbox.checked = allChecked;
        selectAllCheckbox.indeterminate = someChecked && !allChecked;
        updateStudentCount();
      });
    });
    
    const saveBtn = document.getElementById(`save-create-${task.id}`);
    saveBtn.addEventListener('click', () => {
      const className = document.getElementById(`new-class-name-${task.id}`).value.trim();
      
      const errorElement = document.getElementById(`class-name-error-${task.id}`);
      errorElement.style.display = 'none';
      
      if (!className) {
        errorElement.style.display = 'block';
        return;
      }
      
      const selectedStudents = Array.from(document.querySelectorAll('.student-checkbox:checked'))
        .map(cb => cb.value);
      const userCount = selectedStudents.length;
      
      // Generate random 8-character alphanumeric class code
      function generateClassCode() {
        const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
        let code = '';
        for (let i = 0; i < 8; i++) {
          code += chars.charAt(Math.floor(Math.random() * chars.length));
        }
        return code;
      }
      
      const classObj = {
        name: className,
        description: existingClass ? existingClass.description : '',
        users: userCount,
        grade: existingClass ? existingClass.grade : 1,
        teacher: existingClass ? existingClass.teacher : '',
        assistant: existingClass ? existingClass.assistant : '',
        classCode: existingClass ? existingClass.classCode : generateClassCode(),
        students: selectedStudents
      };
      
      if (isEditMode && existingClass) {
        const classIndex = classData.findIndex(c => 
          c.name === existingClass.name && c.grade === existingClass.grade
        );
        if (classIndex !== -1) {
          classData[classIndex] = classObj;
        }
      } else {
        classData.push(classObj);
      }
      
      filteredData = [...classData];
      showClassListView();
    });
  }
  
  modalBackdrop.classList.add('show');
  modalBackdrop.setAttribute('aria-hidden', 'false');
  
  // Show class list view
  showClassListView();
}

// Duplicated function for Austria-ABC school workflow
function setupCreateClassFormFromAustria(task) {
  const modalBody = document.getElementById('modalBody');
  const modalBackdrop = document.getElementById('modalBackdrop');
  
  // Sample class data - students distributed uniquely across classes
  const classData = [
    { name: '1', users: 0, grade: 1, teacher: 'Teacher-Class 1', assistant: '', classCode: 'A1B2C3D4', students: [] },
    { name: '2', users: 0, grade: 2, teacher: 'Teacher-Class 2', assistant: '', classCode: 'E5F6G7H8', students: [] },
    { name: '3', users: 0, grade: 3, teacher: 'Teacher-Class 3', assistant: '', classCode: 'I9J0K1L2', students: [] },
    { name: '4', users: 0, grade: 4, teacher: 'Teacher-Class 4', assistant: '', classCode: 'M3N4O5P6', students: [] },
    { name: '5', users: 0, grade: 5, teacher: 'Teacher-Class 5', assistant: '', classCode: 'Q7R8S9T0', students: [] },
    { name: '6', users: 10, grade: 1, teacher: 'Teacher-Class 1', assistant: 'Teacher-Class 2', classCode: 'U1V2W3X4', students: ['Student01', 'Student02', 'Student03', 'Student04', 'Student05', 'Student06', 'Student07', 'Student08', 'Student09', 'Student10'] },
    { name: 'ABC', users: 0, grade: 1, teacher: 'Teacher-Cclass 1', assistant: 'Teacher-Class 2', classCode: 'V1W2X3Y4', students: [] },
    { name: 'DEF', users: 0, grade: 2, teacher: 'Teacher-Class 2', assistant: 'Teacher-Class 4', classCode: 'Y5Z6A7B8', students: [] },
    { name: 'GHI', users: 0, grade: 3, teacher: 'Teacher-Class 3', assistant: 'Teacher-Class 1', classCode: 'C9D0E1F2', students: [] },
    { name: 'JKL', users: 0, grade: 4, teacher: 'Teacher-Class 4', assistant: 'Teacher-Class 5', classCode: 'G3H4I5J6', students: [] },
    { name: 'MNO', users: 0, grade: 5, teacher: 'Teacher-Class 5', assistant: 'Teacher-Class 3', classCode: 'K7L8M9N0', students: [] }
  ];
  
  let filteredData = [...classData];
  let lastCheckedRadio = null;
  
  // Load user's joined class from sessionStorage
  let currentUserClass = null;
  const savedClass = sessionStorage.getItem('userJoinedClass');
  if (savedClass) {
    try {
      const parsedClass = JSON.parse(savedClass);
      // Find the class in classData to ensure it still exists
      currentUserClass = classData.find(c => c.name === parsedClass.name && c.grade === parsedClass.grade);
    } catch (e) {
      console.error('Error loading joined class:', e);
    }
  }
  
  // Show class list view (page 1) - Austria workflow
  function showClassListView() {
    // Determine current user's class
    const userClassName = currentUserClass ? currentUserClass.name : 'Not Joined';
    
    modalBody.innerHTML = `
      <div class="task-form-container">
        <div style="padding: 12px 16px; background: #f3f4f6; border-radius: 8px; margin-bottom: 16px;">
          <span style="font-weight: 600; color: #374151;">My Class:</span> 
          <span id="user-class-display-${task.id}" style="color: #1f2937; font-weight: 500;">${userClassName}</span>
        </div>
        
        <p class="task-form-description">Join and manage your existing classes. Give the 8-character Class code to your students to join the school and class directly.</p>
        
        <div class="class-filters">
          <div class="filter-group">
            <label for="grade-filter-${task.id}">Grade:</label>
            <select id="grade-filter-${task.id}">
              <option value="all">All</option>
              <option value="1">Grade 1</option>
              <option value="2">Grade 2</option>
              <option value="3">Grade 3</option>
              <option value="4">Grade 4</option>
              <option value="5">Grade 5</option>
              <option value="6">Grade 6</option>
              <option value="7">Grade 7</option>
              <option value="8">Grade 8</option>
              <option value="9">Grade 9</option>
              <option value="10">Grade 10</option>
              <option value="11">Grade 11</option>
            </select>
          </div>
          
          <div class="filter-group">
            <label for="class-name-filter-${task.id}">Class Name:</label>
            <input type="text" id="class-name-filter-${task.id}" placeholder="Search class name">
          </div>
          
          <div class="filter-actions">
            <button type="button" class="filter-reset-btn" id="reset-filter-${task.id}">Reset</button>
            <button type="button" class="filter-search-btn" id="search-filter-${task.id}">Search</button>
          </div>
        </div>
        
        <div class="class-toolbar">
          <button type="button" class="create-class-btn" id="create-class-btn-${task.id}">Create Class</button>
          <div class="class-action-buttons" id="class-action-buttons-${task.id}" style="display: none;">
            <button type="button" class="join-class-btn" id="join-class-btn-${task.id}" style="background: #10b981; color: white; padding: 8px 16px; border: none; border-radius: 6px; cursor: pointer; font-size: 14px; font-weight: 500; margin-right: 8px;">Join</button>
            <button type="button" class="manage-class-btn" id="manage-class-btn-${task.id}" style="background: #3b82f6; color: white; padding: 8px 16px; border: none; border-radius: 6px; cursor: pointer; font-size: 14px; font-weight: 500;">Edit</button>
            <button type="button" class="delete-class-btn" id="delete-class-btn-${task.id}">Delete</button>
          </div>
        </div>
        
        <div class="class-list-container">
          <table class="class-table">
            <thead>
              <tr>
                <th class="radio-column"></th>
                <th>Class Name</th>
                <th>No. of Students</th>
                <th>Grade</th>
                <th>Class Code</th>
              </tr>
            </thead>
            <tbody id="class-table-body-${task.id}"></tbody>
          </table>
        </div>
        
        <div class="form-actions">
          <button type="button" class="form-cancel-btn">Close</button>
        </div>
      </div>
    `;
    
    const gradeFilter = document.getElementById(`grade-filter-${task.id}`);
    const classNameFilter = document.getElementById(`class-name-filter-${task.id}`);
    const resetBtn = document.getElementById(`reset-filter-${task.id}`);
    const searchBtn = document.getElementById(`search-filter-${task.id}`);
    const createClassBtn = document.getElementById(`create-class-btn-${task.id}`);
    const classActionButtons = document.getElementById(`class-action-buttons-${task.id}`);
    const joinClassBtn = document.getElementById(`join-class-btn-${task.id}`);
    const manageClassBtn = document.getElementById(`manage-class-btn-${task.id}`);
    const deleteClassBtn = document.getElementById(`delete-class-btn-${task.id}`);
    const userClassDisplay = document.getElementById(`user-class-display-${task.id}`);
    
    // Function to update user class display
    function updateUserClassDisplay() {
      const userClassName = currentUserClass ? currentUserClass.name : 'Not Joined';
      userClassDisplay.textContent = userClassName;
    }
    
    // Render class table
    function renderClassTable() {
      const tableBody = document.getElementById(`class-table-body-${task.id}`);
      const tableContainer = document.querySelector('.class-list-container');
      tableBody.innerHTML = '';
      
      // If no classes found, show message and hide table
      if (filteredData.length === 0) {
        tableContainer.innerHTML = '<div style="text-align: center; padding: 40px; color: #6b7280; font-size: 14px;">No classes found. Click "Create Class" to add your first class.</div>';
        return;
      }
      
      // Restore table if it was hidden
      if (!tableContainer.querySelector('table')) {
        tableContainer.innerHTML = `
          <table class="class-table">
            <thead>
              <tr>
                <th class="radio-column"></th>
                <th>Class Name</th>
                <th>No. of Students</th>
                <th>Grade</th>
                <th>Class Code</th>
              </tr>
            </thead>
            <tbody id="class-table-body-${task.id}"></tbody>
          </table>
        `;
      }
      
      filteredData.forEach((classItem, index) => {
        const row = document.createElement('tr');
        const isChecked = lastCheckedRadio === classItem.name ? 'checked' : '';
        const classCode = classItem.classCode || 'N/A';
        row.innerHTML = `
          <td class="radio-column">
            <input type="radio" name="class-selection-${task.id}" class="class-row-radio" data-index="${index}" value="${classItem.name}" ${isChecked}>
          </td>
          <td>${classItem.name}</td>
          <td>${classItem.users}</td>
          <td>${classItem.grade}</td>
          <td>
            <div style="display: flex; align-items: center; gap: 8px; position: relative; justify-content: flex-end;">
              <span style="font-weight: bold;">${classCode}</span>
              ${classCode !== 'N/A' ? `<button class="copy-code-btn" data-code="${classCode}" title="Copy code" style="padding: 6px 8px; background: #3b82f6; color: white; border: none; border-radius: 4px; cursor: pointer; display: flex; align-items: center; justify-content: center;"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path></svg></button>` : ''}
            </div>
          </td>
        `;
        tableBody.appendChild(row);
      });
      
      // Add copy button listeners
      const copyButtons = tableBody.querySelectorAll('.copy-code-btn');
      copyButtons.forEach(btn => {
        btn.addEventListener('click', (e) => {
          e.stopPropagation();
          const code = btn.getAttribute('data-code');
          navigator.clipboard.writeText(code).then(() => {
            // Create tooltip
            const tooltip = document.createElement('div');
            tooltip.textContent = 'Copied!';
            tooltip.style.cssText = 'position: absolute; top: -35px; left: 50%; transform: translateX(-50%); background: #16a34a; color: white; padding: 6px 12px; border-radius: 6px; font-size: 12px; white-space: nowrap; opacity: 0; transition: opacity 0.3s ease-in-out; pointer-events: none; z-index: 1000;';

            const container = btn.parentElement;
            container.appendChild(tooltip);

            // Trigger fade-in
            setTimeout(() => {
              tooltip.style.opacity = '1';
            }, 10);

            // Fade out and remove
            setTimeout(() => {
              tooltip.style.opacity = '0';
              setTimeout(() => {
                if (tooltip.parentElement) {
                  tooltip.parentElement.removeChild(tooltip);
                }
              }, 300);
            }, 2000);
          }).catch(err => {
            console.error('Failed to copy:', err);
            alert('Failed to copy code');
          });
        });
      });
      
      // Add email button listeners
      const emailButtons = tableBody.querySelectorAll('.email-code-btn');
      emailButtons.forEach(btn => {
        btn.addEventListener('click', (e) => {
          e.stopPropagation();
          const code = btn.getAttribute('data-code');
          const users = btn.getAttribute('data-users');
          const className = btn.getAttribute('data-classname');
          
          if (users > 0) {
            // Check if email was recently sent for this class
            const cooldownInfo = checkEmailCooldown(code);
            if (cooldownInfo.canSend) {
              showEmailConfirmationModal(code, users, className, showClassListView);
            } else {
              showEmailRestrictionModal(code, className, cooldownInfo.nextSendTime, showClassListView);
            }
          }
        });
      });
      
      setupRadioListeners();
    }
    
    function setupRadioListeners() {
      const radioButtons = document.querySelectorAll(`input[name="class-selection-${task.id}"]`);
      
      radioButtons.forEach(radio => {
        if (radio.checked) {
          lastCheckedRadio = radio.value;
          createClassBtn.style.display = 'none';
          classActionButtons.style.display = 'flex';
        }
      });
      
      radioButtons.forEach(radio => {
        radio.addEventListener('click', (e) => {
          if (lastCheckedRadio === radio.value && radio.checked) {
            radio.checked = false;
            lastCheckedRadio = null;
            createClassBtn.style.display = 'block';
            classActionButtons.style.display = 'none';
          } else {
            lastCheckedRadio = radio.value;
            createClassBtn.style.display = 'none';
            classActionButtons.style.display = 'flex';
          }
        });
      });
    }
    
    function filterClasses() {
      const gradeValue = gradeFilter.value;
      const nameValue = classNameFilter.value.toLowerCase().trim();
      
      filteredData = classData.filter(classItem => {
        const matchesGrade = gradeValue === 'all' || classItem.grade.toString() === gradeValue;
        const matchesName = nameValue === '' || classItem.name.toLowerCase().includes(nameValue);
        return matchesGrade && matchesName;
      });
      
      renderClassTable();
    }
    
    searchBtn.addEventListener('click', filterClasses);
    resetBtn.addEventListener('click', () => {
      gradeFilter.value = 'all';
      classNameFilter.value = '';
      filteredData = [...classData];
      renderClassTable();
    });
    
    classNameFilter.addEventListener('keypress', (e) => {
      if (e.key === 'Enter') filterClasses();
    });
    
    createClassBtn.addEventListener('click', () => showCreateForm(null));
    
    joinClassBtn.addEventListener('click', () => {
      const selectedRadio = document.querySelector(`input[name="class-selection-${task.id}"]:checked`);
      if (selectedRadio) {
        const selectedIndex = parseInt(selectedRadio.getAttribute('data-index'));
        const selectedClass = filteredData[selectedIndex];
        
        // Set current user's class
        currentUserClass = selectedClass;
        
        // Save to sessionStorage
        sessionStorage.setItem('userJoinedClass', JSON.stringify({
          name: selectedClass.name,
          grade: selectedClass.grade,
          teacher: selectedClass.teacher,
          classCode: selectedClass.classCode
        }));
        
        // Update display
        updateUserClassDisplay();
        
        // Show success message
        const successMsg = document.createElement('div');
        successMsg.style.cssText = 'position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%); background: #10b981; color: white; padding: 20px 40px; border-radius: 8px; font-size: 16px; font-weight: 500; z-index: 10001; box-shadow: 0 4px 6px rgba(0,0,0,0.2);';
        successMsg.textContent = `Successfully joined Class ${selectedClass.name}!`;
        document.body.appendChild(successMsg);
        
        setTimeout(() => {
          successMsg.style.opacity = '0';
          successMsg.style.transition = 'opacity 0.3s';
          setTimeout(() => document.body.removeChild(successMsg), 300);
        }, 2000);
      }
    });
    
    manageClassBtn.addEventListener('click', () => {
      const selectedRadio = document.querySelector(`input[name="class-selection-${task.id}"]:checked`);
      if (selectedRadio) {
        const selectedIndex = parseInt(selectedRadio.getAttribute('data-index'));
        showCreateForm(filteredData[selectedIndex]);
      }
    });
    
    deleteClassBtn.addEventListener('click', () => {
      const selectedRadio = document.querySelector(`input[name="class-selection-${task.id}"]:checked`);
      if (selectedRadio) {
        const selectedIndex = parseInt(selectedRadio.getAttribute('data-index'));
        const selectedClass = filteredData[selectedIndex];
        showDeleteConfirmation(selectedClass);
      }
    });
    
    const closeBtn = modalBody.querySelector('.form-cancel-btn');
    closeBtn.addEventListener('click', closeModal);
    
    renderClassTable();
  }
  
  // Show delete confirmation
  function showDeleteConfirmation(classToDelete) {
    const confirmationHtml = `
      <div class="task-form-container">
        <div class="delete-confirmation">
          <div class="warning-icon">!</div>
          <h3>Delete Class?</h3>
          <p>Are you sure you want to delete <strong>${classToDelete.name}</strong>? This action cannot be undone.</p>
          <div class="confirmation-actions">
            <button class="confirmation-cancel-btn">Cancel</button>
            <button class="confirmation-delete-btn">Delete</button>
          </div>
        </div>
      </div>
    `;
    
    modalBody.innerHTML = confirmationHtml;
    
    // Handle Cancel button
    const cancelBtn = modalBody.querySelector('.confirmation-cancel-btn');
    cancelBtn.addEventListener('click', showClassListView);
    
    // Handle Delete button
    const deleteBtn = modalBody.querySelector('.confirmation-delete-btn');
    deleteBtn.addEventListener('click', () => {
      // Find and remove the class from classData
      const classIndex = classData.findIndex(c => 
        c.name === classToDelete.name && 
        c.grade === classToDelete.grade && 
        c.teacher === classToDelete.teacher
      );
      
      if (classIndex !== -1) {
        classData.splice(classIndex, 1);
      }
      
      // Reset lastCheckedRadio since we deleted the selected item
      lastCheckedRadio = null;
      
      // Restore list view with updated data
      filteredData = [...classData];
      showClassListView();
    });
  }
  
  // Show create/edit form (page 2)
  function showCreateForm(existingClass = null) {
    const isEditMode = existingClass !== null;
    const formTitle = isEditMode ? 'Edit Class' : 'Create New Class';
    
    // Get unique teachers from existing classes, or use default list if no classes exist
    let teachers = [...new Set(classData.map(c => c.teacher).filter(t => t && t.trim() !== ''))];
    if (teachers.length === 0) {
      // Default teacher list when no classes exist
      teachers = ['Teacher A', 'Teacher B', 'Teacher C', 'Teacher D', 'Teacher E'];
    }
    const teacherOptions = teachers.map(t => `<option value="${t}">${t}</option>`).join('');
    
    // Get all students already assigned to other classes with class name mapping
    const studentToClassMap = new Map();
    classData.forEach(c => {
      if (c.name !== (existingClass?.name)) {
        c.students?.forEach(s => studentToClassMap.set(s, c.name));
      }
    });
    
    // Generate student table rows with disabled state for assigned students
    const studentRows = Array.from({length: 10}, (_, i) => {
      const studentName = `Student${String(i + 1).padStart(2, '0')}`;
      const assignedClassName = studentToClassMap.get(studentName);
      const isAssigned = assignedClassName !== undefined;
      const isSelected = existingClass?.students?.includes(studentName) || false;
      const disabledAttr = isAssigned ? 'disabled' : '';
      const checkedAttr = isSelected ? 'checked' : '';
      const rowClass = isAssigned ? 'style="opacity: 0.5;"' : '';
      return `
        <tr ${rowClass}>
          <td class="checkbox-column">
            <input type="checkbox" id="student-${i}-${task.id}" class="student-checkbox" value="${studentName}" ${checkedAttr} ${disabledAttr}>
          </td>
          <td>${studentName}${isAssigned ? ` (Assigned to Class ${assignedClassName})` : ''}</td>
        </tr>
      `;
    }).join('');
    
    modalBody.innerHTML = `
      <div class="task-form-container">
        <h3 class="form-section-title">${formTitle}</h3>
        
        <div class="form-row-2col">
          <div class="form-group">
            <label for="new-class-name-${task.id}">Class Name:</label>
            <input type="text" id="new-class-name-${task.id}" placeholder="Enter class name" value="${existingClass ? existingClass.name : ''}">
            <div class="form-error" id="class-name-error-${task.id}" style="display: none;">Please enter a Class Name</div>
          </div>
          
          <div class="form-group">
            <label for="new-class-desc-${task.id}">Description:</label>
            <textarea id="new-class-desc-${task.id}" placeholder="Enter class description" rows="3">${existingClass && existingClass.description ? existingClass.description : ''}</textarea>
          </div>
        </div>
        
        <div class="form-row-3col">
          <div class="form-group">
            <label for="new-class-grade-${task.id}">Grade:</label>
            <select id="new-class-grade-${task.id}">
              <option value="">Select grade</option>
              <option value="1">Grade 1</option>
              <option value="2">Grade 2</option>
              <option value="3">Grade 3</option>
              <option value="4">Grade 4</option>
              <option value="5">Grade 5</option>
              <option value="6">Grade 6</option>
              <option value="7">Grade 7</option>
              <option value="8">Grade 8</option>
              <option value="9">Grade 9</option>
              <option value="10">Grade 10</option>
              <option value="11">Grade 11</option>
            </select>
            <div class="form-error" id="grade-error-${task.id}" style="display: none;">Please select a Grade</div>
          </div>
          
          <div class="form-group">
            <label for="new-class-teacher-${task.id}">Form Teacher:</label>
            <select id="new-class-teacher-${task.id}">
              <option value="">Select teacher</option>
              ${teacherOptions}
            </select>
            <div class="form-error" id="teacher-error-${task.id}" style="display: none;">Please select a Form Teacher</div>
          </div>
          
          <div class="form-group">
            <label for="new-class-assistant-${task.id}">Assistant Teacher:</label>
            <select id="new-class-assistant-${task.id}">
              <option value="">Select teacher</option>
              ${teacherOptions}
            </select>
            <div class="form-error" id="assistant-error-${task.id}" style="display: none;">Form Teacher and Assistant Teacher cannot be the same</div>
          </div>
        </div>
        
        <div class="form-group">
          <label>No. of Students Selected <strong id="student-count-${task.id}">0</strong>:</label>
          <div class="student-table-container">
            <table class="student-table">
              <thead>
                <tr>
                  <th class="checkbox-column">
                    <input type="checkbox" id="select-all-students-${task.id}" class="select-all-checkbox">
                  </th>
                  <th>Student Name</th>
                </tr>
              </thead>
              <tbody id="student-table-body-${task.id}">
                ${studentRows}
              </tbody>
            </table>
          </div>
        </div>
        
        <div class="form-actions">
          <button type="button" class="form-cancel-btn" id="cancel-create-${task.id}">Cancel</button>
          <button type="button" class="form-submit-btn" id="save-create-${task.id}">Save</button>
        </div>
      </div>
    `;
    
    // Set values if editing
    if (existingClass) {
      const gradeSelect = document.getElementById(`new-class-grade-${task.id}`);
      if (gradeSelect && existingClass.grade) gradeSelect.value = existingClass.grade.toString();
      
      const teacherSelect = document.getElementById(`new-class-teacher-${task.id}`);
      if (teacherSelect && existingClass.teacher) teacherSelect.value = existingClass.teacher;
      
      const assistantSelect = document.getElementById(`new-class-assistant-${task.id}`);
      if (assistantSelect && existingClass.assistant) assistantSelect.value = existingClass.assistant;
      
      if (existingClass.users > 0) {
        const allCheckboxes = Array.from(document.querySelectorAll('.student-checkbox'));
        const shuffled = allCheckboxes.sort(() => 0.5 - Math.random());
        const selected = shuffled.slice(0, existingClass.users);
        selected.forEach(cb => cb.checked = true);
      }
    }
    
    const cancelBtn = document.getElementById(`cancel-create-${task.id}`);
    cancelBtn.addEventListener('click', showClassListView);
    
    const selectAllCheckbox = document.getElementById(`select-all-students-${task.id}`);
    const studentCheckboxes = document.querySelectorAll('.student-checkbox');
    const studentCountDisplay = document.getElementById(`student-count-${task.id}`);
    
    function updateStudentCount() {
      const checkedCount = Array.from(studentCheckboxes).filter(cb => cb.checked).length;
      studentCountDisplay.textContent = checkedCount;
    }
    
    updateStudentCount();
    
    selectAllCheckbox.addEventListener('change', (e) => {
      studentCheckboxes.forEach(checkbox => checkbox.checked = e.target.checked);
      updateStudentCount();
    });
    
    studentCheckboxes.forEach(checkbox => {
      checkbox.addEventListener('change', () => {
        const allChecked = Array.from(studentCheckboxes).every(cb => cb.checked);
        const someChecked = Array.from(studentCheckboxes).some(cb => cb.checked);
        selectAllCheckbox.checked = allChecked;
        selectAllCheckbox.indeterminate = someChecked && !allChecked;
        updateStudentCount();
      });
    });
    
    const saveBtn = document.getElementById(`save-create-${task.id}`);
    saveBtn.addEventListener('click', () => {
      const className = document.getElementById(`new-class-name-${task.id}`).value.trim();
      const classDesc = document.getElementById(`new-class-desc-${task.id}`).value.trim();
      const grade = document.getElementById(`new-class-grade-${task.id}`).value;
      const teacher = document.getElementById(`new-class-teacher-${task.id}`).value;
      const assistant = document.getElementById(`new-class-assistant-${task.id}`).value;
      
      const errorElements = [
        document.getElementById(`class-name-error-${task.id}`),
        document.getElementById(`grade-error-${task.id}`),
        document.getElementById(`teacher-error-${task.id}`),
        document.getElementById(`assistant-error-${task.id}`)
      ];
      errorElements.forEach(el => el.style.display = 'none');
      
      let hasError = false;
      
      if (!className) {
        document.getElementById(`class-name-error-${task.id}`).style.display = 'block';
        hasError = true;
      }
      
      if (!grade) {
        document.getElementById(`grade-error-${task.id}`).style.display = 'block';
        hasError = true;
      }
      
      if (!teacher) {
        document.getElementById(`teacher-error-${task.id}`).style.display = 'block';
        hasError = true;
      }
      
      if (assistant && assistant === teacher) {
        document.getElementById(`assistant-error-${task.id}`).style.display = 'block';
        hasError = true;
      }
      
      if (hasError) return;
      
      const selectedStudents = Array.from(document.querySelectorAll('.student-checkbox:checked'))
        .map(cb => cb.value);
      const userCount = selectedStudents.length;
      
      // Generate random 8-character alphanumeric class code
      function generateClassCode() {
        const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
        let code = '';
        for (let i = 0; i < 8; i++) {
          code += chars.charAt(Math.floor(Math.random() * chars.length));
        }
        return code;
      }
      
      const classObj = {
        name: className,
        description: classDesc,
        users: userCount,
        grade: parseInt(grade),
        teacher: teacher,
        assistant: assistant,
        classCode: generateClassCode(),
        students: selectedStudents
      };
      
      if (isEditMode && existingClass) {
        const classIndex = classData.findIndex(c => 
          c.name === existingClass.name && c.grade === existingClass.grade
        );
        if (classIndex !== -1) {
          // Keep existing class code when editing
          classObj.classCode = existingClass.classCode || generateClassCode();
          classData[classIndex] = classObj;
        }
      } else {
        classData.push(classObj);
      }
      
      filteredData = [...classData];
      showClassListView();
    });
  }
  
  modalBackdrop.classList.add('show');
  modalBackdrop.setAttribute('aria-hidden', 'false');
  
  showClassListView();
}

function showFormSuccess(taskLabel, message = null) {
  const modalBody = document.getElementById('modalBody');
  modalBody.innerHTML = `
    <div class="form-success">
      <svg viewBox="0 0 24 24" fill="none" class="success-icon">
        <circle cx="12" cy="12" r="10" stroke="#16a34a" stroke-width="2" fill="none"/>
        <path d="M9 12l2 2 4-4" stroke="#16a34a" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
      </svg>
      <h3>Form Submitted Successfully!</h3>
      <p>${message || `Thank you for submitting the form for "${taskLabel}".`}</p>
      <button class="form-cancel-btn">Close</button>
    </div>
  `;
  
  const closeBtn = modalBody.querySelector('.form-cancel-btn');
  closeBtn.addEventListener('click', closeModal);
}

function showEmailConfirmationModal(classCode, userCount, className, onCancel) {
  const modalBody = document.getElementById('modalBody');
  modalBody.innerHTML = `
    <div class="form-success">
      <svg viewBox="0 0 24 24" fill="none" class="success-icon" style="stroke: #3b82f6;">
        <circle cx="12" cy="12" r="10" stroke="#3b82f6" stroke-width="2" fill="none"/>
        <path d="M12 8v4M12 16h.01" stroke="#3b82f6" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
      </svg>
      <h3>Confirm Email Sending</h3>
      <p>Are you sure you want to send the Class Code <strong>${classCode}</strong> to <strong>${userCount}</strong> student${userCount > 1 ? 's' : ''} in <strong>${className}</strong>?</p>
      <div style="display: flex; gap: 12px; justify-content: center; margin-top: 20px;">
        <button class="form-cancel-btn" id="cancel-email-btn">Cancel</button>
        <button class="form-save-btn" id="send-email-btn">Send</button>
      </div>
    </div>
  `;
  
  const cancelBtn = modalBody.querySelector('#cancel-email-btn');
  const sendBtn = modalBody.querySelector('#send-email-btn');
  
  cancelBtn.addEventListener('click', () => {
    // Return to class list view
    if (onCancel && typeof onCancel === 'function') {
      onCancel();
    } else {
      closeModal();
    }
  });
  
  sendBtn.addEventListener('click', () => {
    // Record the send timestamp
    recordEmailSend(classCode);
    showEmailSuccessModal(classCode, userCount, onCancel);
  });
}

function checkEmailCooldown(classCode) {
  const lastSent = emailSendTimestamps[classCode];
  if (!lastSent) {
    return { canSend: true };
  }
  
  const now = Date.now();
  const cooldownMs = EMAIL_COOLDOWN_HOURS * 60 * 60 * 1000;
  const timeSinceLastSend = now - lastSent;
  
  if (timeSinceLastSend >= cooldownMs) {
    return { canSend: true };
  }
  
  const nextSendTime = new Date(lastSent + cooldownMs);
  return { 
    canSend: false, 
    nextSendTime: nextSendTime,
    remainingMinutes: Math.ceil((cooldownMs - timeSinceLastSend) / (60 * 1000))
  };
}

function recordEmailSend(classCode) {
  emailSendTimestamps[classCode] = Date.now();
}

function formatTimeUntilNextSend(nextSendTime) {
  const now = new Date();
  const diff = nextSendTime - now;
  const minutes = Math.ceil(diff / (60 * 1000));
  
  if (minutes >= 60) {
    const hours = Math.floor(minutes / 60);
    const remainingMinutes = minutes % 60;
    if (remainingMinutes === 0) {
      return `${hours} hour${hours > 1 ? 's' : ''}`;
    }
    return `${hours} hour${hours > 1 ? 's' : ''} and ${remainingMinutes} minute${remainingMinutes > 1 ? 's' : ''}`;
  }
  return `${minutes} minute${minutes > 1 ? 's' : ''}`;
}

function showEmailRestrictionModal(classCode, className, nextSendTime, onClose) {
  const modalBody = document.getElementById('modalBody');
  const timeUntil = formatTimeUntilNextSend(nextSendTime);
  const formattedTime = nextSendTime.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: true });
  const formattedDate = nextSendTime.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
  
  modalBody.innerHTML = `
    <div class="form-success">
      <svg viewBox="0 0 24 24" fill="none" class="success-icon" style="stroke: #f59e0b;">
        <circle cx="12" cy="12" r="10" stroke="#f59e0b" stroke-width="2" fill="none"/>
        <path d="M12 8v4M12 16h.01" stroke="#f59e0b" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
      </svg>
      <h3>Email Recently Sent</h3>
      <p>The Class Code <strong>${classCode}</strong> for <strong>${className}</strong> was recently sent.</p>
      <p style="margin-top: 16px; color: #6b7280;">To prevent spam, you can send another email in <strong>${timeUntil}</strong>.</p>
      <p style="margin-top: 8px; font-size: 14px; color: #9ca3af;">Next available send time: <strong>${formattedTime} on ${formattedDate}</strong></p>
      <button class="form-cancel-btn" style="margin-top: 20px;">OK</button>
    </div>
  `;
  
  const closeBtn = modalBody.querySelector('.form-cancel-btn');
  closeBtn.addEventListener('click', () => {
    if (onClose && typeof onClose === 'function') {
      onClose();
    } else {
      closeModal();
    }
  });
}

function showEmailSuccessModal(classCode, userCount, onClose) {
  const modalBody = document.getElementById('modalBody');
  modalBody.innerHTML = `
    <div class="form-success">
      <svg viewBox="0 0 24 24" fill="none" class="success-icon">
        <circle cx="12" cy="12" r="10" stroke="#16a34a" stroke-width="2" fill="none"/>
        <path d="M9 12l2 2 4-4" stroke="#16a34a" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
      </svg>
      <h3>Email Sent Successfully!</h3>
      <p>The Class Code <strong>${classCode}</strong> has been sent to <strong>${userCount}</strong> recipient${userCount > 1 ? 's' : ''}' email.</p>
      <button class="form-cancel-btn">Close</button>
    </div>
  `;
  
  const closeBtn = modalBody.querySelector('.form-cancel-btn');
  closeBtn.addEventListener('click', () => {
    // Return to class list view
    if (onClose && typeof onClose === 'function') {
      onClose();
    } else {
      closeModal();
    }
  });
}

function setupMP4Player(task, modalBody) {
  const videoContainer = document.createElement('div');
  videoContainer.className = 'video-container';
  
  const video = document.createElement('video');
  video.src = task.video.src;
  video.playsInline = true;
  video.preload = 'metadata';
  video.title = `Tutorial: ${task.label}`;
  video.className = 'custom-video';
  
  const controls = document.createElement('div');
  controls.className = 'video-controls';
  
  // Play/Pause button
  const playPauseBtn = document.createElement('button');
  playPauseBtn.className = 'control-btn play-pause';
  playPauseBtn.innerHTML = '<svg viewBox="0 0 24 24" fill="none"><path d="M8 5v14l11-7L8 5z" fill="currentColor"/></svg>';
  playPauseBtn.setAttribute('aria-label', 'Play');
  playPauseBtn.setAttribute('title', 'Play');
  
  // Stop button
  const stopBtn = document.createElement('button');
  stopBtn.className = 'control-btn stop';
  stopBtn.innerHTML = '<svg viewBox="0 0 24 24" fill="none"><rect x="6" y="6" width="12" height="12" fill="currentColor" rx="1"/></svg>';
  stopBtn.setAttribute('aria-label', 'Stop');
  stopBtn.setAttribute('title', 'Stop');
  stopBtn.disabled = true;
  
  // Time display
  const timeDisplay = document.createElement('div');
  timeDisplay.className = 'time-display';
  timeDisplay.textContent = '0:00 / 0:00';
  
  // Seekbar
  const seekbar = document.createElement('input');
  seekbar.type = 'range';
  seekbar.className = 'seekbar';
  seekbar.min = '0';
  seekbar.max = '100';
  seekbar.value = '0';
  seekbar.setAttribute('aria-label', 'Seek');
  
  // Volume controls container
  const volumeContainer = document.createElement('div');
  volumeContainer.className = 'volume-container';
  
  // Mute button
  const muteBtn = document.createElement('button');
  muteBtn.className = 'control-btn mute';
  muteBtn.innerHTML = '<svg viewBox="0 0 24 24" fill="none"><path d="M11 5L6 9H2v6h4l5 4V5zm4 1v12M19 7v10" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>';
  muteBtn.setAttribute('aria-label', 'Unmute');
  muteBtn.setAttribute('title', 'Unmute');
  
  // Volume slider
  const volumeSlider = document.createElement('input');
  volumeSlider.type = 'range';
  volumeSlider.className = 'volume-slider hidden';
  volumeSlider.min = '0';
  volumeSlider.max = '100';
  volumeSlider.value = '60';
  volumeSlider.setAttribute('aria-label', 'Volume');
  
  volumeContainer.appendChild(muteBtn);
  volumeContainer.appendChild(volumeSlider);
  
  // Fullscreen button
  const fullscreenBtn = document.createElement('button');
  fullscreenBtn.className = 'control-btn fullscreen';
  fullscreenBtn.innerHTML = '<svg viewBox="0 0 24 24" fill="none"><path d="M8 3H5a2 2 0 0 0-2 2v3m18 0V5a2 2 0 0 0-2-2h-3m0 18h3a2 2 0 0 0 2-2v-3M3 16v3a2 2 0 0 0 2 2h3" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>';
  fullscreenBtn.setAttribute('aria-label', 'Fullscreen');
  fullscreenBtn.setAttribute('title', 'Fullscreen');
  
  controls.appendChild(playPauseBtn);
  controls.appendChild(stopBtn);
  controls.appendChild(timeDisplay);
  controls.appendChild(seekbar);
  controls.appendChild(volumeContainer);
  controls.appendChild(fullscreenBtn);
  
  videoContainer.appendChild(video);
  videoContainer.appendChild(controls);
  modalBody.appendChild(videoContainer);
  
  // Set initial muted state
  video.muted = true;
  video.volume = 0.6;
  
  // Volume slider auto-hide timer
  let volumeHideTimer = null;
  
  function startVolumeHideTimer() {
    if (volumeHideTimer) clearTimeout(volumeHideTimer);
    volumeHideTimer = setTimeout(() => {
      if (!video.muted && video.volume > 0) {
        volumeSlider.classList.add('hidden');
      }
    }, 5000);
  }
  
  // Format time helper
  function formatTime(seconds) {
    if (isNaN(seconds)) return '0:00';
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  }
  
  // Update time display when metadata loads
  video.addEventListener('loadedmetadata', () => {
    const duration = formatTime(video.duration);
    timeDisplay.textContent = `0:00 / ${duration}`;
  });
  
  // Event handlers
  playPauseBtn.addEventListener('click', () => {
    if (video.paused) {
      video.play();
      playPauseBtn.innerHTML = '<svg viewBox="0 0 24 24" fill="none"><path d="M6 4h4v16H6V4zm8 0h4v16h-4V4z" fill="currentColor"/></svg>';
      playPauseBtn.setAttribute('aria-label', 'Pause');
      playPauseBtn.setAttribute('title', 'Pause');
      stopBtn.disabled = false;
    } else {
      video.pause();
      playPauseBtn.innerHTML = '<svg viewBox="0 0 24 24" fill="none"><path d="M8 5v14l11-7L8 5z" fill="currentColor"/></svg>';
      playPauseBtn.setAttribute('aria-label', 'Play');
      playPauseBtn.setAttribute('title', 'Play');
    }
  });
  
  stopBtn.addEventListener('click', () => {
    video.pause();
    video.currentTime = 0;
    playPauseBtn.innerHTML = '<svg viewBox="0 0 24 24" fill="none"><path d="M8 5v14l11-7L8 5z" fill="currentColor"/></svg>';
    playPauseBtn.setAttribute('aria-label', 'Play');
    playPauseBtn.setAttribute('title', 'Play');
    stopBtn.disabled = true;
  });
  
  muteBtn.addEventListener('click', () => {
    if (video.muted || video.volume === 0) {
      video.muted = false;
      video.volume = 0.6;
      volumeSlider.value = 60;
      muteBtn.innerHTML = '<svg viewBox="0 0 24 24" fill="none"><path d="M11 5L6 9H2v6h4l5 4V5zm4 1v12M19 7v10" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>';
      muteBtn.setAttribute('aria-label', 'Mute');
      muteBtn.setAttribute('title', 'Mute');
      volumeSlider.classList.remove('hidden');
      startVolumeHideTimer();
    } else {
      video.muted = true;
      muteBtn.innerHTML = '<svg viewBox="0 0 24 24" fill="none"><path d="M11 5L6 9H2v6h4l5 4V5zm4 1v12M19 7v10" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>';
      muteBtn.setAttribute('aria-label', 'Unmute');
      muteBtn.setAttribute('title', 'Unmute');
      volumeSlider.classList.add('hidden');
      if (volumeHideTimer) clearTimeout(volumeHideTimer);
    }
  });
  
  volumeSlider.addEventListener('input', () => {
    const volume = volumeSlider.value / 100;
    video.volume = volume;
    
    if (volume === 0) {
      video.muted = true;
      muteBtn.innerHTML = '<svg viewBox="0 0 24 24" fill="none"><path d="M11 5L6 9H2v6h4l5 4V5zm4 1v12M19 7v10" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>';
      muteBtn.setAttribute('aria-label', 'Mute');
      muteBtn.setAttribute('title', 'Mute');
      if (volumeHideTimer) clearTimeout(volumeHideTimer);
    } else {
      video.muted = false;
      muteBtn.innerHTML = '<svg viewBox="0 0 24 24" fill="none"><path d="M11 5L6 9H2v6h4l5 4V5zm4 1v12M19 7v10" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>';
      muteBtn.setAttribute('aria-label', 'Mute');
      muteBtn.setAttribute('title', 'Mute');
      startVolumeHideTimer();
    }
  });
  
  fullscreenBtn.addEventListener('click', () => {
    if (!document.fullscreenElement) {
      if (videoContainer.requestFullscreen) {
        videoContainer.requestFullscreen();
      } else if (videoContainer.webkitRequestFullscreen) {
        videoContainer.webkitRequestFullscreen();
      } else if (videoContainer.msRequestFullscreen) {
        videoContainer.msRequestFullscreen();
      }
      fullscreenBtn.innerHTML = 'â›¶';
    } else {
      if (document.exitFullscreen) {
        document.exitFullscreen();
      } else if (document.webkitExitFullscreen) {
        document.webkitExitFullscreen();
      } else if (document.msExitFullscreen) {
        document.msExitFullscreen();
      }
      fullscreenBtn.innerHTML = 'â›¶';
    }
  });
  
  video.addEventListener('timeupdate', () => {
    const current = formatTime(video.currentTime);
    const duration = formatTime(video.duration);
    timeDisplay.textContent = `${current} / ${duration}`;
    
    if (video.duration) {
      seekbar.value = (video.currentTime / video.duration) * 100;
    }
  });
  
  seekbar.addEventListener('input', () => {
    const time = (seekbar.value / 100) * video.duration;
    video.currentTime = time;
  });
  
  video.addEventListener('ended', () => {
    playPauseBtn.innerHTML = '<svg viewBox="0 0 24 24" fill="none"><path d="M8 5v14l11-7L8 5z" fill="currentColor"/></svg>';
    playPauseBtn.setAttribute('aria-label', 'Play');
    playPauseBtn.setAttribute('title', 'Play');
    stopBtn.disabled = true;
  });
}

// ============================================
// NOTIFICATION PANEL
// ============================================
function getTimeAgo(dateString) {
  const now = new Date();
  const notificationDate = new Date(dateString);
  const diffInSeconds = Math.floor((now - notificationDate) / 1000);
  
  const intervals = {
    year: 31536000,
    month: 2592000,
    week: 604800,
    day: 86400,
    hour: 3600,
    minute: 60
  };
  
  for (const [unit, seconds] of Object.entries(intervals)) {
    const interval = Math.floor(diffInSeconds / seconds);
    if (interval >= 1) {
      return interval === 1 ? `1 ${unit} ago` : `${interval} ${unit}s ago`;
    }
  }
  
  return 'Just now';
}

function formatDate(dateString) {
  const date = new Date(dateString);
  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  const day = date.getDate();
  const month = months[date.getMonth()];
  const year = date.getFullYear();
  return `${day} ${month} ${year}`;
}

let notificationsData = [
  {
    id: 3,
    title: 'Student08 has joined your class 1D',
    message: 'Student08 is now in your class 1D. You can start assigning them to tasks and activities.',
    timestamp: new Date(Date.now() - 2 * 60 * 1000), // 2 minutes ago (most recent)
    read: false,
    from: 'MCEduHub System',
  },
  {
    id: 2,
    title: 'Student01 has joined your class 1A',
    message: 'Student01 is now in your class 1A. You can start assigning them to tasks and activities.',
    timestamp: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000), // 2 days ago
    read: false,
    from: 'MCEduHub System'
  },
  {
    id: 1,
    title: 'Welcome to MCEduHub',
    message: 'Thank you for joining MCEduHub! We\'re excited to have you here. Explore our platform to discover interactive lessons, engaging assignments, and collaborative tools designed to enhance your learning experience. If you need any help getting started, feel free to reach out to our support team.',
    timestamp: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000), // 5 days ago (oldest)
    read: false,
    from: 'MCEduHub System'
  }
];

function initNotificationPanel() {
  const notificationBtn = document.getElementById('notificationBtn');
  const notificationPanel = document.getElementById('notificationPanel');
  const notificationClose = document.getElementById('notificationClose');
  const notificationList = document.getElementById('notificationList');
  const markAllReadBtn = document.getElementById('markAllReadBtn');
  const manageNotificationsBtn = document.getElementById('manageNotificationsBtn');
  
  if (!notificationBtn || !notificationPanel) return;
  
  // Render notifications
  function renderNotifications() {
    if (notificationsData.length === 0) {
      notificationList.innerHTML = '<div class="no-notifications-message">No notifications</div>';
    } else {
      notificationList.innerHTML = notificationsData.map(notif => `
        <div class="notification-item ${notif.read ? 'read' : 'unread'}" data-id="${notif.id}">
          <div class="notification-icon">
            <svg viewBox="0 0 24 24" fill="none">
              <circle cx="12" cy="12" r="10" stroke="currentColor" stroke-width="2"/>
              <path d="M12 8v4M12 16h.01" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
            </svg>
          </div>
          <div class="notification-content">
            <div class="notification-title">${notif.title}</div>
            <div class="notification-message">${notif.message}</div>
            <div class="notification-time">${getTimeAgo(notif.timestamp)}</div>
          </div>
          ${!notif.read ? '<div class="unread-indicator"></div>' : ''}
        </div>
      `).join('');
      
      // Add click handlers
      document.querySelectorAll('.notification-item').forEach(item => {
        item.addEventListener('click', () => {
          const notifId = parseInt(item.dataset.id);
          openNotificationDetail(notifId);
        });
      });
    }
    
    updateNotificationBadge();
  }
  
  function updateNotificationBadge() {
    const badge = document.querySelector('.notification-badge');
    const unreadCount = notificationsData.filter(n => !n.read).length;
    if (badge) {
      badge.textContent = unreadCount;
      badge.style.display = unreadCount > 0 ? 'block' : 'none';
    }
  }
  
  function openNotificationDetail(notifId) {
    closeAllModals(['notificationDetailModal', 'notificationPanel']);
    
    const notif = notificationsData.find(n => n.id === notifId);
    if (!notif) return;
    
    // Mark as read
    notif.read = true;
    renderNotifications();
    
    const modal = document.getElementById('notificationDetailModal');
    const titleEl = document.getElementById('notificationModalTitle');
    const postedEl = document.getElementById('notificationModalPosted');
    const messageEl = document.getElementById('notificationModalMessage');
    const approvalEl = document.getElementById('notificationModalApproval');
    
    titleEl.textContent = notif.title;
    postedEl.innerHTML = `Posted on ${formatDate(notif.timestamp)} from <strong>${notif.from}</strong>`;
    messageEl.innerHTML = notif.message;
    
    if (notif.requiresApproval) {
      approvalEl.style.display = 'block';
      
      const approveBtn = document.getElementById('approveBtn');
      const rejectBtn = document.getElementById('rejectBtn');
      
      approveBtn.onclick = () => handleTeacherApproval(notifId, true);
      rejectBtn.onclick = () => handleTeacherApproval(notifId, false);
    } else {
      approvalEl.style.display = 'none';
    }
    
    modal.classList.add('active');
  }
  
  function handleTeacherApproval(notifId, approved) {
    const action = approved ? 'approve' : 'reject';
    const actionPast = approved ? 'approved' : 'rejected';
    const confirmTitle = approved ? 'Approve Teacher Request' : 'Reject Teacher Request';
    const confirmMessage = approved 
      ? 'Are you sure you want to approve Teacher1119\'s request to join your school?'
      : 'Are you sure you want to reject Teacher1119\'s request? This action cannot be undone.';
    
    showConfirmationModal(
      confirmTitle,
      confirmMessage,
      approved ? 'approve' : 'reject',
      approved ? 'Approve' : 'Reject',
      () => {
        // On confirm
        showSuccessModal(
          approved ? 'Teacher Approved' : 'Teacher Rejected',
          `Teacher request has been ${actionPast}.`
        );
        
        // Remove notification
        notificationsData = notificationsData.filter(n => n.id !== notifId);
        renderNotifications();
        closeNotificationDetailModal();
      }
    );
  }
  
  function closeNotificationDetailModal() {
    const modal = document.getElementById('notificationDetailModal');
    modal.classList.remove('active');
  }
  
  function showConfirmationModal(title, message, actionType, actionButtonText, onConfirm) {
    // Keep notification detail modal open (parent-child relationship)
    closeAllModals(['confirmationModal', 'notificationDetailModal']);
    
    const modal = document.getElementById('confirmationModal');
    const titleEl = document.getElementById('confirmationModalTitle');
    const messageEl = document.getElementById('confirmationModalMessage');
    const actionBtn = document.getElementById('confirmationActionBtn');
    const cancelBtn = document.getElementById('confirmationCancelBtn');
    
    titleEl.textContent = title;
    messageEl.textContent = message;
    actionBtn.textContent = actionButtonText;
    
    // Remove previous action type classes
    actionBtn.classList.remove('approve', 'reject');
    // Add new action type class
    if (actionType) {
      actionBtn.classList.add(actionType);
    }
    
    // Remove previous event listeners by cloning the button
    const newActionBtn = actionBtn.cloneNode(true);
    actionBtn.parentNode.replaceChild(newActionBtn, actionBtn);
    
    const newCancelBtn = cancelBtn.cloneNode(true);
    cancelBtn.parentNode.replaceChild(newCancelBtn, cancelBtn);
    
    // Add new event listeners
    newActionBtn.addEventListener('click', () => {
      if (onConfirm) onConfirm();
      closeConfirmationModal();
    });
    
    newCancelBtn.addEventListener('click', () => {
      closeConfirmationModal();
    });
    
    modal.classList.add('active');
  }
  
  function closeConfirmationModal() {
    const modal = document.getElementById('confirmationModal');
    modal.classList.remove('active');
  }
  
  function showSuccessModal(title, message) {
    // Reuse the confirmation modal for success messages
    const modal = document.getElementById('confirmationModal');
    const titleEl = document.getElementById('confirmationModalTitle');
    const messageEl = document.getElementById('confirmationModalMessage');
    const actionBtn = document.getElementById('confirmationActionBtn');
    const cancelBtn = document.getElementById('confirmationCancelBtn');
    
    titleEl.textContent = title;
    messageEl.textContent = message;
    actionBtn.textContent = 'OK';
    
    // Remove action type classes for success modal
    actionBtn.classList.remove('approve', 'reject');
    
    // Hide cancel button for success messages
    cancelBtn.style.display = 'none';
    
    // Remove previous event listeners
    const newActionBtn = actionBtn.cloneNode(true);
    actionBtn.parentNode.replaceChild(newActionBtn, actionBtn);
    
    newActionBtn.addEventListener('click', () => {
      closeConfirmationModal();
      // Show cancel button again for next time
      document.getElementById('confirmationCancelBtn').style.display = 'block';
    });
    
    modal.classList.add('active');
  }
  
  function openManageNotificationsModal() {
    closeAllModals(['manageNotificationsModal', 'notificationPanel']);
    
    const modal = document.getElementById('manageNotificationsModal');
    const manageList = document.getElementById('manageNotificationList');
    const countDisplay = document.getElementById('manageNotificationCount');
    const selectAllContainer = document.querySelector('.manage-select-all');
    const actionsContainer = document.getElementById('manageModalActions');
    
    // Update notification count
    const count = notificationsData.length;
    countDisplay.textContent = `${count} notification(s) found`;
    
    // Hide Select All checkbox, count display, and actions when no notifications
    if (selectAllContainer) {
      selectAllContainer.style.display = count > 0 ? 'flex' : 'none';
    }
    if (countDisplay) {
      countDisplay.style.display = count > 0 ? 'block' : 'none';
    }
    if (actionsContainer) {
      actionsContainer.style.display = count > 0 ? 'flex' : 'none';
    }
    
    if (count === 0) {
      manageList.innerHTML = '<div class="no-notifications-message">No notifications</div>';
    } else {
      manageList.innerHTML = notificationsData.map(notif => `
        <div class="manage-notification-item" data-id="${notif.id}">
          <label class="manage-notification-label">
            <input type="checkbox" class="notification-checkbox" data-id="${notif.id}" />
            <div class="manage-notification-info">
              <div class="manage-notification-title">${notif.title}</div>
              <div class="manage-notification-meta">${formatDate(notif.timestamp)} • ${notif.read ? 'Read' : 'Unread'}</div>
            </div>
          </label>
        </div>
      `).join('');
      
      setupManageModalHandlers();
    }
    
    modal.classList.add('active');
  }
  
  function setupManageModalHandlers() {
    const selectAllCheckbox = document.getElementById('selectAllCheckbox');
    const deleteBtn = document.getElementById('deleteSelectedBtn');
    const markUnreadBtn = document.getElementById('markUnreadBtn');
    const actionsContainer = document.getElementById('manageModalActions');
    const checkboxes = document.querySelectorAll('.notification-checkbox');
    const manageItems = document.querySelectorAll('.manage-notification-item');
    
    selectAllCheckbox.checked = false;
    
    function updateActionButtons() {
      const checkedBoxes = document.querySelectorAll('.notification-checkbox:checked');
      const hasSelection = checkedBoxes.length > 0;
      
      // Hide/show entire actions container based on selection
      if (hasSelection) {
        actionsContainer.style.display = 'flex';
        deleteBtn.style.display = 'block';
        markUnreadBtn.style.display = 'block';
        
        // Check if all selected items are read or unread
        const selectedIds = Array.from(checkedBoxes).map(cb => parseInt(cb.dataset.id));
        const selectedNotifs = notificationsData.filter(n => selectedIds.includes(n.id));
        const allRead = selectedNotifs.every(n => n.read);
        
        // Change button text based on read status
        if (allRead) {
          markUnreadBtn.textContent = 'Mark as Unread';
        } else {
          markUnreadBtn.textContent = 'Mark as Read';
        }
      } else {
        actionsContainer.style.display = 'none';
        deleteBtn.style.display = 'none';
        markUnreadBtn.style.display = 'none';
      }
    }
    
    selectAllCheckbox.addEventListener('change', (e) => {
      checkboxes.forEach(cb => cb.checked = e.target.checked);
      updateActionButtons();
    });
    
    checkboxes.forEach(cb => {
      cb.addEventListener('change', (e) => {
        e.stopPropagation();
        updateActionButtons();
        selectAllCheckbox.checked = Array.from(checkboxes).every(c => c.checked);
      });
    });
    
    // Make notification info area clickable - DON'T close manage modal
    manageItems.forEach(item => {
      const infoArea = item.querySelector('.manage-notification-info');
      if (infoArea) {
        infoArea.style.cursor = 'pointer';
        infoArea.addEventListener('click', (e) => {
          e.stopPropagation();
          const notifId = parseInt(item.dataset.id);
          // Don't close manage modal, just open detail on top
          openNotificationDetail(notifId);
        });
      }
    });
    
    deleteBtn.addEventListener('click', () => {
      const checkedIds = Array.from(document.querySelectorAll('.notification-checkbox:checked'))
        .map(cb => parseInt(cb.dataset.id));
      
      if (checkedIds.length > 0 && confirm(`Delete ${checkedIds.length} notification(s)?`)) {
        notificationsData = notificationsData.filter(n => !checkedIds.includes(n.id));
        renderNotifications();
        openManageNotificationsModal(); // Refresh the modal
      }
    });
    
    markUnreadBtn.addEventListener('click', () => {
      const checkedIds = Array.from(document.querySelectorAll('.notification-checkbox:checked'))
        .map(cb => parseInt(cb.dataset.id));
      
      const selectedNotifs = notificationsData.filter(n => checkedIds.includes(n.id));
      const allRead = selectedNotifs.every(n => n.read);
      
      // Toggle read status based on current state
      checkedIds.forEach(id => {
        const notif = notificationsData.find(n => n.id === id);
        if (notif) {
          if (allRead) {
            notif.read = false; // Mark as unread
          } else {
            notif.read = true; // Mark as read
          }
        }
      });
      
      renderNotifications();
      openManageNotificationsModal(); // Refresh the modal
    });
    
    // Initialize button visibility
    updateActionButtons();
  }
  
  function closeManageModal() {
    const modal = document.getElementById('manageNotificationsModal');
    modal.classList.remove('active');
  }
  
  renderNotifications();
  
  // Toggle notification panel
  function toggleNotificationPanel(show) {
    const isOpen = show !== undefined ? show : !notificationPanel.classList.contains('open');
    
    if (isOpen) {
      closeAllModals(['notificationPanel']);
      notificationPanel.classList.add('open');
      notificationBtn.setAttribute('aria-expanded', 'true');
    } else {
      notificationPanel.classList.remove('open');
      notificationBtn.setAttribute('aria-expanded', 'false');
    }
  }
  
  // Event listeners
  notificationBtn.addEventListener('click', (e) => {
    e.stopPropagation();
    toggleNotificationPanel();
  });
  
  if (notificationClose) {
    notificationClose.addEventListener('click', () => {
      toggleNotificationPanel(false);
    });
  }
  
  if (markAllReadBtn) {
    markAllReadBtn.addEventListener('click', () => {
      notificationsData.forEach(n => n.read = true);
      renderNotifications();
    });
  }
  
  if (manageNotificationsBtn) {
    manageNotificationsBtn.addEventListener('click', openManageNotificationsModal);
  }
  
  // Close when clicking outside
  document.addEventListener('click', (e) => {
    if (!notificationPanel.contains(e.target) && !notificationBtn.contains(e.target)) {
      toggleNotificationPanel(false);
    }
  });
  
  // Prevent panel clicks from closing it
  notificationPanel.addEventListener('click', (e) => {
    e.stopPropagation();
  });
  
  // Modal close handlers
  const closeDetailModalBtn = document.getElementById('closeNotificationModal');
  const closeManageModalBtn = document.getElementById('closeManageModal');
  
  if (closeDetailModalBtn) {
    closeDetailModalBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      closeNotificationDetailModal();
    });
  }
  
  if (closeManageModalBtn) {
    closeManageModalBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      closeManageModal();
    });
  }
  
  // Close modals when clicking overlay
  document.getElementById('notificationDetailModal')?.addEventListener('click', (e) => {
    if (e.target.id === 'notificationDetailModal') {
      closeNotificationDetailModal();
    }
  });
  
  document.getElementById('confirmationModal')?.addEventListener('click', (e) => {
    if (e.target.id === 'confirmationModal') {
      closeConfirmationModal();
      // Show cancel button again in case it was hidden
      const cancelBtn = document.getElementById('confirmationCancelBtn');
      if (cancelBtn) cancelBtn.style.display = 'block';
    }
  });
  
  document.getElementById('manageNotificationsModal')?.addEventListener('click', (e) => {
    if (e.target.id === 'manageNotificationsModal') {
      closeManageModal();
    }
  });
}


// ============================================
// USER DROPDOWN MENU
// ============================================
function initUserDropdown() {
  const userInfo = document.getElementById('userInfo');
  const userDropdownMenu = document.getElementById('userDropdownMenu');
  
  if (!userInfo || !userDropdownMenu) return;
  
  // Toggle dropdown menu
  userInfo.addEventListener('click', (e) => {
    // Don't open dropdown if clicking on the role badge
    if (e.target.id === 'userRoleBadge' || e.target.closest('#userRoleBadge')) {
      return;
    }
    
    e.stopPropagation();
    const isOpen = !userInfo.classList.contains('active');
    
    if (isOpen) {
      closeAllModals(['userDropdownMenu']);
    }
    
    userInfo.classList.toggle('active');
    userDropdownMenu.classList.toggle('active');
  });
  
  // Close dropdown when clicking outside
  document.addEventListener('click', (e) => {
    // Don't close if welcome tour is showing the dropdown step
    if (window.WelcomeTour && window.WelcomeTour.isOnDropdownStep && window.WelcomeTour.isOnDropdownStep()) {
      return;
    }
    
    if (!userInfo.contains(e.target) && !userDropdownMenu.contains(e.target)) {
      userInfo.classList.remove('active');
      userDropdownMenu.classList.remove('active');
    }
  });
  
  // Handle dropdown item clicks
  const dropdownItems = userDropdownMenu.querySelectorAll('.user-dropdown-item');
  dropdownItems.forEach(item => {
    item.addEventListener('click', (e) => {
      e.preventDefault();
      const action = item.getAttribute('data-action');
      
      // Close dropdown
      userInfo.classList.remove('active');
      userDropdownMenu.classList.remove('active');
      
      // Handle specific actions
      if (action === 'getting-started') {
        showGettingStartedWidget();
      } else if (action === 'logout') {
        // Redirect to login page
        window.location.href = 'login.html';
      } else if (action === 'manage-class') {
        // Navigate to Class page based on role (same as nav link behavior)
        const userInfoElem = document.getElementById('userInfo');
        const viewMode = userInfoElem ? userInfoElem.getAttribute('data-view-mode') : 'teacher';
        
        // Get nav elements
        const navLinks = document.querySelectorAll('.nav-link');
        const contentPages = document.querySelectorAll('.content-page');
        
        // Update active nav link to Class
        navLinks.forEach(l => l.classList.remove('active'));
        const classNavLink = document.querySelector('.nav-link[data-action="manage-class"]');
        if (classNavLink) {
          classNavLink.classList.add('active');
        }
        
        // Hide all content pages
        contentPages.forEach(page => page.classList.remove('active'));
        
        if (viewMode === 'student') {
          // Student view - show Join School/Class full page
          const joinClassPage = document.getElementById('join-class');
          if (joinClassPage) {
            joinClassPage.classList.add('active');
            initializeJoinClassPage();
          }
        } else {
          // Teacher view - show Class management page
          const manageClassPage = document.getElementById('manage-class');
          if (manageClassPage) {
            manageClassPage.classList.add('active');
            initializeManageClassPage();
          }
        }
      } else {
        // Dummy actions - show alert
        const actionName = item.querySelector('span').textContent;
        alert(`${actionName} feature coming soon!`);
      }
    });
  });
}

function showGettingStartedWidget() {
  const panel = document.getElementById('onboardPanel');
  const toggleBtn = document.getElementById('onboardToggle');
  
  if (!panel) return;
  
  // Open the Getting Started panel
  panel.classList.add('open');
  if (toggleBtn) {
    toggleBtn.setAttribute('aria-expanded', 'true');
  }
  
  console.log('Getting Started widget opened');
}

// ============================================
// JOIN A CLASS MODAL (REMOVED - No longer needed)
// ============================================
// Modal removed as per requirements - student books now open ebook.html directly

function openJoinClassSuccessModal() {
  const modal = document.getElementById('joinClassSuccessModal');
  if (modal) {
    modal.classList.add('active');
    document.body.style.overflow = 'hidden';
  }
}

function closeJoinClassSuccessModal() {
  const modal = document.getElementById('joinClassSuccessModal');
  if (modal) {
    modal.classList.remove('active');
    document.body.style.overflow = '';
  }
}

// ============================================
// JOIN CLASS AI MODAL (REMOVED - No longer needed)
// ============================================
// Modal removed as per requirements - student books now open ebook.html directly

function initJoinClassSuccessModal() {
  const modal = document.getElementById('joinClassSuccessModal');
  const closeBtn = document.getElementById('closeJoinClassSuccessModal');
  const okBtn = document.getElementById('joinClassOkBtn');
  
  if (closeBtn) {
    closeBtn.addEventListener('click', closeJoinClassSuccessModal);
  }
  
  if (okBtn) {
    okBtn.addEventListener('click', closeJoinClassSuccessModal);
  }
  
  modal.addEventListener('click', (e) => {
    if (e.target === modal) {
      closeJoinClassSuccessModal();
    }
  });
}

// ============================================
// HELP SUPPORT MODAL
// ============================================
function initHelpSupportModal() {
  const helpSupportModal = document.getElementById('helpSupportModal');
  const closeHelpSupportModal = document.getElementById('closeHelpSupportModal');
  const expandHelpModal = document.getElementById('expandHelpModal');
  const feedbackFormModal = document.getElementById('feedbackFormModal');
  const closeFeedbackModal = document.getElementById('closeFeedbackModal');
  const reportIssueBtn = document.getElementById('reportIssueBtn');
  const feedbackCancelBtn = document.getElementById('feedbackCancelBtn');
  const feedbackForm = document.getElementById('feedbackForm');
  const faqItems = document.querySelectorAll('.faq-item');
  
  if (!helpSupportModal) return;
  
  // Expand/Collapse functionality
  if (expandHelpModal) {
    expandHelpModal.addEventListener('click', () => {
      const modal = document.querySelector('.help-support-modal');
      const supportFrame = document.getElementById('supportPageFrame');
      const isExpanded = modal.classList.contains('expanded');
      
      if (isExpanded) {
        // Collapse to normal size
        modal.classList.remove('expanded');
        expandHelpModal.classList.remove('collapse-mode');
        expandHelpModal.setAttribute('title', 'Expand');
        expandHelpModal.innerHTML = `
          <svg viewBox="0 0 24 24" fill="none">
            <path d="M15 3h6v6M9 21H3v-6M21 3l-7 7M3 21l7-7" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
        `;
      } else {
        // Expand to 90% screen
        modal.classList.add('expanded');
        expandHelpModal.classList.add('collapse-mode');
        expandHelpModal.setAttribute('title', 'Collapse');
        expandHelpModal.innerHTML = `
          <svg viewBox="0 0 24 24" fill="none">
            <path d="M9 3H3v6M21 9V3h-6M9 21H3v-6M21 15v6h-6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
        `;
        
        // Load support page in iframe if not already loaded
        if (supportFrame && (!supportFrame.src || supportFrame.src === '' || supportFrame.src === window.location.href)) {
          supportFrame.src = 'support.html';
        }
      }
    });
  }
  
  // FAQ accordion functionality
  faqItems.forEach(item => {
    const question = item.querySelector('.faq-question');
    question.addEventListener('click', () => {
      const isActive = item.classList.contains('active');
      
      // Close all other FAQs
      faqItems.forEach(otherItem => {
        if (otherItem !== item) {
          otherItem.classList.remove('active');
        }
      });
      
      // Toggle current FAQ
      item.classList.toggle('active');
    });
  });
  
  // Search functionality (basic)
  const supportSearchInput = document.getElementById('supportSearchInput');
  const supportSearchBtn = document.querySelector('.support-search-btn');
  
  if (supportSearchBtn && supportSearchInput) {
    supportSearchBtn.addEventListener('click', () => {
      const searchTerm = supportSearchInput.value.trim();
      if (searchTerm) {
        alert(`Search functionality for "${searchTerm}" coming soon!`);
      }
    });
    
    supportSearchInput.addEventListener('keypress', (e) => {
      if (e.key === 'Enter') {
        const searchTerm = supportSearchInput.value.trim();
        if (searchTerm) {
          alert(`Search functionality for "${searchTerm}" coming soon!`);
        }
      }
    });
  }
  
  // Close help support modal
  if (closeHelpSupportModal) {
    closeHelpSupportModal.addEventListener('click', closeHelpSupportModalFunc);
  }
  
  // Close modal when clicking overlay
  helpSupportModal.addEventListener('click', (e) => {
    if (e.target.id === 'helpSupportModal') {
      closeHelpSupportModalFunc();
    }
  });
  
  // Report issue button
  if (reportIssueBtn) {
    reportIssueBtn.addEventListener('click', () => {
      openFeedbackFormModal();
    });
  }
  
  // Contact support button on Support page
  const contactSupportBtn = document.getElementById('contactSupportBtn');
  if (contactSupportBtn) {
    contactSupportBtn.addEventListener('click', () => {
      openFeedbackFormModal();
    });
  }
  
  // Close feedback modal
  if (closeFeedbackModal) {
    closeFeedbackModal.addEventListener('click', closeFeedbackFormModalFunc);
  }
  
  if (feedbackCancelBtn) {
    feedbackCancelBtn.addEventListener('click', closeFeedbackFormModalFunc);
  }
  
  // Close feedback modal when clicking overlay
  if (feedbackFormModal) {
    feedbackFormModal.addEventListener('click', (e) => {
      if (e.target.id === 'feedbackFormModal') {
        closeFeedbackFormModalFunc();
      }
    });
  }
  
  // Handle feedback form submission
  if (feedbackForm) {
    feedbackForm.addEventListener('submit', (e) => {
      e.preventDefault();
      
      const subject = document.getElementById('feedbackSubject').value;
      const category = document.getElementById('feedbackCategory').value;
      const message = document.getElementById('feedbackMessage').value;
      
      // Show success message
      showSuccessModal(
        'Issue Reported',
        'Thank you for your feedback! We have received your issue report and will review it shortly. Our support team will investigate and get back to you soon.'
      );
      
      // Reset form
      feedbackForm.reset();
      closeFeedbackFormModalFunc();
      
      console.log('Issue reported:', { issueType, issueSubject, issueDescription, userEmail });
    });
  }
}

// ============================================
// GLOBAL MODAL MANAGEMENT
// ============================================
function closeAllModals(except = []) {
  const modals = [
    { id: 'notificationDetailModal', type: 'modal' },
    { id: 'manageNotificationsModal', type: 'modal' },
    { id: 'confirmationModal', type: 'modal' },
    { id: 'downloadAppModal', type: 'modal' },
    { id: 'enhancedEbookModal', type: 'modal' },
    { id: 'autoMarkingModal', type: 'modal' },
    { id: 'teacherResourcesModal', type: 'modal' },
    { id: 'helpSupportModal', type: 'modal' },
    { id: 'feedbackFormModal', type: 'modal' },
    { id: 'modalBackdrop', type: 'backdrop' },
    { id: 'notificationPanel', type: 'panel' },
    { id: 'onboardPanel', type: 'onboard' },
    { id: 'userDropdownMenu', type: 'dropdown' }
  ];
  
  modals.forEach(({id, type}) => {
    if (except.includes(id)) return;
    
    const element = document.getElementById(id);
    if (!element) return;
    
    if (type === 'modal' || type === 'dialog') {
      element.classList.remove('active');
    } else if (type === 'backdrop') {
      element.classList.remove('show');
      element.setAttribute('aria-hidden', 'true');
      const modalBody = document.getElementById('modalBody');
      if (modalBody) modalBody.innerHTML = '';
    } else if (type === 'panel') {
      element.classList.remove('open');
      const notificationBtn = document.getElementById('notificationBtn');
      if (notificationBtn) notificationBtn.setAttribute('aria-expanded', 'false');
    } else if (type === 'onboard') {
      // Don't close onboard panel - it stays open independently
      return;
    } else if (type === 'dropdown') {
      element.classList.remove('active');
      const userInfo = document.getElementById('userInfo');
      if (userInfo) userInfo.classList.remove('active');
    }
  });
  
  // Reset body overflow
  if (!except.includes('downloadAppModal') && !except.includes('modalBackdrop')) {
    document.body.style.overflow = '';
  }
}

function openHelpSupportModal() {
  closeAllModals(['helpSupportModal']);
  
  const helpSupportModal = document.getElementById('helpSupportModal');
  if (helpSupportModal) {
    helpSupportModal.classList.add('active');
    
    // Close all open FAQs
    const faqItems = document.querySelectorAll('.faq-item');
    faqItems.forEach(item => item.classList.remove('active'));
    
    // Clear search input
    const supportSearchInput = document.getElementById('supportSearchInput');
    if (supportSearchInput) {
      supportSearchInput.value = '';
    }
  }
}

function closeHelpSupportModalFunc() {
  const helpSupportModal = document.getElementById('helpSupportModal');
  const modal = document.querySelector('.help-support-modal');
  const expandHelpModal = document.getElementById('expandHelpModal');
  
  if (helpSupportModal) {
    helpSupportModal.classList.remove('active');
  }
  
  // Reset to normal state
  if (modal) {
    modal.classList.remove('expanded');
  }
  
  if (expandHelpModal) {
    expandHelpModal.classList.remove('collapse-mode');
    expandHelpModal.setAttribute('title', 'Expand');
    expandHelpModal.innerHTML = `
      <svg viewBox="0 0 24 24" fill="none">
        <path d="M15 3h6v6M9 21H3v-6M21 3l-7 7M3 21l7-7" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
      </svg>
    `;
  }
}

function openFeedbackFormModal() {
  // Keep Help Support Modal open (parent-child relationship)
  closeAllModals(['feedbackFormModal', 'helpSupportModal']);
  
  const feedbackFormModal = document.getElementById('feedbackFormModal');
  if (feedbackFormModal) {
    feedbackFormModal.classList.add('active');
  }
}

function closeFeedbackFormModalFunc() {
  const feedbackFormModal = document.getElementById('feedbackFormModal');
  if (feedbackFormModal) {
    feedbackFormModal.classList.remove('active');
  }
}

// ============================================
// DYNAMIC FONT SIZE ADJUSTMENT FOR GRID MODE
// ============================================
function adjustThumbnailTitleFontSize() {
  // Only adjust titles when NOT in list mode
  const grids = document.querySelectorAll('.thumbnails-grid:not(.list-mode)');
  
  grids.forEach(grid => {
    const thumbnails = grid.querySelectorAll('.thumbnail-card');
    
    thumbnails.forEach(thumbnail => {
      // Skip if thumbnail is hidden
      if (thumbnail.style.display === 'none') return;
      
      const titleElement = thumbnail.querySelector('.thumbnail-info h3');
      if (!titleElement) return;
      
      // Reset any previous inline font-size to get the base size from CSS
      titleElement.style.fontSize = '';
      
      // Get the computed style
      const computedStyle = window.getComputedStyle(titleElement);
      const lineHeight = parseFloat(computedStyle.lineHeight);
      const maxHeight = lineHeight * 3; // 3 lines
      
      // Get initial font size from clamp() result
      let fontSize = parseFloat(computedStyle.fontSize);
      const minFontSize = 9; // Minimum readable size
      const maxFontSize = fontSize; // Don't go larger than clamp result
      
      // Check if content overflows
      if (titleElement.scrollHeight > maxHeight + 1) { // +1 for rounding
        // Binary search for optimal font size
        let low = minFontSize;
        let high = maxFontSize;
        let optimalSize = minFontSize;
        
        while (low <= high) {
          const mid = (low + high) / 2;
          titleElement.style.fontSize = mid + 'px';
          
          if (titleElement.scrollHeight <= maxHeight + 1) {
            optimalSize = mid;
            low = mid + 0.5; // Increase precision
          } else {
            high = mid - 0.5;
          }
          
          // Prevent infinite loop
          if (high - low < 0.5) break;
        }
        
        titleElement.style.fontSize = optimalSize + 'px';
      }
    });
  });
}

// Debounced resize handler for font size adjustment
let resizeTimeout;
window.addEventListener('resize', () => {
  clearTimeout(resizeTimeout);
  resizeTimeout = setTimeout(adjustThumbnailTitleFontSize, 150);
});

// ============================================
// VIEW TOGGLE (CHANNEL MODE / LIST MODE)
// ============================================
function initViewToggle() {
  const viewToggleBtn = document.getElementById('viewToggleBtn');
  const contentSections = document.querySelectorAll('.content-section');
  
  if (!viewToggleBtn) return;
  
  let isListMode = false;
  
  viewToggleBtn.addEventListener('click', () => {
    isListMode = !isListMode;
    
    // Toggle icons
    const gridIcon = viewToggleBtn.querySelector('.grid-icon');
    const listIcon = viewToggleBtn.querySelector('.list-icon');
    
    if (isListMode) {
      gridIcon.style.display = 'none';
      listIcon.style.display = 'block';
    } else {
      gridIcon.style.display = 'block';
      listIcon.style.display = 'none';
    }
    
    // Toggle list-mode class on all thumbnails grids
    contentSections.forEach(section => {
      const grid = section.querySelector('.thumbnails-grid');
      if (grid) {
        grid.classList.toggle('list-mode', isListMode);
      }
    });
    
    // Adjust font sizes when switching to grid mode
    if (!isListMode) {
      // Use setTimeout to ensure layout is complete
      setTimeout(adjustThumbnailTitleFontSize, 50);
    }
  });
}

// ============================================
// MOBILE SEARCH TOGGLE
// ============================================
function initMobileSearchToggle() {
  const mobileSearchToggle = document.getElementById('mobileSearchToggle');
  const mobileSearchClose = document.getElementById('mobileSearchClose');
  const searchContainer = document.querySelector('.search-container');
  
  if (!mobileSearchToggle || !searchContainer) return;
  
  mobileSearchToggle.addEventListener('click', () => {
    searchContainer.classList.add('active');
    document.body.classList.add('search-active');
    
    // Focus on search input when opened
    const searchInput = document.getElementById('librarySearchInput');
    if (searchInput) {
      setTimeout(() => searchInput.focus(), 100);
    }
  });
  
  // Close button
  if (mobileSearchClose) {
    mobileSearchClose.addEventListener('click', () => {
      searchContainer.classList.remove('active');
      document.body.classList.remove('search-active');
    });
  }
  
  // Close search container when clicking outside
  document.addEventListener('click', (e) => {
    if (searchContainer.classList.contains('active') &&
        !searchContainer.contains(e.target) &&
        !mobileSearchToggle.contains(e.target)) {
      searchContainer.classList.remove('active');
      document.body.classList.remove('search-active');
    }
  });
}

// ============================================
// LIBRARY SEARCH FUNCTIONALITY
// ============================================
function initLibrarySearch() {
  const searchInput = document.getElementById('librarySearchInput');
  const searchClearBtn = document.getElementById('searchClearBtn');
  const recentSearches = document.getElementById('recentSearches');
  const keywordBubbles = document.getElementById('keywordBubbles');
  const searchResultsInfo = document.getElementById('searchResultsInfo');
  const thumbnailCards = document.querySelectorAll('.thumbnail-card');
  const contentSections = document.querySelectorAll('.content-section');
  
  if (!searchInput) return;
  
  // Recent search keywords storage
  let recentKeywords = JSON.parse(localStorage.getItem('libraryRecentSearches') || '[]');
  let searchTimeout = null;
  
  // Update recent searches display
  function updateRecentSearches() {
    if (recentKeywords.length > 0 && keywordBubbles) {
      keywordBubbles.innerHTML = recentKeywords.slice(0, 5).map(keyword => 
        `<span class="keyword-bubble">${keyword}</span>`
      ).join('');
      
      // Add click handlers to keyword bubbles
      keywordBubbles.querySelectorAll('.keyword-bubble').forEach(bubble => {
        bubble.addEventListener('click', () => {
          searchInput.value = bubble.textContent;
          // Show clear button
          if (searchClearBtn) {
            searchClearBtn.style.display = 'flex';
          }
          performSearch(bubble.textContent, true);
        });
      });
    }
  }
  
  // Perform search
  function performSearch(query, saveToRecent = false) {
    const searchTerm = query.trim().toLowerCase();
    
    if (!searchTerm) {
      // Show all items
      thumbnailCards.forEach(card => {
        card.style.display = '';
      });
      // Show all section titles (only if they exist)
      contentSections.forEach(section => {
        const sectionTitle = section.querySelector('.section-title');
        if (sectionTitle) {
          sectionTitle.style.display = '';
        }
      });
      if (searchResultsInfo) searchResultsInfo.style.display = 'none';
      if (recentSearches) recentSearches.style.display = 'none';
      return;
    }
    
    let visibleCount = 0;
    
    // Split search term into individual keywords
    const searchKeywords = searchTerm.split(/\s+/).filter(k => k.length > 0);
    
    thumbnailCards.forEach(card => {
      const title = card.getAttribute('data-title')?.toLowerCase() || '';
      const keywords = card.getAttribute('data-keywords')?.toLowerCase() || '';
      const type = card.getAttribute('data-type')?.toLowerCase() || '';
      const grade = card.getAttribute('data-grade')?.toLowerCase() || '';
      
      // Combine all searchable content
      const searchableContent = `${title} ${keywords} ${type} ${grade}`;
      
      // Check if ALL search keywords are present (AND logic)
      const matches = searchKeywords.every(keyword => 
        searchableContent.includes(keyword)
      );
      
      if (matches) {
        card.style.display = '';
        visibleCount++;
      } else {
        card.style.display = 'none';
      }
    });
    
    // Hide section titles if no results in that section
    contentSections.forEach(section => {
      const grid = section.querySelector('.thumbnails-grid');
      const sectionTitle = section.querySelector('.section-title');
      
      if (grid && sectionTitle) {
        const hasVisibleCards = Array.from(grid.querySelectorAll('.thumbnail-card')).some(card => {
          return card.style.display !== 'none';
        });
        
        sectionTitle.style.display = hasVisibleCards ? '' : 'none';
      }
    });
    
    // Update search results info
    if (searchResultsInfo) {
      searchResultsInfo.textContent = `${visibleCount} result${visibleCount !== 1 ? 's' : ''}`;
      searchResultsInfo.style.display = 'block';
    }
    
    // Hide recent searches when showing results
    if (recentSearches) {
      recentSearches.style.display = 'none';
    }
    
    // Add to recent searches only when saveToRecent is true
    if (saveToRecent && !recentKeywords.includes(query)) {
      recentKeywords.unshift(query);
      if (recentKeywords.length > 5) {
        recentKeywords = recentKeywords.slice(0, 5);
      }
      localStorage.setItem('libraryRecentSearches', JSON.stringify(recentKeywords));
      updateRecentSearches();
    }
    
    // Adjust font sizes after search filtering
    setTimeout(adjustThumbnailTitleFontSize, 50);
  }
  
  // Search input event - debounced incremental search
  searchInput.addEventListener('input', (e) => {
    const value = e.target.value;
    
    if (searchClearBtn) {
      searchClearBtn.style.display = value ? 'flex' : 'none';
    }
    
    // Clear any existing timeout
    if (searchTimeout) {
      clearTimeout(searchTimeout);
    }
    
    if (!value) {
      // No debounce for clearing search
      performSearch('', false);
      if (recentSearches && recentKeywords.length > 0) {
        recentSearches.style.display = 'flex';
      }
    } else {
      // Debounce search by 400ms to reduce lag and improve performance
      searchTimeout = setTimeout(() => {
        performSearch(value, false);
      }, 400);
    }
  });
  
  // Search on Enter key
  searchInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
      performSearch(searchInput.value, true);
    }
  });
  
  // Clear button
  if (searchClearBtn) {
    searchClearBtn.addEventListener('click', () => {
      searchInput.value = '';
      searchClearBtn.style.display = 'none';
      performSearch('', false);
      searchInput.focus();
      if (recentSearches && recentKeywords.length > 0) {
        recentSearches.style.display = 'flex';
      }
    });
  }
  
  // Show recent searches on focus if input is empty
  searchInput.addEventListener('focus', () => {
    if (!searchInput.value && recentKeywords.length > 0 && recentSearches) {
      recentSearches.style.display = 'flex';
    }
  });
  
  // Hide recent searches on blur (with delay to allow bubble clicks)
  searchInput.addEventListener('blur', () => {
    setTimeout(() => {
      if (recentSearches && !searchInput.value) {
        recentSearches.style.display = 'none';
      }
    }, 200);
  });
  
  // Initialize recent searches display
  updateRecentSearches();
}

// ============================================
// CLASS MANAGEMENT PAGE INITIALIZATION
// ============================================

// Module-level variables to persist across navigation within same session
// (but reset on page refresh since not using sessionStorage)
let addedClasses = [];

function initializeManageClassPage() {
  console.log('🔵 initializeManageClassPage called');
  
  // Wait for DOM to be ready after display change
  requestAnimationFrame(() => {
    const container = document.getElementById('classListContainer');
    console.log('🔵 Elements found:', {container: !!container});
    
    if (!container) {
      console.error('🔴 Required elements not found!');
      return;
    }
    
    // Render the class list
    function renderClassList() {
      console.log('🔵 renderClassList called, addedClasses count:', addedClasses.length);
      if (!container) return;
      
      if (addedClasses.length === 0) {
        // Show empty state with link
        container.innerHTML = '<div class="empty-class-state" id="emptyClassState"><p>You have no classes at the moment. <a href="#" id="addClassLink" style="color: #007bff; text-decoration: none; font-weight: 500;">Contact</a> Helpdesk to create class.</p></div>';
        
        // Add click event to the link
        const addClassLink = document.getElementById('addClassLink');
        console.log('🔵 Add class link found:', !!addClassLink);
        if (addClassLink) {
          addClassLink.addEventListener('click', (e) => {
            console.log('🟢 Add class link clicked!');
            e.preventDefault();
            initializeDefaultClasses();
          });
        }
      } else {
        // Show classes list (limit to 15)
        let html = '<div class="added-class-list">';
        html += '<div class="added-class-list-header">Classes</div>';
        
        const displayClasses = addedClasses.slice(0, 15);
        displayClasses.forEach((classItem, index) => {
          const gradeText = classItem.grade ? `Grade ${classItem.grade}` : 'Grade 1';
          const studentCount = classItem.students ? classItem.students.length : 0;
          const classCode = classItem.classCode || 'N/A';
          html += `
            <div class="class-item">
              <div class="class-item-info">
                <span class="class-item-title">${classItem.name}</span>
                <span class="class-item-grade">${studentCount} students • Class Code: <strong>${classCode}</strong></span>
              </div>
              <div class="class-item-buttons">
                <button class="class-item-students-btn" data-index="${index}">Students</button>
              </div>
            </div>
          `;
        });
        
        html += '</div>';
        container.innerHTML = html;
        
        // Add event listeners to students buttons
        const studentButtons = container.querySelectorAll('.class-item-students-btn');
        console.log('🟡 Found student buttons:', studentButtons.length);
        studentButtons.forEach(btn => {
          btn.addEventListener('click', (e) => {
            console.log('🟢 Student button clicked!');
            const index = parseInt(e.target.getAttribute('data-index'));
            console.log('🟢 Opening student list for class index:', index);
            handleStudentList(index);
          });
        });
      }
    }
    
    // Initialize default classes (1A, 1B, 1C, 1D)
    function initializeDefaultClasses() {
      console.log('🟢 initializeDefaultClasses called!');
      const classNames = ['1A', '1B', '1C', '1D'];
      addedClasses = classNames.map(name => {
        // Generate random student count between 15-30
        const studentCount = Math.floor(Math.random() * 16) + 15;
        const students = Array.from({length: studentCount}, (_, i) => `Student${String(i + 1).padStart(2, '0')}`);
        
        return {
          name: name,
          grade: 1,
          classCode: generateClassCode(),
          students: students
        };
      });
      
      console.log('🟢 Classes created:', addedClasses.length);
      
      // Re-render the list
      renderClassList();
    }
    
    // Generate random 8-character class code
    function generateClassCode() {
      const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
      let code = '';
      for (let i = 0; i < 8; i++) {
        code += chars.charAt(Math.floor(Math.random() * chars.length));
      }
      return code;
    }
    
    // Handle student list
    function handleStudentList(index) {
      const classItem = addedClasses[index];
      
      // Get modal elements
      const modal = document.getElementById('studentListModal');
      const modalTitle = modal.querySelector('.modal-title');
      const modalDescription = modal.querySelector('.modal-description');
      const studentTableBody = document.getElementById('studentTableBody');
      const studentCountDisplay = document.getElementById('studentCountDisplay');
      const cancelBtn = document.getElementById('cancelStudentList');
      
      if (!modal || !studentTableBody) return;
      
      // Use students from the class
      const allStudents = classItem.students || [];
      
      // Update modal title and description
      if (modalTitle) {
        modalTitle.textContent = `Class ${classItem.name}`;
      }
      if (modalDescription) {
        modalDescription.innerHTML = `Class code: <strong>${classItem.classCode}</strong>`;
      }
      
      // Populate student table (without checkboxes)
      studentTableBody.innerHTML = allStudents.map((studentName, i) => {
        return `
          <tr>
            <td>${studentName}</td>
          </tr>
        `;
      }).join('');
      
      // Update total count
      if (studentCountDisplay) {
        studentCountDisplay.textContent = allStudents.length;
      }
      
      // Show modal
      modal.classList.add('active');
      
      // Cancel button (acts as close button)
      if (cancelBtn) {
        const newCancelBtn = cancelBtn.cloneNode(true);
        cancelBtn.parentNode.replaceChild(newCancelBtn, cancelBtn);
        
        newCancelBtn.addEventListener('click', () => {
          modal.classList.remove('active');
        });
      }
      
      // Close on overlay click
      modal.onclick = (e) => {
        if (e.target === modal) {
          modal.classList.remove('active');
        }
      };
    }
    
    // Initial render (will show empty state or existing classes)
    renderClassList();
    console.log('🔵 initializeManageClassPage completed');
  });
}

function initializeJoinClassPage() {
  // Wait for DOM to be ready after display change
  requestAnimationFrame(() => {
    // Get inputs only from the join-class page, not from modals
    const joinClassPage = document.getElementById('join-class');
    if (!joinClassPage) return;
    
    const inputs = joinClassPage.querySelectorAll('.class-code-input');
    const submitBtn = joinClassPage.querySelector('#submitClassCode');
    const continueBtn = joinClassPage.querySelector('#continueToLibrary');
    const joinedClassesList = document.getElementById('joinedClassesList');
    
    // Track joined classes
    let joinedClasses = [];
    
  // Load joined classes from sessionStorage
    const savedClasses = sessionStorage.getItem('studentJoinedClasses');
    if (savedClasses) {
      try {
        joinedClasses = JSON.parse(savedClasses);
      } catch (e) {
        console.error('Error loading joined classes:', e);
      }
    }
    
    // Render joined classes list
    function renderJoinedClasses() {
      if (!joinedClassesList) return;
      
      const emptyMessage = document.getElementById('emptyClassesMessage');
      const actualList = document.getElementById('actualClassesList');
      
      if (joinedClasses.length === 0) {
        if (emptyMessage) emptyMessage.style.display = 'block';
        if (actualList) actualList.style.display = 'none';
      } else {
        let html = '';
        joinedClasses.forEach((classItem) => {
          html += `
            <div class="joined-class-item">
              <span class="joined-class-name">Class: <strong>${classItem.name || 'Class'}</strong></span>
              <span class="joined-class-code">Joined with Class Code: <strong>${classItem.code}</strong></span>
            </div>
          `;
        });
        if (actualList) {
          actualList.innerHTML = html;
          actualList.style.display = 'block';
        }
        if (emptyMessage) emptyMessage.style.display = 'none';
      }
    }
    
    // Handle show classes link click
    function setupShowClassesLink() {
      const showClassesLink = document.getElementById('showClassesLink');
      const emptyMessage = document.getElementById('emptyClassesMessage');
      const actualList = document.getElementById('actualClassesList');
      
      if (showClassesLink) {
        showClassesLink.addEventListener('click', (e) => {
          e.preventDefault();
          if (emptyMessage) emptyMessage.style.display = 'none';
          
          // If no classes joined yet, show sample/demo classes
          if (joinedClasses.length === 0) {
            const sampleClasses = [
              { name: '1D', code: 'ABC12345' }
            ];
            
            let html = '';
            sampleClasses.forEach((classItem) => {
              html += `
                <div class="joined-class-item">
                  <span class="joined-class-name">Class: <strong>${classItem.name}</strong></span>
                  <span class="joined-class-code">Joined with Class Code: <strong>${classItem.code}</strong></span>
                </div>
              `;
            });
            
            if (actualList) {
              actualList.innerHTML = html;
              actualList.style.display = 'block';
            }
          } else {
            // Show the actual joined classes
            if (actualList) actualList.style.display = 'block';
          }
        });
      }
    }
    
    // Initial render
    renderJoinedClasses();
    setupShowClassesLink();
    
    // Submit button - clone to remove old listeners
    if (submitBtn) {
      const newSubmitBtn = submitBtn.cloneNode(true);
      submitBtn.parentNode.replaceChild(newSubmitBtn, submitBtn);
      
      newSubmitBtn.addEventListener('click', () => {
        // Re-query inputs to get current values
        const currentInputs = joinClassPage.querySelectorAll('.class-code-input');
        const code = Array.from(currentInputs).map(input => input.value).join('').toUpperCase();
        
        if (code.length !== 8) {
          alert('Please enter all 8 characters of the class code.');
          return;
        }
        
        // Check if already joined this class
        const alreadyJoined = joinedClasses.some(c => c.code === code);
        if (alreadyJoined) {
          alert('You have already joined this class!');
          // Clear inputs
          currentInputs.forEach(input => input.value = '');
          if (currentInputs[0]) currentInputs[0].focus();
          return;
        }
        
        // Add new class
        const newClass = {
          code: code,
          name: `Class ${joinedClasses.length + 1}`,
          joinedDate: new Date().toISOString()
        };
        
        joinedClasses.push(newClass);
        
        // Save to sessionStorage
        sessionStorage.setItem('studentJoinedClasses', JSON.stringify(joinedClasses));
        
        // Update success message
        const successMessage = joinClassPage.querySelector('#successMessage');
        if (successMessage) {
          successMessage.textContent = `You have successfully joined the class with code ${code}!`;
        }
        
        // Show success view
        const joinFormView = joinClassPage.querySelector('#joinFormView');
        const successView = joinClassPage.querySelector('#successView');
        
        if (joinFormView) joinFormView.style.display = 'none';
        if (successView) successView.style.display = 'block';
      });
    }
    
    // Continue button - clone to remove old listeners
    if (continueBtn) {
      const newContinueBtn = continueBtn.cloneNode(true);
      continueBtn.parentNode.replaceChild(newContinueBtn, continueBtn);
      
      newContinueBtn.addEventListener('click', () => {
        // Reset form
        const currentInputs = joinClassPage.querySelectorAll('.class-code-input');
        currentInputs.forEach(input => input.value = '');
        const joinFormView = joinClassPage.querySelector('#joinFormView');
        const successView = joinClassPage.querySelector('#successView');
        if (joinFormView) joinFormView.style.display = 'block';
        if (successView) successView.style.display = 'none';
        
        // Re-render the joined classes list
        renderJoinedClasses();
        
        // Focus first input
        if (currentInputs[0]) currentInputs[0].focus();
      });
    }
    
    // Input handlers - add directly without cloning (like the modal)
    const currentInputs = joinClassPage.querySelectorAll('.class-code-input');
    
    currentInputs.forEach((input, index) => {
      // Handle paste
      input.addEventListener('paste', (e) => {
        e.preventDefault();
        const pastedData = e.clipboardData.getData('text').trim().toUpperCase();
        
        // Fill inputs with pasted data
        for (let i = 0; i < Math.min(pastedData.length, 8); i++) {
          if (currentInputs[i]) {
            currentInputs[i].value = pastedData[i];
          }
        }
        
        // Focus on the next empty input or the last one
        const nextEmptyIndex = Array.from(currentInputs).findIndex(inp => !inp.value);
        if (nextEmptyIndex !== -1) {
          currentInputs[nextEmptyIndex].focus();
        } else {
          currentInputs[7].focus();
        }
      });
      
      // Handle input
      input.addEventListener('input', (e) => {
        const value = e.target.value.toUpperCase();
        
        if (value.length > 0) {
          e.target.value = value[value.length - 1]; // Keep only the last char
          
          // Move to next input
          if (index < currentInputs.length - 1) {
            currentInputs[index + 1].focus();
          }
        }
      });
      
      // Handle backspace
      input.addEventListener('keydown', (e) => {
        if (e.key === 'Backspace' && !e.target.value && index > 0) {
          currentInputs[index - 1].focus();
        }
      });
    });
    
    // Focus first input
    if (currentInputs[0]) currentInputs[0].focus();
  });
}

// ============================================
// INITIALIZATION
// ============================================
document.addEventListener('DOMContentLoaded', () => {
  initNavigation();
  initOnboardWidget();
  initModal();
  initHelpSupportModal();
  initUserDropdown();
  initJoinClassSuccessModal();
  initThumbnails();
  initDownloadAppModal();
  initFeatureModals();
  initNotificationPanel();
  initViewToggle();
  initMobileSearchToggle();
  initLibrarySearch();
  initUserRoleToggle();
  
  // Adjust thumbnail title font sizes after initial load
  setTimeout(adjustThumbnailTitleFontSize, 100);
  
  console.log('Library website initialized successfully!');
});

// ============================================
// USER ROLE TOGGLE (Student/Teacher View)
// ============================================
function initUserRoleToggle() {
  const userInfo = document.getElementById('userInfo');
  const userRoleBadge = document.getElementById('userRoleBadge');
  
  if (!userRoleBadge || !userInfo) return;
  
  userRoleBadge.addEventListener('click', (e) => {
    e.stopPropagation();
    
    // Get current view mode
    const currentMode = userInfo.getAttribute('data-view-mode');
    const newMode = currentMode === 'student' ? 'teacher' : 'student';
    
    // Update data attribute
    userInfo.setAttribute('data-view-mode', newMode);
    
    // Update badge appearance and text
    if (newMode === 'teacher') {
      userRoleBadge.textContent = 'Teacher';
      userRoleBadge.classList.remove('student-badge');
      userRoleBadge.classList.add('teacher-badge');
    } else {
      userRoleBadge.textContent = 'Student';
      userRoleBadge.classList.remove('teacher-badge');
      userRoleBadge.classList.add('student-badge');
    }
    
    // Filter thumbnails
    filterThumbnailsByRole(newMode);
  });
  
  // Apply initial filtering based on current data-view-mode
  const initialMode = userInfo.getAttribute('data-view-mode');
  filterThumbnailsByRole(initialMode);
}

function filterThumbnailsByRole(mode) {
  const thumbnails = document.querySelectorAll('.thumbnail-card');
  
  thumbnails.forEach(thumbnail => {
    const hasTeacherBadge = thumbnail.querySelector('.book-type-badge.teacher-badge');
    const hasStudentBadge = thumbnail.querySelector('.book-type-badge.student-badge');
    const isContentPackage = thumbnail.getAttribute('data-type') === 'content-package';
    const isSample = thumbnail.getAttribute('data-type') === 'sample';
    
    if (mode === 'student') {
      // Show: Content Package, Student books, and Sample
      // Hide: Teacher books
      if (hasTeacherBadge) {
        thumbnail.style.display = 'none';
      } else {
        thumbnail.style.display = '';
      }
    } else {
      // Show all books (teacher view)
      thumbnail.style.display = '';
    }
  });
  
  // Adjust font sizes after filtering
  setTimeout(adjustThumbnailTitleFontSize, 50);
}

// ============================================
// UTILITY: Reset checklist (for testing)
// ============================================
window.resetChecklist = function() {
  if (confirm('Are you sure you want to reset the Getting Started checklist?')) {
    state.tasks.forEach(task => task.completed = false);
    state.panelOpen = false;
    saveState(state);
    renderTasks();
    
    const panel = document.getElementById('onboardPanel');
    const toggleBtn = document.getElementById('onboardToggle');
    if (panel) panel.classList.remove('open');
    if (toggleBtn) toggleBtn.setAttribute('aria-expanded', 'false');
    
    console.log('Checklist reset successfully!');
  }
};

// ============================================
// WELCOME TOUR
// ============================================
document.addEventListener('DOMContentLoaded', function() {
  const TOUR_STORAGE_KEY = 'libraryWelcomeTourCompleted';
  
  // Tour steps - updated to focus on key navigation and features
  const steps = [
    { 
      title: "Library", 
      text: "This is your library! You can view all your subscribed channels and eBooks here.",
      targetSelector: '.nav-link[data-page="my-library"]',
      placement: 'bottom'
    },
    { 
      title: "Assignment", 
      text: "This is your assignment page! You can view all your assignments here.",
      targetSelector: '.nav-link[data-page="assignment"]',
      placement: 'bottom'
    },
    { 
      title: "Help", 
      text: "Need help? Click here to access help resources and FAQs.",
      targetSelector: '.nav-link[data-page="support"]',
      placement: 'bottom'
    },
    { 
      title: "Profile Settings", 
      text: "Access your profile settings here. Update your profile in About Me and secure your account by changing your password.",
      targetSelector: '.user-dropdown-item[data-action="about-me"]',
      placement: 'left',
      openDropdown: true
    },
    { 
      title: "Add Library Content", 
      text: "Add more channels and eBooks with your access codes.",
      targetSelector: '.user-dropdown-item[data-action="add-library-content"]',
      placement: 'left',
      openDropdown: true
    },
    { 
      title: "Class", 
      text: "View your classes here.",
      targetSelector: '.user-dropdown-item[data-action="manage-class"]',
      placement: 'left',
      openDropdown: true
    },
    { 
      title: "Student eBooks", 
      text: "Access interactive student eBooks with enhanced learning features.",
      targetSelector: '.thumbnail-card[data-title="My Pals Are Here! Primary Maths 4th Edition Textbook 3A"]',
      placement: 'right',
      scrollIntoView: true
    },
    { 
      title: "Teacher eBooks and Resources", 
      text: "Access teacher resources like the Teacher’s Guide, lesson plans, schemes of work, and additional tools—all in one place.",
      targetSelector: '.thumbnail-card[data-teacher-resources]',
      placement: 'right',
      scrollIntoView: true
    }
  ];

  const tourEl = document.getElementById('welcomeTour');
  const bubble = document.querySelector('.tour-bubble');
  const tailEl = document.getElementById('tourTail');
  const spotlightEl = document.getElementById('tourSpotlight');
  const titleEl = document.getElementById('tourTitle');
  const txtEl = document.getElementById('tourText');
  const progressEl = document.getElementById('tourProgress');
  const backBtn = document.getElementById('tourBack');
  const nextBtn = document.getElementById('tourNext');
  const skipBtn = document.getElementById('tourSkip');

  let currentStepIndex = 0;

  function getElementPosition(element) {
    const rect = element.getBoundingClientRect();
    return {
      top: rect.top,
      left: rect.left,
      width: rect.width,
      height: rect.height,
      bottom: rect.bottom,
      right: rect.right
    };
  }

  function positionBubble(step) {
    const target = document.querySelector(step.targetSelector);
    if (!target) {
      console.warn('Target element not found:', step.targetSelector);
      return;
    }

    // Scroll element into view if specified
    if (step.scrollIntoView) {
      target.scrollIntoView({ behavior: 'smooth', block: 'center', inline: 'nearest' });
      // Wait a bit for scroll to complete before positioning
      setTimeout(() => {
        positionBubbleAfterScroll(step, target);
      }, 500);
      return;
    }
    
    positionBubbleAfterScroll(step, target);
  }
  
  function positionBubbleAfterScroll(step, target) {

    let targetPos = getElementPosition(target);
    
    // Special handling for first row of thumbnail cards
    if (step.highlightFirstRow && target.classList.contains('thumbnails-grid')) {
      const cards = Array.from(target.querySelectorAll('.thumbnail-card'));
      if (cards.length > 0) {
        // Find cards in the first row (same top position)
        const firstCardTop = getElementPosition(cards[0]).top;
        const firstRowCards = cards.filter(card => {
          const cardPos = getElementPosition(card);
          return Math.abs(cardPos.top - firstCardTop) < 10; // Within 10px threshold
        });
        
        // Calculate bounding box for first row
        if (firstRowCards.length > 0) {
          const positions = firstRowCards.map(card => getElementPosition(card));
          const minLeft = Math.min(...positions.map(p => p.left));
          const maxRight = Math.max(...positions.map(p => p.right));
          const minTop = Math.min(...positions.map(p => p.top));
          const maxBottom = Math.max(...positions.map(p => p.bottom));
          
          targetPos = {
            top: minTop,
            left: minLeft,
            width: maxRight - minLeft,
            height: maxBottom - minTop,
            bottom: maxBottom,
            right: maxRight
          };
        }
      }
    }
    
    const bubbleWidth = 320;
    const bubbleHeight = 180;
    const padding = 20;
    const tailSize = 14.5;
    const spotlightMargin = 10; // Spotlight extends 10px beyond target

    let bubbleTop, bubbleLeft, tailTop, tailLeft;
    let spotTop = targetPos.top - spotlightMargin;
    let spotLeft = targetPos.left - spotlightMargin;
    let spotWidth = targetPos.width + (spotlightMargin * 2);
    let spotHeight = targetPos.height + (spotlightMargin * 2);

    const viewportWidth = window.innerWidth;
    const viewportHeight = window.innerHeight;
    
    // Determine effective placement (with automatic adjustment for viewport)
    let effectivePlacement = step.placement;
    
    // Check if bottom placement would go off-screen, if so switch to top
    if (step.placement === 'bottom') {
      const bottomBubbleTop = spotTop + spotHeight + padding;
      if (bottomBubbleTop + bubbleHeight > viewportHeight - 20) {
        // Would go off screen at bottom, try top instead
        const topBubbleTop = spotTop - bubbleHeight - padding;
        if (topBubbleTop >= 20) {
          effectivePlacement = 'top';
        }
      }
    }
    
    // Check if top placement would go off-screen, if so switch to bottom
    if (step.placement === 'top') {
      const topBubbleTop = spotTop - bubbleHeight - padding;
      if (topBubbleTop < 20) {
        // Would go off screen at top, try bottom instead
        const bottomBubbleTop = spotTop + spotHeight + padding;
        if (bottomBubbleTop + bubbleHeight <= viewportHeight - 20) {
          effectivePlacement = 'bottom';
        }
      }
    }

    // Position bubble based on effective placement
    switch (effectivePlacement) {
      case 'bottom':
        // Position below the spotlight area
        bubbleTop = spotTop + spotHeight + padding;
        bubbleLeft = targetPos.left + (targetPos.width / 2) - (bubbleWidth / 2);
        // For Help & Support step, position tail at right corner
        // For Profile & Settings dropdown, also position tail at right
        if (step.targetSelector === '.help-icon-btn' || step.targetSelector === '#userDropdownMenu') {
          tailLeft = bubbleWidth - tailSize - 30; // 30px from right edge
        } else {
          tailLeft = bubbleWidth / 2 - tailSize / 2;
        }
        tailTop = -tailSize / 2;
        break;
      
      case 'top':
        // Position above the spotlight area
        bubbleTop = spotTop - bubbleHeight - padding;
        bubbleLeft = targetPos.left + (targetPos.width / 2) - (bubbleWidth / 2);
        tailLeft = bubbleWidth / 2 - tailSize / 2;
        tailTop = bubbleHeight - tailSize / 2;
        break;
      
      case 'right':
        bubbleTop = targetPos.top + (targetPos.height / 2) - (bubbleHeight / 2);
        bubbleLeft = spotLeft + spotWidth + padding;
        tailLeft = -tailSize / 2;
        tailTop = bubbleHeight / 2 - tailSize / 2;
        break;
      
      case 'left':
        bubbleTop = targetPos.top + (targetPos.height / 2) - (bubbleHeight / 2);
        bubbleLeft = spotLeft - bubbleWidth - padding;
        tailLeft = bubbleWidth - tailSize / 2;
        tailTop = bubbleHeight / 2 - tailSize / 2;
        break;
    }

    // Keep bubble within viewport (fine-tuning)
    if (bubbleLeft < 20) bubbleLeft = 20;
    if (bubbleLeft + bubbleWidth > viewportWidth - 20) {
      bubbleLeft = viewportWidth - bubbleWidth - 20;
    }
    if (bubbleTop < 20) bubbleTop = 20;
    if (bubbleTop + bubbleHeight > viewportHeight - 20) {
      bubbleTop = viewportHeight - bubbleHeight - 20;
    }

    // Apply positions
    bubble.style.left = bubbleLeft + 'px';
    bubble.style.top = bubbleTop + 'px';
    bubble.style.width = bubbleWidth + 'px';
    bubble.style.minWidth = bubbleWidth + 'px';
    
    tailEl.style.left = tailLeft + 'px';
    tailEl.style.top = tailTop + 'px';
    
    spotlightEl.style.left = spotLeft + 'px';
    spotlightEl.style.top = spotTop + 'px';
    spotlightEl.style.width = spotWidth + 'px';
    spotlightEl.style.height = spotHeight + 'px';
  }

  function showStep(index) {
    if (index < 0 || index >= steps.length) return;

    const step = steps[index];
    const previousStep = currentStepIndex >= 0 ? steps[currentStepIndex] : null;
    
    // Close dropdown from previous step if it was open
    if (previousStep && previousStep.openDropdown) {
      const userInfo = document.getElementById('userInfo');
      const userDropdownMenu = document.getElementById('userDropdownMenu');
      if (userInfo) userInfo.classList.remove('active');
      if (userDropdownMenu) userDropdownMenu.classList.remove('active');
    }
    
    currentStepIndex = index;

    titleEl.textContent = step.title;
    txtEl.textContent = step.text;
    progressEl.textContent = `${index + 1} of ${steps.length}`;
    
    backBtn.disabled = index === 0;
    nextBtn.textContent = index === steps.length - 1 ? 'Finish' : 'Next >';

    // Open dropdown if this step requires it
    if (step.openDropdown) {
      const userInfo = document.getElementById('userInfo');
      const userDropdownMenu = document.getElementById('userDropdownMenu');
      if (userInfo) userInfo.classList.add('active');
      if (userDropdownMenu) userDropdownMenu.classList.add('active');
      
      // Wait for dropdown to render before positioning bubble
      setTimeout(() => {
        positionBubble(step);
      }, 100);
    } else {
      positionBubble(step);
    }
  }

  function openTour() {
    // Make sure we're on the My Library page
    const myLibraryPage = document.getElementById('my-library');
    if (myLibraryPage && !myLibraryPage.classList.contains('active')) {
      const myLibraryLink = document.querySelector('.nav-link[data-page="my-library"]');
      if (myLibraryLink) myLibraryLink.click();
    }

    // Freeze the page
    document.body.style.overflow = 'hidden';
    document.body.style.paddingRight = (window.innerWidth - document.documentElement.clientWidth) + 'px'; // Prevent layout shift from scrollbar

    tourEl.classList.remove('hidden');
    currentStepIndex = 0;
    showStep(0);
  }

  function closeTour() {
    // Close any open dropdown
    const currentStep = steps[currentStepIndex];
    if (currentStep && currentStep.openDropdown) {
      const userInfo = document.getElementById('userInfo');
      const userDropdownMenu = document.getElementById('userDropdownMenu');
      if (userInfo) userInfo.classList.remove('active');
      if (userDropdownMenu) userDropdownMenu.classList.remove('active');
    }
    
    tourEl.classList.add('hidden');
    
    // Unfreeze the page
    document.body.style.overflow = '';
    document.body.style.paddingRight = '';
    
    // Mark tour as completed
    localStorage.setItem(TOUR_STORAGE_KEY, 'true');
  }

  function skipTour() {
    closeTour();
  }

  function nextStep() {
    if (currentStepIndex < steps.length - 1) {
      showStep(currentStepIndex + 1);
    } else {
      closeTour();
    }
  }

  function prevStep() {
    if (currentStepIndex > 0) {
      showStep(currentStepIndex - 1);
    }
  }

  // Event listeners
  if (backBtn) backBtn.addEventListener('click', prevStep);
  if (nextBtn) nextBtn.addEventListener('click', nextStep);
  if (skipBtn) skipBtn.addEventListener('click', skipTour);

  // Keyboard navigation
  window.addEventListener('keydown', (e) => {
    if (tourEl.classList.contains('hidden')) return;
    
    if (e.key === 'Escape') skipTour();
    if (e.key === 'ArrowLeft' && !backBtn.disabled) prevStep();
    if (e.key === 'ArrowRight') nextStep();
  });

  // Reposition on window resize
  let resizeTimeout;
  window.addEventListener('resize', () => {
    if (tourEl.classList.contains('hidden')) return;
    
    clearTimeout(resizeTimeout);
    resizeTimeout = setTimeout(() => {
      showStep(currentStepIndex);
    }, 100);
  });

  // Public API
  window.WelcomeTour = {
    open: openTour,
    close: closeTour,
    skip: skipTour,
    isActive: function() {
      return !tourEl.classList.contains('hidden');
    },
    isOnDropdownStep: function() {
      return !tourEl.classList.contains('hidden') && currentStepIndex >= 0 && steps[currentStepIndex].openDropdown === true;
    }
  };

  // Welcome Modal Management
  const WELCOME_MODAL_KEY = 'libraryWelcomeModalShown';
  const welcomeModal = document.getElementById('welcomeModal');
  const welcomeContinueBtn = document.getElementById('welcomeContinueBtn');

  function showWelcomeModal() {
    if (welcomeModal) {
      welcomeModal.classList.remove('hidden');
      document.body.style.overflow = 'hidden';
    }
  }

  function hideWelcomeModal() {
    if (welcomeModal) {
      welcomeModal.classList.add('hidden');
      document.body.style.overflow = '';
      localStorage.setItem(WELCOME_MODAL_KEY, 'true');
      // Start the tour after closing welcome modal
      setTimeout(() => {
        openTour();
      }, 300);
    }
  }

  // Handle continue button click
  if (welcomeContinueBtn) {
    welcomeContinueBtn.addEventListener('click', hideWelcomeModal);
  }

  // Use AI Modal Management - Slideshow Version
  const USE_AI_MODAL_KEY = 'libraryUseAiModalShown';
  const useAiModal = document.getElementById('useAiModal');
  const slideshowBackBtn = document.getElementById('slideshowBackBtn');
  const slideshowNextBtn = document.getElementById('slideshowNextBtn');
  let currentSlide = 1;
  const totalSlides = 3;

  function showUseAiModal(forceShow = false) {
    const hasSeenAiModal = localStorage.getItem(USE_AI_MODAL_KEY) === 'true';
    
    // Show if forced (from tour completion) or if user hasn't seen it before
    if (useAiModal && (forceShow || !hasSeenAiModal)) {
      currentSlide = 1;
      updateSlideDisplay();
      useAiModal.classList.remove('hidden');
      document.body.style.overflow = 'hidden';
    }
  }

  function hideUseAiModal() {
    if (useAiModal) {
      // Pause video if playing
      const explicoVideo = document.getElementById('explicoVideo');
      if (explicoVideo) {
        explicoVideo.pause();
        explicoVideo.currentTime = 0; // Reset to beginning
        const playPauseBtn = document.getElementById('playPauseBtn');
        if (playPauseBtn) {
          playPauseBtn.innerHTML = '<svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor"><path d="M8 5v14l11-7z"/></svg>';
          playPauseBtn.setAttribute('aria-label', 'Play');
        }
      }
      
      useAiModal.classList.add('hidden');
      document.body.style.overflow = '';
      localStorage.setItem(USE_AI_MODAL_KEY, 'true');
      currentSlide = 1;
      updateSlideDisplay();
    }
  }

  function updateSlideDisplay() {
    // Update slides visibility
    const slides = useAiModal.querySelectorAll('.slideshow-slide');
    slides.forEach((slide, index) => {
      if (index + 1 === currentSlide) {
        slide.classList.add('active');
      } else {
        slide.classList.remove('active');
      }
    });

    // Pause video when navigating away from slide 2
    const explicoVideo = document.getElementById('explicoVideo');
    if (explicoVideo && currentSlide !== 2) {
      explicoVideo.pause();
      const playPauseBtn = document.getElementById('playPauseBtn');
      if (playPauseBtn) {
        playPauseBtn.innerHTML = '<svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor"><path d="M8 5v14l11-7z"/></svg>';
        playPauseBtn.setAttribute('aria-label', 'Play');
      }
    }

    // Update progress dots
    const dots = useAiModal.querySelectorAll('.slideshow-dot');
    dots.forEach((dot, index) => {
      if (index + 1 === currentSlide) {
        dot.classList.add('active');
      } else {
        dot.classList.remove('active');
      }
    });

    // Update button states
    if (slideshowBackBtn) {
      if (currentSlide === 1) {
        slideshowBackBtn.textContent = 'Close';
        slideshowBackBtn.disabled = false;
      } else {
        slideshowBackBtn.textContent = 'Back';
        slideshowBackBtn.disabled = false;
      }
    }

    if (slideshowNextBtn) {
      if (currentSlide === totalSlides) {
        slideshowNextBtn.textContent = "Launch eBook";
      } else {
        slideshowNextBtn.textContent = 'Next';
      }
    }
  }

  function navigateSlideshow(direction) {
    if (direction === 'next') {
      if (currentSlide < totalSlides) {
        currentSlide++;
        updateSlideDisplay();
      } else {
        // On last slide, close modal and proceed
        handleSlideshowComplete();
      }
    } else if (direction === 'back') {
      if (currentSlide === 1) {
        // On first slide, close the modal
        hideUseAiModal();
      } else if (currentSlide > 1) {
        currentSlide--;
        updateSlideDisplay();
      }
    }
  }

  function handleSlideshowComplete() {
    hideUseAiModal();
      
    // Open ebook.html in a new tab
    window.open('ebook.html', '_blank');
  }

  // Expose to global scope for use in other functions
  window.showUseAiModal = showUseAiModal;
  window.hideUseAiModal = hideUseAiModal;

  // Handle slideshow navigation
  if (slideshowBackBtn) {
    slideshowBackBtn.addEventListener('click', () => navigateSlideshow('back'));
  }

  if (slideshowNextBtn) {
    slideshowNextBtn.addEventListener('click', () => navigateSlideshow('next'));
  }

  // Handle clicking on progress dots
  const slideshowDots = useAiModal?.querySelectorAll('.slideshow-dot');
  if (slideshowDots) {
    slideshowDots.forEach((dot, index) => {
      dot.addEventListener('click', () => {
        currentSlide = index + 1;
        updateSlideDisplay();
      });
    });
  }

  // Video Player Controls
  const explicoVideo = document.getElementById('explicoVideo');
  const playPauseBtn = document.getElementById('playPauseBtn');
  const seekBar = document.getElementById('seekBar');
  const seekBarProgress = document.getElementById('seekBarProgress');
  const currentTimeDisplay = document.getElementById('currentTime');
  const totalTimeDisplay = document.getElementById('totalTime');
  const fullscreenBtn = document.getElementById('fullscreenBtn');

  // Format time in MM:SS
  function formatTime(seconds) {
    if (isNaN(seconds)) return '0:00';
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  }

  // Play/Pause functionality
  if (playPauseBtn && explicoVideo) {
    playPauseBtn.addEventListener('click', () => {
      if (explicoVideo.paused) {
        explicoVideo.play();
        playPauseBtn.innerHTML = '<svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor"><path d="M6 4h4v16H6V4zm8 0h4v16h-4V4z"/></svg>';
        playPauseBtn.setAttribute('aria-label', 'Pause');
      } else {
        explicoVideo.pause();
        playPauseBtn.innerHTML = '<svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor"><path d="M8 5v14l11-7z"/></svg>';
        playPauseBtn.setAttribute('aria-label', 'Play');
      }
    });
  }

  // Update time display and seek bar
  if (explicoVideo) {
    explicoVideo.addEventListener('loadedmetadata', () => {
      totalTimeDisplay.textContent = formatTime(explicoVideo.duration);
      seekBar.max = explicoVideo.duration;
    });

    explicoVideo.addEventListener('timeupdate', () => {
      currentTimeDisplay.textContent = formatTime(explicoVideo.currentTime);
      seekBar.value = explicoVideo.currentTime;
      
      // Update progress bar
      const percentage = (explicoVideo.currentTime / explicoVideo.duration) * 100;
      seekBarProgress.style.width = `${percentage}%`;
    });

    // Seek functionality
    seekBar.addEventListener('input', () => {
      explicoVideo.currentTime = seekBar.value;
    });

    // Reset play button when video ends
    explicoVideo.addEventListener('ended', () => {
      playPauseBtn.innerHTML = '<svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor"><path d="M8 5v14l11-7z"/></svg>';
      playPauseBtn.setAttribute('aria-label', 'Play');
    });
  }

  // Fullscreen functionality
  if (fullscreenBtn && explicoVideo) {
    fullscreenBtn.addEventListener('click', () => {
      const videoContainer = explicoVideo.closest('.video-player-container');
      
      if (!document.fullscreenElement) {
        if (videoContainer.requestFullscreen) {
          videoContainer.requestFullscreen();
        } else if (videoContainer.webkitRequestFullscreen) {
          videoContainer.webkitRequestFullscreen();
        } else if (videoContainer.msRequestFullscreen) {
          videoContainer.msRequestFullscreen();
        }
      } else {
        if (document.exitFullscreen) {
          document.exitFullscreen();
        } else if (document.webkitExitFullscreen) {
          document.webkitExitFullscreen();
        } else if (document.msExitFullscreen) {
          document.msExitFullscreen();
        }
      }
    });
  }

  // Handle Offline Available badge click
  const offlineAvailableBadge = document.getElementById('offlineAvailableBadge');
  if (offlineAvailableBadge) {
    offlineAvailableBadge.addEventListener('click', () => {
      openDownloadAppModal();
    });
  }

  // Auto-start: show welcome modal on first visit only
  setTimeout(() => {
    // TESTING MODE: Comment out storage checks to show on every page load
    // const hasSeenWelcome = localStorage.getItem(WELCOME_MODAL_KEY) === 'true';
    // const hasCompletedTour = localStorage.getItem(TOUR_STORAGE_KEY) === 'true';
    
    // Show welcome modal if user hasn't seen it and hasn't completed tour
    // if (!hasSeenWelcome && !hasCompletedTour) {
      showWelcomeModal();
    // }
  }, 1000);

});
