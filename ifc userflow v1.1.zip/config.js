// ============================================
// WEBSITE CONFIGURATION
// ============================================
// Edit this file to quickly customize your website
// After making changes, refresh your browser to see updates

const CONFIG = {
  // ==================== SITE INFO ====================
  site: {
    title: 'Marshall Cavendish Education',
    year: '2026',
    companyName: 'MARSHALL CAVENDISH EDUCATION PTE. LTD.'
  },

  // ==================== USER INFO ====================
  user: {
    name: 'John Doe',
    role: 'Teacher',
    avatar: 'images/avatar.jpg',
    notificationCount: 3
  },

  // ==================== NAVIGATION MENU ====================
  navigation: [
    { id: 'my-library', label: 'My Library', active: true },
    { id: 'my-assignments', label: 'My Assignments', active: false },
    { id: 'my-resources', label: 'My Resources', active: false },
    { id: 'my-reports', label: 'My Reports', active: false },
    { id: 'collaboration', label: 'Collaboration', active: false }
  ],

  // ==================== CONTENT PACKAGES ====================
  contentPackages: [
    {
      id: 1,
      title: 'Mathematics Package',
      description: 'Complete math resources',
      image: 'images/mpah4e_3a.jpg',
      link: '#'
    },
    {
      id: 2,
      title: 'Science Package',
      description: 'Science learning materials',
      image: 'images/mpah4e_3b.jpg',
      link: '#'
    },
    {
      id: 3,
      title: 'English Package',
      description: 'Language arts resources',
      image: 'images/encc3.png',
      link: '#'
    },
    {
      id: 4,
      title: 'History Package',
      description: 'Historical content',
      image: 'images/mpah4e_3a_wb.jpg',
      link: '#'
    }
  ],

  // ==================== STUDENT BOOKS ====================
  studentBooks: [
    {
      id: 1,
      title: 'Math Workbook Grade 5',
      description: 'Interactive exercises',
      image: 'images/mpah4e_3a_wb.jpg',
      link: '#'
    },
    {
      id: 2,
      title: 'Science Textbook Grade 6',
      description: 'Comprehensive guide',
      image: 'images/mpah4e_3b_wb.jpg',
      link: '#'
    },
    {
      id: 3,
      title: 'English Reader Grade 4',
      description: 'Reading comprehension',
      image: 'images/encc3.png',
      link: '#'
    },
    {
      id: 4,
      title: 'Social Studies Grade 7',
      description: 'World cultures and geography',
      image: 'images/mpah4e_3a.jpg',
      link: '#'
    }
  ],

  // ==================== FOOTER LINKS ====================
  footer: {
    links: [
      { label: 'TERMS & CONDITIONS', url: '#my-library' },
      { label: 'DATA PROTECTION & PRIVACY STATEMENT', url: '#my-library' },
      { label: 'CUSTOMER SUPPORT', url: '#my-library' }
    ]
  },

  // ==================== CHECKLIST TASKS ====================
  // Getting Started checklist items
  // 
  // To ADD a new task: Add a new object with the following properties:
  //   - id: unique identifier (e.g., 'download-app')
  //   - label: task title shown to user
  //   - hint: brief description below the title
  //   - link: external link URL (optional, use '' if none)
  //   - video: tutorial video details { type: 'mp4', src: 'path/to/video.mp4' }
  //   - action: (optional) adds an action button { label: 'Button Text', type: 'link', url: 'https://...' }
  //
  // To EDIT a task: Change any property values
  // To REMOVE a task: Delete the entire task object (or comment it out with /* */)
  //
  // Example with action button:
  // {
  //   id: 'download-app',
  //   label: 'Download Mobile App',
  //   hint: 'Get the app for offline access.',
  //   link: '',
  //   video: { type: 'mp4', src: 'videos/app-download.mp4' },
  //   action: { label: 'Go to Store', type: 'link', url: 'https://app-store.com' }
  // }
  //
  checklistTasks: [
    {
      id: 'are-you-teacher',
      label: 'Are you a Teacher?',
      hint: 'Convert your role to a Teacher.',
      link: '',
      video: { type: 'mp4', src: 'videos/role-conversion.mp4' }
    },
    {
      id: 'create-class',
      label: 'Create a class',
      hint: 'Set up your first class to organise students.',
      link: '',
      video: { type: 'mp4', src: 'videos/create-class.mp4' }
    },
    {
      id: 'add-students',
      label: 'Add students',
      hint: 'Invite students by sending them a school code.',
      link: '',
      video: { type: 'mp4', src: 'videos/add-students.mp4' }
    },
    {
      id: 'assign-first-lesson',
      label: 'Assign your first lesson',
      hint: 'Publish a lesson so students can start.',
      link: '',
      video: { type: 'mp4', src: 'videos/assign-lesson.mp4' }
    },
    {
      id: 'premium-services',
      label: 'Premium Services',
      hint: 'To help setup school and onboard your Teachers?',
      link: '',
      video: { type: 'mp4', src: 'videos/premium-services.mp4' }
    },
  ],

  // ==================== THEME COLORS ====================
  theme: {
    // You can also edit these in styles.css :root section
    primaryColor: '#2f7ed8',
    primaryHover: '#2673c9',
    successColor: '#16a34a',
    textColor: '#1f2937',
    textLight: '#64748b',
    borderColor: '#e2e8f0',
    backgroundColor: '#ffffff',
    backgroundLight: '#f8fafc'
  },

  // ==================== HELP WIDGET ====================
  helpWidget: {
    icon: 'images/logo.png',
    title: 'Help & Support',
    // Customize the action when help button is clicked in script.js
  }
};

// Export for use in other files (if using modules)
// For now, this is just for reference and easy editing
if (typeof module !== 'undefined' && module.exports) {
  module.exports = CONFIG;
}
